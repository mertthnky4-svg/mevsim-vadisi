# Mevsim Vadisi

React, TypeScript, Vite ve Three.js ile hazırlanmış izometrik çiftlik oyunu.
Tarım, hayvancılık, madencilik ve üretim sistemleri içerir.

## Kurulum

Node.js 22.12 veya üzeri gerekir. Gemini API anahtarı gerekmez.

```sh
npm ci
npm run dev
```

Varsayılan adres: http://localhost:3000
Sunucu 0.0.0.0 üzerinde dinler. Ortamın PORT ve DISABLE_HMR ayarlarını destekler.

## Kontroller

```sh
npm run typecheck
npm run build
npm run preview
```

## Google AI Studio aktarımı

ZIP kökünde package.json, package-lock.json, index.html, vite.config.ts ve src bulunur.
Dosyalar iç içe ek bir proje klasörüne sarılmamıştır.
AI Studio arayüzünde ZIP içe aktarma seçeneği varsa bu paketi kullanın.
Alternatif olarak dosyaları bir GitHub deposuna aktararak Build içindeki GitHub içe aktarmayı kullanın.

İçe aktardıktan sonraki ilk istek:

> Bu mevcut Mevsim Vadisi projesidir. Yeniden oluşturma. Önce npm ci, npm run typecheck ve npm run build komutlarını çalıştır, ardından npm run dev ile önizlemeyi aç. Oyun mantığını, görselleri, ekonomiyi ve mevsim_vadisi_save_v1 kayıt uyumluluğunu koru. Yalnızca açılışı engelleyen bir hata varsa en küçük düzeltmeyi yap ve bildir. Sonraki geliştirme isteğimi bekle.

## Kayıtlar ve kapsam

Oyuncu ilerlemesi tarayıcının localStorage alanındadır. Kaynak ZIP'i bu ilerlemeyi taşımaz.
Başka hesap veya önizleme adresinde eski kayıt kendiliğinden görünmez.
Bu paket node_modules, derleme çıktısı, kişisel sırlar ve geçici ekran görüntüleri içermez.
Fontlar Google Fonts üzerinden yüklenir; bağlantı yoksa yedek fontlar kullanılır.
