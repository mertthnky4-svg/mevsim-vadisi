import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  ClipboardList,
  Home,
  Package,
  Store,
  X,
} from 'lucide-react';
import {
  BuildingInspector,
  GuideResetPanel,
  MineInspector,
  OrdersPanel,
  PlotInspector,
  VillageMarketPanel,
  WarehousePanel,
} from './components/InspectorPanels';
import { ItemIcon } from './components/ItemIcon';
import { Valley3DScene, type SelectedEntity } from './components/Valley3DScene';
import {
  applyFertilizer,
  cancelOrder,
  claimQuestReward,
  collectBuildingProduction,
  collectMineWork,
  deliverVillageResource,
  fulfillOrder,
  getActiveQuest,
  getInventoryUsed,
  getXpProgress,
  harvestPlot,
  plantCrop,
  refreshReadyOrders,
  sellItem,
  startBuildingProduction,
  startMineWork,
  upgradeBuilding,
  upgradeWarehouse,
} from './game/engine';
import { loadGameState, resetSavedGame, saveGameState } from './game/storage';
import type {
  ActionResult,
  BuildingId,
  CropId,
  GameState,
  ItemId,
  MapFocusTarget,
  MineNodeId,
} from './game/types';

type DrawerView =
  | { kind: 'plot'; plotId: number }
  | { kind: 'building'; buildingId: BuildingId }
  | { kind: 'mine'; preferredNode?: MineNodeId }
  | { kind: 'orders' }
  | { kind: 'warehouse' }
  | { kind: 'village_market' }
  | { kind: 'guide' };

interface ToastState {
  id: number;
  ok: boolean;
  message: string;
}

export default function App() {
  const initialLoadRef = useRef<ReturnType<typeof loadGameState> | null>(null);
  if (initialLoadRef.current === null) {
    initialLoadRef.current = loadGameState(Date.now());
  }

  const [state, setState] = useState<GameState>(() => initialLoadRef.current!.state);
  const [now, setNow] = useState<number>(() => Date.now());
  const [drawer, setDrawer] = useState<DrawerView | null>(null);
  const [questCollapsed, setQuestCollapsed] = useState<boolean>(true);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [focusRequest, setFocusRequest] = useState<{ target: MapFocusTarget; seq: number } | null>(
    null
  );

  const toastTimerRef = useRef<number | null>(null);
  const plotHarvestLockRef = useRef<Record<number, number>>({});
  const stateRef = useRef(state);
  stateRef.current = state;

  const showToast = useCallback((ok: boolean, message: string) => {
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    setToast({ id: Date.now(), ok, message });
    toastTimerRef.current = window.setTimeout(() => {
      setToast(null);
    }, 3200);
  }, []);

  useEffect(() => {
    if (initialLoadRef.current?.recoveredFromCorrupt) {
      showToast(false, 'Önceki kayıt bozuktu; çiftlik güvenli şekilde yenilendi.');
    }
  }, [showToast]);

  useEffect(() => {
    saveGameState(state);
  }, [state]);

  useEffect(() => {
    const tick = () => {
      const currentNow = Date.now();
      setNow(currentNow);
      setState((prev) => refreshReadyOrders(prev, currentNow));
    };

    const intervalId = window.setInterval(tick, 500);
    const onVisChange = () => {
      if (document.visibilityState === 'visible') {
        tick();
      }
    };
    document.addEventListener('visibilitychange', onVisChange);

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', onVisChange);
    };
  }, []);

  const runAction = useCallback(
    (updater: (prev: GameState, ts: number) => { state: GameState; result: ActionResult }): ActionResult => {
      const ts = Date.now();
      const outcome = updater(stateRef.current, ts);
      stateRef.current = outcome.state;
      setState(outcome.state);
      setNow(ts);
      if (outcome.result.message) {
        const levelMsg = outcome.result.leveledUpTo
          ? ` Seviye ${outcome.result.leveledUpTo} oldun!`
          : '';
        showToast(outcome.result.ok, `${outcome.result.message}${levelMsg}`);
      }
      return outcome.result;
    },
    [showToast]
  );

  const handleSelectPlot = (plotId: number) => {
    const plot = stateRef.current.plots.find((p) => p.id === plotId);
    if (!plot) return;
    const currentNow = Date.now();
    if (plot.status === 'growing' && plot.completesAt !== null && currentNow >= plot.completesAt) {
      if (currentNow - (plotHarvestLockRef.current[plotId] ?? 0) < 450) {
        return;
      }
      plotHarvestLockRef.current[plotId] = currentNow;
      const res = runAction((prev, ts) => harvestPlot(prev, plotId, ts));
      if (!res.ok && res.message.includes('Depo dolu')) {
        setDrawer({ kind: 'warehouse' });
      }
      return;
    }
    setDrawer({ kind: 'plot', plotId });
  };

  const handleSelectBuilding = (buildingId: BuildingId) => {
    const bState = state.buildings[buildingId];
    const currentNow = Date.now();
    if (
      bState.status === 'producing' &&
      bState.completesAt !== null &&
      currentNow >= bState.completesAt
    ) {
      const res = runAction((prev, ts) => collectBuildingProduction(prev, buildingId, ts));
      if (!res.ok && res.message.includes('Depo dolu')) {
        setDrawer({ kind: 'warehouse' });
      }
      return;
    }
    setDrawer({ kind: 'building', buildingId });
  };

  const handleSelectMine = (preferredNode?: MineNodeId) => {
    const currentNow = Date.now();
    if (
      state.mine.status === 'working' &&
      state.mine.completesAt !== null &&
      currentNow >= state.mine.completesAt
    ) {
      const res = runAction((prev, ts) => collectMineWork(prev, ts));
      if (!res.ok && res.message.includes('Depo dolu')) {
        setDrawer({ kind: 'warehouse' });
      }
      return;
    }
    setDrawer({ kind: 'mine', preferredNode });
  };

  const handleQuestFocus = (target: MapFocusTarget) => {
    setFocusRequest((prev) => ({ target, seq: (prev?.seq ?? 0) + 1 }));
    if (target === 'orders') {
      setDrawer({ kind: 'orders' });
    } else if (target === 'village_market') {
      setDrawer({ kind: 'village_market' });
    } else if (target === 'warehouse') {
      setDrawer({ kind: 'warehouse' });
    } else if (
      target === 'bakery' ||
      target === 'feed_mill' ||
      target === 'coop' ||
      target === 'workshop'
    ) {
      setDrawer({ kind: 'building', buildingId: target });
    } else if (target === 'mine') {
      setDrawer({ kind: 'mine' });
    }
  };

  const activeQuest = getActiveQuest(state);
  const questCompleted = activeQuest ? activeQuest.checkCompleted(state) : false;
  const xpInfo = getXpProgress(state.xp);
  const usedWarehouse = getInventoryUsed(state.inventory);
  const deliverableOrdersCount = state.orders.filter(
    (o) =>
      o.status === 'active' &&
      o.requirements.every((r) => (state.inventory[r.itemId] || 0) >= r.amount)
  ).length;

  const selectedEntity: SelectedEntity =
    drawer?.kind === 'plot'
      ? { kind: 'plot', plotId: drawer.plotId }
      : drawer?.kind === 'building'
        ? { kind: 'building', buildingId: drawer.buildingId }
        : drawer?.kind === 'mine'
          ? { kind: 'mine', nodeId: drawer.preferredNode }
          : drawer?.kind === 'orders'
            ? { kind: 'orders' }
            : drawer?.kind === 'warehouse'
              ? { kind: 'warehouse' }
              : drawer?.kind === 'village_market'
                ? { kind: 'village_market' }
                : null;

  const renderDrawerContent = () => {
    if (!drawer) return null;
    switch (drawer.kind) {
      case 'plot':
        return (
          <PlotInspector
            state={state}
            plotId={drawer.plotId}
            now={now}
            onPlant={(plotId, cropId: CropId) => {
              const res = runAction((prev, ts) => plantCrop(prev, plotId, cropId, ts));
              if (res.ok) setDrawer(null);
            }}
            onFertilize={(plotId) => runAction((prev, ts) => applyFertilizer(prev, plotId, ts))}
            onHarvest={(plotId) => {
              const res = runAction((prev, ts) => harvestPlot(prev, plotId, ts));
              if (res.ok) setDrawer(null);
            }}
          />
        );
      case 'building':
        return (
          <BuildingInspector
            state={state}
            buildingId={drawer.buildingId}
            now={now}
            onStartProduction={(bId) => runAction((prev, ts) => startBuildingProduction(prev, bId, ts))}
            onCollectProduction={(bId) =>
              runAction((prev, ts) => collectBuildingProduction(prev, bId, ts))
            }
            onUpgradeBuilding={(bId) => runAction((prev, ts) => upgradeBuilding(prev, bId, ts))}
          />
        );
      case 'mine':
        return (
          <MineInspector
            state={state}
            preferredNode={drawer.preferredNode}
            now={now}
            onStartMine={(nodeId) => runAction((prev, ts) => startMineWork(prev, nodeId, ts))}
            onCollectMine={() => runAction((prev, ts) => collectMineWork(prev, ts))}
          />
        );
      case 'orders':
        return (
          <OrdersPanel
            state={state}
            now={now}
            onFulfillOrder={(slotIdx) => runAction((prev, ts) => fulfillOrder(prev, slotIdx, ts))}
            onCancelOrder={(slotIdx) => runAction((prev, ts) => cancelOrder(prev, slotIdx, ts))}
          />
        );
      case 'warehouse':
        return (
          <WarehousePanel
            state={state}
            onSellItem={(itemId: ItemId, qty: number) =>
              runAction((prev, ts) => sellItem(prev, itemId, qty, ts))
            }
            onUpgradeWarehouse={() => runAction((prev, ts) => upgradeWarehouse(prev, ts))}
          />
        );
      case 'village_market':
        return (
          <VillageMarketPanel
            state={state}
            onDeliverResource={(itemId, amount) =>
              runAction((prev, ts) => deliverVillageResource(prev, itemId, amount, ts))
            }
          />
        );
      case 'guide':
        return (
          <GuideResetPanel
            state={state}
            onResetGame={() => {
              const fresh = resetSavedGame(Date.now());
              setState(fresh);
              setDrawer(null);
              showToast(true, 'Çiftlik sıfırlandı. Yeni bir başlangıç yaptın!');
            }}
          />
        );
    }
  };

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-[#739747] text-[#2C2A24] overflow-hidden">
      {/* TOP CREAM HUD BAR */}
      <header className="h-14 shrink-0 px-2.5 sm:px-5 bg-[#FBF7EE] border-b-2 border-[#D4C4A8] flex items-center justify-between gap-1.5 sm:gap-2 z-30 shadow-xs">
        {/* Left: Level Star & XP Bar */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0" title="Seviye ve Deneyim">
          <div className="relative flex items-center justify-center">
            <ItemIcon itemId="xp" size={22} />
            <span className="absolute text-[10px] font-bold text-[#FFFDF9] tabular-nums">
              {state.level}
            </span>
          </div>
          <div className="w-11 sm:w-28 h-2.5 sm:h-3 rounded-full bg-[#E6DEC8] border border-[#CBBBA0] overflow-hidden">
            <div
              className="h-full bg-[#4E9643] transition-all duration-300"
              style={{ width: `${Math.round(xpInfo.progressRatio * 100)}%` }}
            />
          </div>
        </div>

        {/* Center: Game Title */}
        <div className="flex items-center gap-1.5 min-w-0">
          <svg width="18" height="14" viewBox="0 0 18 14" fill="none" className="hidden sm:block shrink-0" aria-hidden="true">
            <path d="M16 12C10 12 4 8 2 2C8 2 14 6 16 12Z" fill="#5D874B" />
          </svg>
          <h1 className="font-display text-sm sm:text-xl font-bold tracking-tight text-[#3A2B1C] whitespace-nowrap">
            Mevsim Vadisi
          </h1>
          <svg width="18" height="14" viewBox="0 0 18 14" fill="none" className="hidden sm:block shrink-0" aria-hidden="true">
            <path d="M2 12C8 12 14 8 16 2C10 2 4 6 2 12Z" fill="#5D874B" />
          </svg>
        </div>

        {/* Right: Gold, Warehouse & Guide */}
        <div className="flex items-center gap-1.5 sm:gap-4 shrink-0">
          <div className="flex items-center gap-1" title="Altın">
            <ItemIcon itemId="gold" size={18} />
            <span className="text-xs sm:text-sm font-bold text-[#3A2B1C] tabular-nums whitespace-nowrap">
              {state.gold}
            </span>
          </div>

          <button
            type="button"
            onClick={() => setDrawer({ kind: 'warehouse' })}
            className={`flex items-center gap-1 px-1.5 sm:px-2 py-1 rounded-lg border text-xs font-bold tabular-nums transition-colors min-h-[34px] sm:min-h-[36px] ${
              usedWarehouse >= state.warehouseCapacity
                ? 'border-[#B43F2E] bg-[#FDECE9] text-[#B43F2E]'
                : 'border-[#D4C4A8] bg-[#F4EFE6] text-[#3A2B1C] hover:bg-[#EAE1CE]'
            }`}
            title="Depo Kapasitesi"
          >
            <ItemIcon itemId="warehouse" size={16} />
            <span>
              {usedWarehouse}/{state.warehouseCapacity}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setDrawer({ kind: 'guide' })}
            aria-label="Rehber ve Kayıt Ayarları"
            className="min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] rounded-xl border border-[#D4C4A8] bg-[#FFFDF9] hover:bg-[#F4EFE6] flex items-center justify-center text-[#5E5748] transition-colors"
          >
            <BookOpen className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MAIN 3D VIEWPORT + CONDITIONAL INSPECTOR PANEL */}
      <main className="flex-1 min-h-0 flex relative overflow-hidden">
        <section className="relative flex-1 min-w-0 h-full min-h-0">
          <Valley3DScene
            state={state}
            now={now}
            highlightTarget={activeQuest && !questCompleted ? activeQuest.target : null}
            selectedEntity={selectedEntity}
            focusRequest={focusRequest}
            onSelectPlot={handleSelectPlot}
            onSelectBuilding={handleSelectBuilding}
            onSelectMine={handleSelectMine}
            onSelectOrders={() => setDrawer({ kind: 'orders' })}
            onSelectWarehouse={() => setDrawer({ kind: 'warehouse' })}
            onSelectVillageMarket={() => setDrawer({ kind: 'village_market' })}
          />

          {/* SMALL COLLAPSIBLE ACTIVE QUEST CARD (Compact single line by default, clear of buildings & camera buttons) */}
          {activeQuest && (
            <div className="absolute top-2.5 left-2.5 sm:top-3 sm:left-3 z-20 max-w-[calc(100%-156px)] sm:max-w-xs">
              <div className="rounded-xl bg-[#FBF7EE] border border-[#D4C4A8] shadow-sm overflow-hidden">
                <div className="flex items-center justify-between gap-2 px-2.5 sm:px-3 py-1 bg-[#F4EAD5]">
                  <button
                    type="button"
                    onClick={() => setQuestCollapsed((c) => !c)}
                    className="flex items-center gap-1.5 text-left min-w-0 flex-1 min-h-[28px]"
                    aria-expanded={!questCollapsed}
                  >
                    {questCollapsed ? (
                      <ChevronDown className="w-3.5 h-3.5 text-[#8A5A32] shrink-0" />
                    ) : (
                      <ChevronUp className="w-3.5 h-3.5 text-[#8A5A32] shrink-0" />
                    )}
                    <span className="text-[11px] font-bold text-[#7A4416] truncate">
                      {activeQuest.title}
                    </span>
                  </button>

                  {questCompleted && (
                    <button
                      type="button"
                      onClick={() =>
                        runAction((prev, ts) => claimQuestReward(prev, activeQuest.id, ts))
                      }
                      className="px-2 py-0.5 rounded-lg bg-[#2F6F5E] text-white text-[10px] font-bold whitespace-nowrap shrink-0 tabular-nums"
                    >
                      Ödül (+{activeQuest.goldBonus})
                    </button>
                  )}
                </div>

                {!questCollapsed && (
                  <div className="px-3 py-2 flex items-center justify-between gap-2">
                    <p className="text-[11px] text-[#3A2B1C] leading-snug">
                      {activeQuest.instruction}
                    </p>
                    {!questCompleted && (
                      <button
                        type="button"
                        onClick={() => handleQuestFocus(activeQuest.target)}
                        className="min-h-[32px] px-2.5 py-1 rounded-lg border border-[#D4C4A8] bg-[#FFFDF9] text-[11px] font-semibold text-[#2C2A24] hover:bg-[#F4EFE6] shrink-0 flex items-center gap-0.5"
                      >
                        <span>Göster</span>
                        <ChevronRight className="w-3 h-3 text-[#C86D3B]" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Floating Toast Feedback */}
          {toast && (
            <div className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 z-30 w-[calc(100%-24px)] max-w-sm">
              <div
                className={`rounded-xl px-4 py-2.5 text-xs font-semibold shadow-lg border text-center ${
                  toast.ok
                    ? 'bg-[#2C2A24] text-[#FFFDF9] border-[#4A463B]'
                    : 'bg-[#B43F2E] text-white border-[#8E2E20]'
                }`}
              >
                {toast.message}
              </div>
            </div>
          )}
        </section>

        {/* DESKTOP SIDE INSPECTOR (Opens cleanly only when an item or tab is selected) */}
        {drawer && (
          <aside className="hidden lg:flex flex-col w-[380px] shrink-0 h-full min-h-0 bg-[#FBF7EE] border-l-2 border-[#D4C4A8] z-20 shadow-lg">
            <div className="px-4 py-2.5 border-b border-[#DED4C1] flex items-center justify-between bg-[#F4EAD5]">
              <span className="text-xs font-bold text-[#7A4416]">İşlem Paneli</span>
              <button
                type="button"
                onClick={() => setDrawer(null)}
                aria-label="Paneli kapat"
                className="min-w-[36px] min-h-[36px] rounded-lg flex items-center justify-center text-[#5E5748] hover:bg-[#E6D9BE]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">{renderDrawerContent()}</div>
          </aside>
        )}
      </main>

      {/* UNIFIED CREAM BOTTOM NAVIGATION BAR (Mobile + Desktop) */}
      <nav className="shrink-0 h-16 bg-[#FBF7EE] border-t-2 border-[#D4C4A8] px-2 sm:px-6 flex items-center justify-center z-30">
        <div className="w-full max-w-2xl grid grid-cols-4 divide-x divide-[#DFD3BD]">
          <button
            type="button"
            onClick={() => setDrawer(null)}
            className={`min-h-[48px] flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 text-[11px] sm:text-xs font-bold transition-colors ${
              drawer === null ? 'text-[#2F6F5E]' : 'text-[#5E5748] hover:text-[#2C2A24]'
            }`}
          >
            <Home className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>Çiftlik</span>
          </button>

          <button
            type="button"
            onClick={() => setDrawer({ kind: 'orders' })}
            className={`relative min-h-[48px] flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 text-[11px] sm:text-xs font-bold transition-colors ${
              drawer?.kind === 'orders' ? 'text-[#2F6F5E]' : 'text-[#5E5748] hover:text-[#2C2A24]'
            }`}
          >
            <ClipboardList className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>Siparişler</span>
            {deliverableOrdersCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-[#C86D3B] text-white text-[10px] font-bold tabular-nums">
                {deliverableOrdersCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setDrawer({ kind: 'warehouse' })}
            className={`min-h-[48px] flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 text-[11px] sm:text-xs font-bold transition-colors ${
              drawer?.kind === 'warehouse'
                ? 'text-[#2F6F5E]'
                : 'text-[#5E5748] hover:text-[#2C2A24]'
            }`}
          >
            <Package className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>Depo</span>
          </button>

          <button
            type="button"
            onClick={() => setDrawer({ kind: 'village_market' })}
            className={`min-h-[48px] flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 text-[11px] sm:text-xs font-bold transition-colors ${
              drawer?.kind === 'village_market'
                ? 'text-[#2F6F5E]'
                : 'text-[#5E5748] hover:text-[#2C2A24]'
            }`}
          >
            <Store className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>Köy Pazarı</span>
          </button>
        </div>
      </nav>

      {/* MOBILE BOTTOM SHEET OVERLAY (Solid dark scrim, no backdrop-blur over WebGL) */}
      {drawer && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/45 flex items-end"
          onClick={() => setDrawer(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-h-[82dvh] bg-[#FBF7EE] rounded-t-3xl border-t-2 border-[#D4C4A8] shadow-2xl flex flex-col"
          >
            <div className="shrink-0 pt-2.5 pb-1 px-4 flex items-center justify-between border-b border-[#E6DEC8]">
              <div className="w-10" />
              <div className="w-10 h-1.5 rounded-full bg-[#CFC6B4]" />
              <button
                type="button"
                onClick={() => setDrawer(null)}
                aria-label="Kapat"
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-[#5E5748] hover:bg-[#EAE4D7]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 pb-8">{renderDrawerContent()}</div>
          </div>
        </div>
      )}
    </div>
  );
}
