import * as THREE from 'three';

function createTiledTexture(
  draw: (ctx: CanvasRenderingContext2D, size: number, rand: () => number) => void,
  size: number,
  maxAnisotropy: number,
  repeatX = 1,
  repeatY = 1
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  let seed = 4219;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  if (ctx) {
    draw(ctx, size, rand);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeatX, repeatY);
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export interface GroundPathPoint {
  x: number;
  z: number;
}

export interface GroundMapSpec {
  worldSize: number;
  paths: { pts: GroundPathPoint[]; width: number }[];
  earthPatches: { x: number; z: number; rx: number; rz: number; rot?: number }[];
  grassDarkPatches: { x: number; z: number; r: number }[];
}

function createGroundMapTexture(spec: GroundMapSpec, maxAnisotropy: number): THREE.CanvasTexture {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  const toPx = (w: number) => ((w / spec.worldSize) + 0.5) * size;
  const scalePx = (w: number) => (w / spec.worldSize) * size;

  if (ctx) {
    // Rich Aegean olive-meadow base
    ctx.fillStyle = '#739747';
    ctx.fillRect(0, 0, size, size);

    let seed = 7331;
    const rand = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };

    // Subtle organic meadow tonal variation
    for (let i = 0; i < 520; i++) {
      const gx = rand() * size;
      const gy = rand() * size;
      const gr = 14 + rand() * 44;
      ctx.globalAlpha = 0.09 + rand() * 0.1;
      ctx.fillStyle = rand() > 0.45 ? '#66893D' : '#80A451';
      ctx.beginPath();
      ctx.arc(gx, gy, gr, 0, Math.PI * 2);
      ctx.fill();
    }

    // Lush darker grass under coop, trees & borders
    for (const gp of spec.grassDarkPatches) {
      const px = toPx(gp.x);
      const py = toPx(gp.z);
      const pr = scalePx(gp.r);
      const grad = ctx.createRadialGradient(px, py, pr * 0.2, px, py, pr);
      grad.addColorStop(0, 'rgba(84, 118, 52, 0.72)');
      grad.addColorStop(1, 'rgba(84, 118, 52, 0)');
      ctx.globalAlpha = 1;
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(px, py, pr, 0, Math.PI * 2);
      ctx.fill();
    }

    // Soft compacted earth aprons under barn, feed mill & mine clearing
    for (const ep of spec.earthPatches) {
      const px = toPx(ep.x);
      const py = toPx(ep.z);
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(ep.rot ?? 0);
      ctx.scale(scalePx(ep.rx), scalePx(ep.rz));
      const grad = ctx.createRadialGradient(0, 0, 0.2, 0, 0, 1);
      grad.addColorStop(0, 'rgba(164, 128, 78, 0.88)');
      grad.addColorStop(0.65, 'rgba(155, 118, 70, 0.62)');
      grad.addColorStop(1, 'rgba(155, 118, 70, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Continuous smooth dirt path network with organic grass-blended edges
    ctx.globalAlpha = 1;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const traceCurve = (pts: GroundPathPoint[]) => {
      if (pts.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(toPx(pts[0].x), toPx(pts[0].z));
      if (pts.length === 2) {
        ctx.lineTo(toPx(pts[1].x), toPx(pts[1].z));
      } else {
        for (let i = 1; i < pts.length - 1; i++) {
          const midX = (pts[i].x + pts[i + 1].x) * 0.5;
          const midZ = (pts[i].z + pts[i + 1].z) * 0.5;
          ctx.quadraticCurveTo(toPx(pts[i].x), toPx(pts[i].z), toPx(midX), toPx(midZ));
        }
        const last = pts[pts.length - 1];
        ctx.lineTo(toPx(last.x), toPx(last.z));
      }
    };

    // Pass 1: Wide soft translucent earthy transition into meadow
    for (const p of spec.paths) {
      ctx.strokeStyle = 'rgba(139, 104, 59, 0.34)';
      ctx.lineWidth = scalePx(p.width + 0.62);
      traceCurve(p.pts);
      ctx.stroke();
    }

    // Pass 2: Soft outer dirt border
    for (const p of spec.paths) {
      ctx.strokeStyle = 'rgba(146, 110, 65, 0.78)';
      ctx.lineWidth = scalePx(p.width + 0.24);
      traceCurve(p.pts);
      ctx.stroke();
    }

    // Pass 3: Main warm Aegean packed-dirt path
    for (const p of spec.paths) {
      ctx.strokeStyle = '#B78F59';
      ctx.lineWidth = scalePx(p.width);
      traceCurve(p.pts);
      ctx.stroke();
    }

    // Pass 4: Organic irregular dirt dabs & grass tufts breaking up strict ruler-smooth path margins
    for (const p of spec.paths) {
      const halfW = scalePx(p.width) * 0.5;
      for (let i = 0; i < p.pts.length - 1; i++) {
        const a = p.pts[i];
        const b = p.pts[i + 1];
        const steps = 10;
        for (let s = 0; s <= steps; s++) {
          const t = s / steps;
          const cx = toPx(a.x + (b.x - a.x) * t);
          const cy = toPx(a.z + (b.z - a.z) * t);
          // Dirt speckles on path edge
          for (const side of [-1, 1]) {
            const ang = Math.atan2(b.z - a.z, b.x - a.x) + (Math.PI / 2) * side;
            const edgeR = halfW * (0.85 + rand() * 0.45);
            const ex = cx + Math.cos(ang) * edgeR;
            const ey = cy + Math.sin(ang) * edgeR;
            ctx.fillStyle = rand() > 0.45 ? 'rgba(115, 151, 71, 0.42)' : 'rgba(176, 136, 84, 0.48)';
            ctx.beginPath();
            ctx.arc(ex, ey, 3 + rand() * 5.5, 0, Math.PI * 2);
            ctx.fill();
          }
          // Subtle center soil pebble flecks
          if (rand() > 0.4) {
            ctx.fillStyle = 'rgba(205, 168, 114, 0.45)';
            ctx.beginPath();
            ctx.arc(
              cx + (rand() - 0.5) * halfW * 0.9,
              cy + (rand() - 0.5) * halfW * 0.9,
              2 + rand() * 4,
              0,
              Math.PI * 2
            );
            ctx.fill();
          }
        }
      }
    }

    // Pass 5: Sunlit worn center track
    for (const p of spec.paths) {
      ctx.strokeStyle = 'rgba(202, 166, 114, 0.52)';
      ctx.lineWidth = scalePx(p.width * 0.46);
      traceCurve(p.pts);
      ctx.stroke();
    }

    // Subtle meadow wildflower specks away from paths
    for (let i = 0; i < 240; i++) {
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = rand() > 0.3 ? '#F4E5AE' : '#DCE6B4';
      ctx.fillRect(rand() * size, rand() * size, 2, 2);
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(size / 2, size / 2, size * 0.1, size / 2, size / 2, size * 0.5);
    grad.addColorStop(0, 'rgba(32, 38, 22, 0.42)');
    grad.addColorStop(0.55, 'rgba(32, 38, 22, 0.22)');
    grad.addColorStop(1, 'rgba(32, 38, 22, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface ValleyMaterials {
  groundMeadow: THREE.MeshStandardMaterial;
  grassOuter: THREE.MeshStandardMaterial;
  grassDark: THREE.MeshStandardMaterial;
  cobble: THREE.MeshStandardMaterial;
  soilDry: THREE.MeshStandardMaterial;
  soilWet: THREE.MeshStandardMaterial;
  woodLight: THREE.MeshStandardMaterial;
  woodMid: THREE.MeshStandardMaterial;
  woodDark: THREE.MeshStandardMaterial;
  limestone: THREE.MeshStandardMaterial;
  limestoneWarm: THREE.MeshStandardMaterial;
  stoneMid: THREE.MeshStandardMaterial;
  stoneDark: THREE.MeshStandardMaterial;
  terracotta: THREE.MeshStandardMaterial;
  terracottaDark: THREE.MeshStandardMaterial;
  creamCanvas: THREE.MeshStandardMaterial;
  shutterBlue: THREE.MeshStandardMaterial;
  hayGold: THREE.MeshStandardMaterial;
  waterBlue: THREE.MeshStandardMaterial;
  flowerPink: THREE.MeshStandardMaterial;
  flowerYellow: THREE.MeshStandardMaterial;
  flowerPurple: THREE.MeshStandardMaterial;
  ironMetal: THREE.MeshStandardMaterial;
  copperOre: THREE.MeshStandardMaterial;
  crystalOre: THREE.MeshStandardMaterial;
  oliveLeaf: THREE.MeshStandardMaterial;
  oliveLeafDark: THREE.MeshStandardMaterial;
  cypressLeaf: THREE.MeshStandardMaterial;
  wheatGreen: THREE.MeshStandardMaterial;
  wheatStem: THREE.MeshStandardMaterial;
  wheatLeaf: THREE.MeshStandardMaterial;
  wheatGold: THREE.MeshStandardMaterial;
  cornGreen: THREE.MeshStandardMaterial;
  cornGold: THREE.MeshStandardMaterial;
  chickenWhite: THREE.MeshStandardMaterial;
  chickenAmber: THREE.MeshStandardMaterial;
  chickenComb: THREE.MeshStandardMaterial;
  eggShell: THREE.MeshStandardMaterial;
  tunnelVoid: THREE.MeshStandardMaterial;
  forgeGlow: THREE.MeshStandardMaterial;
  forgeIdle: THREE.MeshStandardMaterial;
  lanternGlow: THREE.MeshBasicMaterial;
  smoke: THREE.MeshStandardMaterial;
  spark: THREE.MeshBasicMaterial;
  contactShadow: THREE.MeshBasicMaterial;
  highlightRing: THREE.MeshBasicMaterial;
  readyRing: THREE.MeshBasicMaterial;
  selectedRing: THREE.MeshBasicMaterial;
  questBorder: THREE.MeshBasicMaterial;
  selectedBorder: THREE.MeshBasicMaterial;
  dispose: () => void;
}

export function createValleyMaterials(
  groundSpec: GroundMapSpec,
  maxAnisotropy: number
): ValleyMaterials {
  const textures: THREE.Texture[] = [];
  const materials: THREE.Material[] = [];

  const trackTex = (tex: THREE.CanvasTexture) => {
    textures.push(tex);
    return tex;
  };
  const trackMat = <T extends THREE.Material>(mat: T): T => {
    materials.push(mat);
    return mat;
  };

  const groundTex = trackTex(createGroundMapTexture(groundSpec, maxAnisotropy));
  const shadowTex = trackTex(createContactShadowTexture());

  const limestoneTex = trackTex(
    createTiledTexture(
      (ctx, size, rand) => {
        ctx.fillStyle = '#E6D9C0';
        ctx.fillRect(0, 0, size, size);
        ctx.strokeStyle = '#C8B89B';
        ctx.lineWidth = 2;
        const rowH = 32;
        for (let y = 0; y < size; y += rowH) {
          const offset = (y / rowH) % 2 === 0 ? 0 : 28;
          for (let x = -32; x < size; x += 56) {
            ctx.fillStyle = rand() > 0.5 ? 'rgba(255, 248, 232, 0.14)' : 'rgba(182, 165, 136, 0.14)';
            ctx.fillRect(x + offset + 2, y + 2, 52, rowH - 4);
            ctx.globalAlpha = 0.45;
            ctx.strokeRect(x + offset, y, 56, rowH);
            ctx.globalAlpha = 1;
          }
        }
      },
      256,
      maxAnisotropy,
      2,
      2
    )
  );

  const cobbleTex = trackTex(
    createTiledTexture(
      (ctx, size, rand) => {
        ctx.fillStyle = '#9E9381';
        ctx.fillRect(0, 0, size, size);
        const step = 32;
        for (let y = 0; y < size; y += step) {
          const off = (y / step) % 2 === 0 ? 0 : 16;
          for (let x = -16; x < size; x += step) {
            const tone = 162 + Math.floor((rand() - 0.5) * 26);
            ctx.fillStyle = `rgb(${tone}, ${tone - 9}, ${tone - 22})`;
            ctx.fillRect(x + off + 3, y + 3, step - 6, step - 6);
          }
        }
      },
      256,
      maxAnisotropy,
      3,
      3
    )
  );

  const woodPlankTex = trackTex(
    createTiledTexture(
      (ctx, size, rand) => {
        ctx.fillStyle = '#B47944';
        ctx.fillRect(0, 0, size, size);
        for (let y = 0; y < size; y += 24) {
          ctx.fillStyle = rand() > 0.5 ? 'rgba(255, 224, 184, 0.1)' : 'rgba(92, 54, 24, 0.12)';
          ctx.fillRect(0, y, size, 23);
          ctx.fillStyle = 'rgba(72, 41, 18, 0.35)';
          ctx.fillRect(0, y + 22, size, 2);
        }
        for (let i = 0; i < 40; i++) {
          ctx.fillStyle = 'rgba(84, 48, 22, 0.14)';
          ctx.fillRect(rand() * size, rand() * size, 30 + rand() * 50, 1.5);
        }
      },
      256,
      maxAnisotropy,
      1.5,
      1.5
    )
  );

  const woodBeamTex = trackTex(
    createTiledTexture(
      (ctx, size, rand) => {
        ctx.fillStyle = '#6B4223';
        ctx.fillRect(0, 0, size, size);
        for (let i = 0; i < 48; i++) {
          ctx.fillStyle = rand() > 0.5 ? 'rgba(42, 24, 10, 0.22)' : 'rgba(130, 88, 52, 0.16)';
          ctx.fillRect(0, rand() * size, size, 2 + rand() * 3);
        }
      },
      128,
      maxAnisotropy,
      1,
      1
    )
  );

  // Organic crumbly dark soil texture (NO wooden/straight plank stripes!)
  const soilTex = trackTex(
    createTiledTexture(
      (ctx, size, rand) => {
        ctx.fillStyle = '#4E341F';
        ctx.fillRect(0, 0, size, size);

        // Mottled dark & warm earthy clods
        for (let i = 0; i < 460; i++) {
          const sx = rand() * size;
          const sy = rand() * size;
          const r = 2 + rand() * 7;
          ctx.fillStyle =
            rand() > 0.52
              ? 'rgba(54, 34, 18, 0.45)'
              : rand() > 0.3
                ? 'rgba(98, 68, 41, 0.36)'
                : 'rgba(122, 88, 54, 0.24)';
          ctx.beginPath();
          ctx.arc(sx, sy, r, 0, Math.PI * 2);
          ctx.fill();
        }

        // Fine soil pebble granules
        for (let i = 0; i < 260; i++) {
          ctx.fillStyle = rand() > 0.5 ? 'rgba(34, 21, 11, 0.42)' : 'rgba(135, 102, 68, 0.28)';
          ctx.beginPath();
          ctx.arc(rand() * size, rand() * size, 1 + rand() * 2, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      256,
      maxAnisotropy,
      1,
      1
    )
  );

  const roofTileTex = trackTex(
    createTiledTexture(
      (ctx, size, rand) => {
        ctx.fillStyle = '#B85A38';
        ctx.fillRect(0, 0, size, size);
        const colW = 24;
        const rowH = 32;
        for (let y = 0; y < size; y += rowH) {
          for (let x = 0; x < size; x += colW) {
            const v = (rand() - 0.5) * 18;
            ctx.fillStyle = `rgb(${Math.round(184 + v)}, ${Math.round(90 + v * 0.6)}, ${Math.round(56 + v * 0.5)})`;
            ctx.fillRect(x + 1, y + 1, colW - 2, rowH - 3);
            ctx.fillStyle = 'rgba(92, 36, 18, 0.28)';
            ctx.fillRect(x, y + rowH - 3, colW, 3);
          }
        }
      },
      256,
      maxAnisotropy,
      2,
      2
    )
  );

  return {
    groundMeadow: trackMat(
      new THREE.MeshStandardMaterial({
        map: groundTex,
        color: 0xffffff,
        roughness: 0.96,
        metalness: 0.0,
        envMapIntensity: 0.2,
      })
    ),
    grassOuter: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x739747,
        roughness: 0.96,
        metalness: 0.0,
        envMapIntensity: 0.2,
      })
    ),
    grassDark: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x5c7f39,
        roughness: 0.94,
        metalness: 0.0,
        envMapIntensity: 0.2,
      })
    ),
    cobble: trackMat(
      new THREE.MeshStandardMaterial({
        map: cobbleTex,
        color: 0xffffff,
        roughness: 0.92,
        metalness: 0.0,
        envMapIntensity: 0.22,
      })
    ),
    soilDry: trackMat(
      new THREE.MeshStandardMaterial({
        map: soilTex,
        color: 0xffffff,
        roughness: 0.98,
        metalness: 0.0,
        envMapIntensity: 0.08,
      })
    ),
    soilWet: trackMat(
      new THREE.MeshStandardMaterial({
        map: soilTex,
        color: 0xb5a495,
        roughness: 0.9,
        metalness: 0.0,
        envMapIntensity: 0.12,
      })
    ),
    woodLight: trackMat(
      new THREE.MeshStandardMaterial({
        map: woodPlankTex,
        color: 0xffffff,
        roughness: 0.84,
        metalness: 0.0,
        envMapIntensity: 0.26,
      })
    ),
    woodMid: trackMat(
      new THREE.MeshStandardMaterial({
        map: woodPlankTex,
        color: 0xe6d4be,
        roughness: 0.86,
        metalness: 0.0,
        envMapIntensity: 0.24,
      })
    ),
    woodDark: trackMat(
      new THREE.MeshStandardMaterial({
        map: woodBeamTex,
        color: 0xffffff,
        roughness: 0.88,
        metalness: 0.0,
        envMapIntensity: 0.22,
      })
    ),
    limestone: trackMat(
      new THREE.MeshStandardMaterial({
        map: limestoneTex,
        color: 0xffffff,
        roughness: 0.9,
        metalness: 0.0,
        envMapIntensity: 0.24,
      })
    ),
    limestoneWarm: trackMat(
      new THREE.MeshStandardMaterial({
        map: limestoneTex,
        color: 0xf2e8d4,
        roughness: 0.92,
        metalness: 0.0,
        envMapIntensity: 0.24,
      })
    ),
    stoneMid: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x8f8576,
        roughness: 0.92,
        metalness: 0.02,
        envMapIntensity: 0.24,
        flatShading: true,
      })
    ),
    stoneDark: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x6f665a,
        roughness: 0.94,
        metalness: 0.02,
        envMapIntensity: 0.22,
        flatShading: true,
      })
    ),
    terracotta: trackMat(
      new THREE.MeshStandardMaterial({
        map: roofTileTex,
        color: 0xffffff,
        roughness: 0.84,
        metalness: 0.0,
        envMapIntensity: 0.24,
      })
    ),
    terracottaDark: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x944328,
        roughness: 0.88,
        metalness: 0.0,
        envMapIntensity: 0.22,
      })
    ),
    creamCanvas: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xece1cb,
        roughness: 0.88,
        metalness: 0.0,
        envMapIntensity: 0.22,
      })
    ),
    shutterBlue: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x3b6e8c,
        roughness: 0.72,
        metalness: 0.02,
        envMapIntensity: 0.35,
      })
    ),
    hayGold: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xdda83c,
        roughness: 0.9,
        metalness: 0.0,
        envMapIntensity: 0.24,
      })
    ),
    waterBlue: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x4f95b5,
        roughness: 0.18,
        metalness: 0.12,
        envMapIntensity: 0.85,
      })
    ),
    flowerPink: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xce4478,
        roughness: 0.8,
        metalness: 0.0,
        envMapIntensity: 0.25,
      })
    ),
    flowerYellow: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xe3b33a,
        roughness: 0.8,
        metalness: 0.0,
        envMapIntensity: 0.25,
      })
    ),
    flowerPurple: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x7e5ba8,
        roughness: 0.8,
        metalness: 0.0,
        envMapIntensity: 0.25,
      })
    ),
    ironMetal: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x4d565e,
        roughness: 0.36,
        metalness: 0.86,
        envMapIntensity: 1.0,
      })
    ),
    copperOre: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xc46733,
        roughness: 0.34,
        metalness: 0.78,
        envMapIntensity: 0.95,
      })
    ),
    crystalOre: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x67a3c2,
        roughness: 0.22,
        metalness: 0.42,
        envMapIntensity: 0.95,
      })
    ),
    oliveLeaf: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x5d7e43,
        roughness: 0.88,
        metalness: 0.0,
        envMapIntensity: 0.2,
      })
    ),
    oliveLeafDark: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x4b6a35,
        roughness: 0.9,
        metalness: 0.0,
        envMapIntensity: 0.18,
      })
    ),
    cypressLeaf: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x3b5c34,
        roughness: 0.9,
        metalness: 0.0,
        envMapIntensity: 0.18,
      })
    ),
    wheatGreen: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x669d3b,
        roughness: 0.84,
        metalness: 0.0,
        envMapIntensity: 0.2,
      })
    ),
    wheatStem: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xd0a23f,
        roughness: 0.82,
        metalness: 0.0,
        envMapIntensity: 0.22,
      })
    ),
    wheatLeaf: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xb1a844,
        roughness: 0.85,
        metalness: 0.0,
        envMapIntensity: 0.2,
      })
    ),
    wheatGold: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xe8b93c,
        roughness: 0.72,
        metalness: 0.02,
        envMapIntensity: 0.28,
      })
    ),
    cornGreen: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x478034,
        roughness: 0.82,
        metalness: 0.0,
        envMapIntensity: 0.22,
      })
    ),
    cornGold: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xebb12c,
        roughness: 0.66,
        metalness: 0.02,
        envMapIntensity: 0.3,
      })
    ),
    chickenWhite: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xf7efe0,
        roughness: 0.8,
        metalness: 0.0,
        envMapIntensity: 0.25,
      })
    ),
    chickenAmber: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xd49148,
        roughness: 0.82,
        metalness: 0.0,
        envMapIntensity: 0.25,
      })
    ),
    chickenComb: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xc23e28,
        roughness: 0.68,
        metalness: 0.0,
        envMapIntensity: 0.25,
      })
    ),
    eggShell: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xf5e8d0,
        roughness: 0.5,
        metalness: 0.0,
        envMapIntensity: 0.3,
      })
    ),
    tunnelVoid: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x171210,
        roughness: 0.98,
        metalness: 0.0,
        envMapIntensity: 0.02,
      })
    ),
    forgeGlow: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xff932c,
        emissive: 0xff5a0d,
        emissiveIntensity: 1.5,
        roughness: 0.45,
      })
    ),
    forgeIdle: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x261f1a,
        roughness: 0.95,
        metalness: 0.0,
        envMapIntensity: 0.06,
      })
    ),
    lanternGlow: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0xffc45c,
      })
    ),
    smoke: trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xebe6dc,
        roughness: 1.0,
        transparent: true,
        opacity: 0.68,
        envMapIntensity: 0.2,
      })
    ),
    spark: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0xffb347,
        transparent: true,
        opacity: 0.9,
      })
    ),
    contactShadow: trackMat(
      new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.72,
      })
    ),
    highlightRing: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0xc86d3b,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9,
      })
    ),
    readyRing: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0x2f6f5e,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.92,
      })
    ),
    selectedRing: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0xf2c144,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95,
      })
    ),
    questBorder: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0xd4713b,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.72,
      })
    ),
    selectedBorder: trackMat(
      new THREE.MeshBasicMaterial({
        color: 0xf4c542,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.96,
      })
    ),
    dispose: () => {
      textures.forEach((t) => t.dispose());
      materials.forEach((m) => m.dispose());
    },
  };
}
