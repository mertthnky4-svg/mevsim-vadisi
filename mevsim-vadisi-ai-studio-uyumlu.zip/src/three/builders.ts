import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { ValleyMaterials } from './materials';

export interface WheatStalkSpec {
  x: number;
  z: number;
  rotY: number;
  leanX: number;
  leanZ: number;
  hScale: number;
  rScale: number;
  phase: number;
}

export interface CornStalkSpec {
  group: THREE.Group;
  baseRotZ: number;
  baseRotX: number;
  phase: number;
  amp: number;
}

export interface PlotRig {
  group: THREE.Group;
  hitMesh: THREE.Mesh;
  soilMesh: THREE.Mesh;
  ridgeMeshes: THREE.Mesh[];
  wheatSproutGroup: THREE.Group;
  cornSproutGroup: THREE.Group;
  wheatReadyGroup: THREE.Group;
  cornReadyGroup: THREE.Group;
  wheatStemInstanced: THREE.InstancedMesh;
  wheatLeafInstanced: THREE.InstancedMesh;
  wheatHeadInstanced: THREE.InstancedMesh;
  wheatStalks: WheatStalkSpec[];
  cornStalks: CornStalkSpec[];
  fertBadge: THREE.Mesh;
  borderMesh: THREE.Mesh;
  questBorderMesh: THREE.Mesh;
}

export interface BuildingRig {
  group: THREE.Group;
  hitMesh: THREE.Mesh;
  ringMesh: THREE.Mesh;
  hearthMesh?: THREE.Mesh;
  ovenLight?: THREE.PointLight;
  smokePuffs?: THREE.Mesh[];
  sailGroup?: THREE.Group;
  henGroups?: { group: THREE.Group; baseX: number; baseZ: number; phase: number }[];
  eggNestGroup?: THREE.Group;
  forgeMesh?: THREE.Mesh;
  forgeLight?: THREE.PointLight;
  sparks?: THREE.Mesh[];
}

export interface MineNodeRig {
  group: THREE.Group;
  hitMesh: THREE.Mesh;
  ringMesh: THREE.Mesh;
  pickaxeGroup: THREE.Group;
}

export interface MarketRig {
  group: THREE.Group;
  hitMesh: THREE.Mesh;
  ringMesh: THREE.Mesh;
  ruinedGroup: THREE.Group;
  repairedGroup: THREE.Group;
}

function enableShadows(obj: THREE.Object3D, cast = true, receive = true) {
  obj.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      child.castShadow = cast;
      child.receiveShadow = receive;
    }
  });
}

function addContactShadow(
  parent: THREE.Group,
  rx: number,
  rz: number,
  x: number,
  z: number,
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
) {
  const geo = new THREE.PlaneGeometry(rx * 2, rz * 2);
  geometries.push(geo);
  const disc = new THREE.Mesh(geo, mats.contactShadow);
  disc.rotation.x = -Math.PI / 2;
  disc.position.set(x, 0.012, z);
  disc.castShadow = false;
  disc.receiveShadow = false;
  disc.renderOrder = 1;
  parent.add(disc);
  return disc;
}

function addFloorRing(radius: number, mat: THREE.Material, geoList: THREE.BufferGeometry[]): THREE.Mesh {
  const geo = new THREE.RingGeometry(radius - 0.1, radius, 40);
  geoList.push(geo);
  const ring = new THREE.Mesh(geo, mat);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.032;
  ring.visible = false;
  return ring;
}

function addTiledGableRoof(
  parent: THREE.Group,
  spanX: number,
  lengthZ: number,
  baseY: number,
  peakHeight: number,
  mats: ValleyMaterials,
  track: <T extends THREE.BufferGeometry>(g: T) => T
) {
  const halfSpan = spanX * 0.54;
  const slopeAngle = Math.atan2(peakHeight, halfSpan);
  const slopeLen = Math.hypot(halfSpan, peakHeight);
  const midY = baseY + peakHeight * 0.5;

  const slopeGeo = track(new THREE.BoxGeometry(slopeLen, 0.12, lengthZ));
  const ribGeo = track(new THREE.BoxGeometry(slopeLen + 0.04, 0.06, 0.08));
  const ribCount = Math.max(4, Math.floor(lengthZ / 0.42));

  for (const side of [-1, 1]) {
    const slopeGroup = new THREE.Group();
    slopeGroup.position.set(side * halfSpan * 0.5, midY, 0);
    slopeGroup.rotation.z = -side * slopeAngle;

    const panel = new THREE.Mesh(slopeGeo, mats.terracotta);
    slopeGroup.add(panel);

    for (let i = 0; i < ribCount; i++) {
      const rz = -lengthZ * 0.44 + (i / Math.max(1, ribCount - 1)) * (lengthZ * 0.88);
      const rib = new THREE.Mesh(ribGeo, mats.terracottaDark);
      rib.position.set(0, 0.075, rz);
      slopeGroup.add(rib);
    }

    // Timber eaves fascia under roof edge
    const fascia = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.1, 0.1, lengthZ - 0.06)),
      mats.woodDark
    );
    fascia.position.set(side * (slopeLen * 0.46), -0.07, 0);
    slopeGroup.add(fascia);

    parent.add(slopeGroup);
  }

  // Terracotta ridge cap along apex
  const ridge = new THREE.Mesh(
    track(new THREE.CylinderGeometry(0.1, 0.1, lengthZ + 0.06, 8)),
    mats.terracottaDark
  );
  ridge.rotation.x = Math.PI / 2;
  ridge.position.set(0, baseY + peakHeight + 0.04, 0);
  parent.add(ridge);
}

interface SharedPlotGeometries {
  beamSideGeo: THREE.BufferGeometry;
  beamFrontGeo: THREE.BufferGeometry;
  postGeo: THREE.BufferGeometry;
  soilGeo: THREE.BufferGeometry;
  furrowGeo: THREE.BufferGeometry;
  clodGeo: THREE.BufferGeometry;
  wSproutBladeGeo: THREE.BufferGeometry;
  cSproutStemGeo: THREE.BufferGeometry;
  cSproutLeafGeo: THREE.BufferGeometry;
  wheatStemGeo: THREE.BufferGeometry;
  wheatLeafGeo: THREE.BufferGeometry;
  wheatHeadGeo: THREE.BufferGeometry;
  cStemGeo: THREE.BufferGeometry;
  cCobGeo: THREE.BufferGeometry;
  cLeafGeo: THREE.BufferGeometry;
  fertBadgeGeo: THREE.BufferGeometry;
  selectedBorderGeo: THREE.BufferGeometry;
  questBorderGeo: THREE.BufferGeometry;
  hitGeo: THREE.BufferGeometry;
}

const sharedPlotGeoCache = new WeakMap<THREE.BufferGeometry[], SharedPlotGeometries>();

function normalizeForMerge(g: THREE.BufferGeometry): THREE.BufferGeometry {
  const nonIndexed = g.index ? g.toNonIndexed() : g;
  if (nonIndexed !== g) g.dispose();
  if (!nonIndexed.attributes.normal) {
    nonIndexed.computeVertexNormals();
  }
  return nonIndexed;
}

function createRectFrameGeo(outerSize: number, thickness: number, height: number): THREE.BufferGeometry {
  const half = outerSize / 2;
  const sideLen = outerSize;
  const n = new THREE.BoxGeometry(sideLen, height, thickness);
  n.translate(0, height / 2, -half + thickness / 2);
  const s = new THREE.BoxGeometry(sideLen, height, thickness);
  s.translate(0, height / 2, half - thickness / 2);
  const w = new THREE.BoxGeometry(thickness, height, sideLen - thickness * 2);
  w.translate(-half + thickness / 2, height / 2, 0);
  const e = new THREE.BoxGeometry(thickness, height, sideLen - thickness * 2);
  e.translate(half - thickness / 2, height / 2, 0);
  const merged = mergeGeometries([n, s, w, e].map(normalizeForMerge), false);
  n.dispose();
  s.dispose();
  w.dispose();
  e.dispose();
  return merged;
}

function createCornerBracketFrameGeo(
  outerSize: number,
  armLen: number,
  thickness: number,
  height: number
): THREE.BufferGeometry {
  const half = outerSize / 2;
  const parts: THREE.BufferGeometry[] = [];
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const bx = new THREE.BoxGeometry(armLen, height, thickness);
      bx.translate(sx * (half - armLen / 2), height / 2, sz * (half - thickness / 2));
      const bz = new THREE.BoxGeometry(thickness, height, armLen - thickness);
      bz.translate(sx * (half - thickness / 2), height / 2, sz * (half - thickness - (armLen - thickness) / 2));
      parts.push(normalizeForMerge(bx), normalizeForMerge(bz));
      bx.dispose();
      bz.dispose();
    }
  }
  const merged = mergeGeometries(parts, false);
  parts.forEach((p) => p.dispose());
  return merged;
}

function createWheatLeavesGeo(): THREE.BufferGeometry {
  const b1 = new THREE.BoxGeometry(0.21, 0.014, 0.042);
  b1.rotateZ(0.52);
  b1.translate(0.088, 0.045, 0.01);

  const b2 = new THREE.BoxGeometry(0.185, 0.014, 0.036);
  b2.rotateY(2.25);
  b2.rotateZ(0.46);
  b2.translate(-0.062, 0.16, -0.036);

  const merged = mergeGeometries([b1, b2].map(normalizeForMerge), false);
  b1.dispose();
  b2.dispose();
  return merged;
}

function createSculptedWheatHeadGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  // Alternating plump spikelet pairs spiraling up the ear + tapered crown tip
  const tierCount = 6;
  for (let i = 0; i < tierCount; i++) {
    const t = i / (tierCount - 1);
    const y = 0.036 + i * 0.046;
    const taper = 1 - t * 0.36;
    for (const side of [-1, 1]) {
      const k = new THREE.OctahedronGeometry(0.046 * taper, 0);
      k.scale(0.86, 1.5, 0.82);
      k.rotateZ(-side * 0.34);
      k.rotateY(i * 0.52);
      k.translate(side * 0.025 * taper, y, (i % 2 === 0 ? 1 : -1) * 0.008);
      parts.push(normalizeForMerge(k));
      k.dispose();
    }
  }
  // Central grain spike & pointed tip
  const tip = new THREE.ConeGeometry(0.028, 0.13, 5);
  tip.translate(0, 0.3, 0);
  parts.push(normalizeForMerge(tip));
  tip.dispose();

  const merged = mergeGeometries(parts, false);
  parts.forEach((p) => p.dispose());
  return merged;
}

function getSharedPlotGeometries(geometriesToDispose: THREE.BufferGeometry[]): SharedPlotGeometries {
  const cached = sharedPlotGeoCache.get(geometriesToDispose);
  if (cached) return cached;

  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometriesToDispose.push(g);
    return g;
  };

  const bedSize = 2.42;
  const frameH = 0.085;
  const railW = 0.072;

  const furrowGeo = new THREE.CylinderGeometry(0.085, 0.115, 0.98, 7);
  furrowGeo.rotateZ(Math.PI / 2);

  const wheatStemGeo = new THREE.CylinderGeometry(0.015, 0.026, 0.72, 5);
  wheatStemGeo.translate(0, 0.36, 0);

  const shared: SharedPlotGeometries = {
    beamSideGeo: track(new THREE.BoxGeometry(bedSize, frameH, railW)),
    beamFrontGeo: track(new THREE.BoxGeometry(railW, frameH, bedSize)),
    postGeo: track(new THREE.BoxGeometry(0.11, 0.12, 0.11)),
    soilGeo: track(new THREE.BoxGeometry(bedSize - 0.14, 0.065, bedSize - 0.14)),
    furrowGeo: track(furrowGeo),
    clodGeo: track(new THREE.DodecahedronGeometry(0.065, 0)),
    wSproutBladeGeo: track(new THREE.ConeGeometry(0.04, 0.48, 5)),
    cSproutStemGeo: track(new THREE.CylinderGeometry(0.034, 0.052, 0.48, 6)),
    cSproutLeafGeo: track(new THREE.BoxGeometry(0.28, 0.034, 0.1)),
    wheatStemGeo: track(wheatStemGeo),
    wheatLeafGeo: track(createWheatLeavesGeo()),
    wheatHeadGeo: track(createSculptedWheatHeadGeo()),
    cStemGeo: track(new THREE.CylinderGeometry(0.04, 0.066, 1.18, 6)),
    cCobGeo: track(new THREE.CapsuleGeometry(0.085, 0.21, 4, 7)),
    cLeafGeo: track(new THREE.BoxGeometry(0.42, 0.036, 0.12)),
    fertBadgeGeo: track(new THREE.OctahedronGeometry(0.13, 0)),
    selectedBorderGeo: track(createRectFrameGeo(bedSize + 0.14, 0.075, 0.042)),
    questBorderGeo: track(createCornerBracketFrameGeo(bedSize + 0.2, 0.48, 0.055, 0.035)),
    hitGeo: track(new THREE.BoxGeometry(bedSize + 0.12, 1.25, bedSize + 0.12)),
  };

  sharedPlotGeoCache.set(geometriesToDispose, shared);
  return shared;
}

const _stalkDummy = new THREE.Object3D();
const _stalkUp = new THREE.Vector3();

export function animatePlotCrops(rig: PlotRig, elapsed: number, plotIdx: number) {
  if (rig.wheatReadyGroup.visible) {
    const count = rig.wheatStalks.length;
    for (let i = 0; i < count; i++) {
      const s = rig.wheatStalks[i];
      const swayX =
        Math.sin(elapsed * 2.15 + s.phase + plotIdx * 0.7) * 0.052 +
        Math.sin(elapsed * 3.8 + s.phase * 1.9) * 0.016;
      const swayZ = Math.cos(elapsed * 1.85 + s.phase * 1.25 + plotIdx * 0.5) * 0.044;

      // Stem
      _stalkDummy.position.set(s.x, 0, s.z);
      _stalkDummy.rotation.set(s.leanX + swayX, s.rotY, s.leanZ + swayZ);
      _stalkDummy.scale.set(s.rScale, s.hScale, s.rScale);
      _stalkDummy.updateMatrix();
      rig.wheatStemInstanced.setMatrixAt(i, _stalkDummy.matrix);

      // Leaf collar anchored ~35% up the tilted stem
      _stalkUp.set(0, 0.25 * s.hScale, 0).applyQuaternion(_stalkDummy.quaternion);
      _stalkDummy.position.set(s.x + _stalkUp.x, _stalkUp.y, s.z + _stalkUp.z);
      _stalkDummy.scale.set(s.rScale, 1, s.rScale);
      _stalkDummy.updateMatrix();
      rig.wheatLeafInstanced.setMatrixAt(i, _stalkDummy.matrix);

      // Sculpted grain head seated at top of stem with gentle extra bow
      _stalkUp.set(0, 0.69 * s.hScale, 0).applyQuaternion(_stalkDummy.quaternion);
      _stalkDummy.position.set(s.x + _stalkUp.x, _stalkUp.y, s.z + _stalkUp.z);
      _stalkDummy.rotation.set(
        s.leanX * 1.25 + swayX * 1.32 + 0.06,
        s.rotY,
        s.leanZ * 1.25 + swayZ * 1.32
      );
      _stalkDummy.scale.set(s.rScale, 0.92 + s.hScale * 0.14, s.rScale);
      _stalkDummy.updateMatrix();
      rig.wheatHeadInstanced.setMatrixAt(i, _stalkDummy.matrix);
    }
    rig.wheatStemInstanced.instanceMatrix.needsUpdate = true;
    rig.wheatLeafInstanced.instanceMatrix.needsUpdate = true;
    rig.wheatHeadInstanced.instanceMatrix.needsUpdate = true;
  }

  if (rig.cornReadyGroup.visible) {
    for (let i = 0; i < rig.cornStalks.length; i++) {
      const cs = rig.cornStalks[i];
      cs.group.rotation.z =
        cs.baseRotZ + Math.sin(elapsed * 1.9 + cs.phase + plotIdx * 0.8) * cs.amp;
      cs.group.rotation.x =
        cs.baseRotX + Math.cos(elapsed * 1.65 + cs.phase * 1.15) * (cs.amp * 0.75);
    }
  }
}

export function createPlot3D(
  plotId: number,
  mats: ValleyMaterials,
  geometriesToDispose: THREE.BufferGeometry[]
): PlotRig {
  const geos = getSharedPlotGeometries(geometriesToDispose);
  const group = new THREE.Group();
  const bedSize = 2.42;
  const frameH = 0.085;
  const railW = 0.072;

  // Slim, low wooden trim strictly on outer perimeter
  const north = new THREE.Mesh(geos.beamSideGeo, mats.woodMid);
  north.position.set(0, frameH / 2, -bedSize / 2 + railW / 2);
  const south = north.clone();
  south.position.z = bedSize / 2 - railW / 2;
  const west = new THREE.Mesh(geos.beamFrontGeo, mats.woodMid);
  west.position.set(-bedSize / 2 + railW / 2, frameH / 2, 0);
  const east = west.clone();
  east.position.x = bedSize / 2 - railW / 2;
  group.add(north, south, west, east);

  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const post = new THREE.Mesh(geos.postGeo, mats.woodDark);
      post.position.set(sx * (bedSize / 2 - 0.045), 0.06, sz * (bedSize / 2 - 0.045));
      group.add(post);
    }
  }

  // Deep matte dark tilled soil bed
  const soilMesh = new THREE.Mesh(geos.soilGeo, mats.soilDry);
  soilMesh.position.y = 0.032;
  group.add(soilMesh);

  // Soft, uneven, rounded earth furrow mounds + small organic clods
  let seed = 1307 + plotId * 313;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  const ridgeMeshes: THREE.Mesh[] = [];
  const rowZs = [-0.74, -0.37, 0, 0.37, 0.74];

  for (const baseZ of rowZs) {
    for (const halfX of [-0.5, 0.5]) {
      const mound = new THREE.Mesh(geos.furrowGeo, mats.soilDry);
      mound.position.set(
        halfX + (rand() - 0.5) * 0.06,
        0.048 + rand() * 0.008,
        baseZ + (rand() - 0.5) * 0.035
      );
      mound.scale.set(
        0.92 + rand() * 0.16,
        0.42 + rand() * 0.12,
        1.15 + rand() * 0.25
      );
      mound.rotation.y = (rand() - 0.5) * 0.06;
      ridgeMeshes.push(mound);
      group.add(mound);
    }

    for (let c = 0; c < 3; c++) {
      const clod = new THREE.Mesh(geos.clodGeo, mats.soilDry);
      clod.position.set(
        (rand() - 0.5) * 1.78,
        0.068,
        baseZ + (rand() - 0.5) * 0.14
      );
      clod.scale.set(0.9 + rand() * 0.7, 0.45 + rand() * 0.25, 0.8 + rand() * 0.6);
      clod.rotation.set(rand() * 0.5, rand() * Math.PI, rand() * 0.5);
      ridgeMeshes.push(clod);
      group.add(clod);
    }
  }

  // Growing Wheat Sprouts: staggered tufts of slender upright light-green blades
  const wheatSproutGroup = new THREE.Group();
  wheatSproutGroup.position.y = 0.075;
  for (let ix = 0; ix < 4; ix++) {
    for (let iz = 0; iz < 4; iz++) {
      const stagger = iz % 2 === 0 ? -0.07 : 0.07;
      const px = THREE.MathUtils.clamp(-0.72 + ix * 0.48 + stagger + (rand() - 0.5) * 0.07, -0.84, 0.84);
      const pz = THREE.MathUtils.clamp(-0.72 + iz * 0.48 + (rand() - 0.5) * 0.07, -0.82, 0.82);
      const tuft = new THREE.Group();
      tuft.position.set(px, 0, pz);
      for (let b = 0; b < 4; b++) {
        const blade = new THREE.Mesh(geos.wSproutBladeGeo, mats.wheatGreen);
        const ang = (b / 4) * Math.PI * 2 + rand() * 0.4;
        blade.position.set(Math.cos(ang) * 0.055, 0.21, Math.sin(ang) * 0.055);
        blade.rotation.z = -Math.cos(ang) * 0.26;
        blade.rotation.x = Math.sin(ang) * 0.26;
        tuft.add(blade);
      }
      wheatSproutGroup.add(tuft);
    }
  }
  wheatSproutGroup.visible = false;
  group.add(wheatSproutGroup);

  // Growing Corn Sprouts: sturdier broader deeper-green shoots in 3x3 rows
  const cornSproutGroup = new THREE.Group();
  cornSproutGroup.position.y = 0.075;
  for (const px of [-0.64, 0, 0.64]) {
    for (const pz of [-0.6, 0, 0.6]) {
      const shoot = new THREE.Group();
      shoot.position.set(px, 0, pz);
      const s = new THREE.Mesh(geos.cSproutStemGeo, mats.cornGreen);
      s.position.y = 0.24;
      const l1 = new THREE.Mesh(geos.cSproutLeafGeo, mats.cornGreen);
      l1.position.set(0.11, 0.3, 0);
      l1.rotation.z = 0.42;
      const l2 = new THREE.Mesh(geos.cSproutLeafGeo, mats.cornGreen);
      l2.position.set(-0.11, 0.26, 0.04);
      l2.rotation.z = -0.38;
      const l3 = new THREE.Mesh(geos.cSproutLeafGeo, mats.cornGreen);
      l3.position.set(0, 0.38, -0.09);
      l3.rotation.y = Math.PI / 2;
      l3.rotation.z = 0.34;
      shoot.add(s, l1, l2, l3);
      cornSproutGroup.add(shoot);
    }
  }
  cornSproutGroup.visible = false;
  group.add(cornSproutGroup);

  // Ready Wheat: InstancedMesh stems, leaves, and sculpted grain heads along furrow rows
  // Deterministic layout leaving tilled dark earth visible and staying strictly inside plot bounds
  const wheatReadyGroup = new THREE.Group();
  wheatReadyGroup.position.y = 0.075;

  const wheatStalks: WheatStalkSpec[] = [];
  for (let r = 0; r < rowZs.length; r++) {
    const baseZ = rowZs[r];
    const cols = r % 2 === 0 ? 8 : 9;
    for (let c = 0; c < cols; c++) {
      const u = c / (cols - 1);
      const rawX = -0.82 + u * 1.64 + (rand() - 0.5) * 0.1;
      const rawZ = baseZ + (rand() - 0.5) * 0.1;
      const x = THREE.MathUtils.clamp(rawX, -0.84, 0.84);
      const z = THREE.MathUtils.clamp(rawZ, -0.80, 0.80);
      wheatStalks.push({
        x,
        z,
        rotY: rand() * Math.PI * 2,
        leanX: (rand() - 0.5) * 0.16,
        leanZ: (rand() - 0.5) * 0.16,
        hScale: 0.78 + rand() * 0.38,
        rScale: 0.86 + rand() * 0.26,
        phase: rand() * Math.PI * 2 + x * 1.35 + z * 1.05,
      });
    }
  }

  const stalkCount = wheatStalks.length;
  const wheatStemInstanced = new THREE.InstancedMesh(geos.wheatStemGeo, mats.wheatStem, stalkCount);
  const wheatLeafInstanced = new THREE.InstancedMesh(geos.wheatLeafGeo, mats.wheatLeaf, stalkCount);
  const wheatHeadInstanced = new THREE.InstancedMesh(geos.wheatHeadGeo, mats.wheatGold, stalkCount);
  wheatStemInstanced.frustumCulled = false;
  wheatLeafInstanced.frustumCulled = false;
  wheatHeadInstanced.frustumCulled = false;
  wheatReadyGroup.add(wheatStemInstanced, wheatLeafInstanced, wheatHeadInstanced);
  wheatReadyGroup.visible = true; // populate initial matrices cleanly, then hide
  group.add(wheatReadyGroup);

  // Ready Corn (tall green stalks, leaves, yellow cobs — individually swaying & bounded inside plot)
  const cornReadyGroup = new THREE.Group();
  cornReadyGroup.position.y = 0.08;
  const cornStalks: CornStalkSpec[] = [];
  for (const px of [-0.64, 0, 0.64]) {
    for (const pz of [-0.6, 0, 0.6]) {
      const stalk = new THREE.Group();
      stalk.position.set(px + (rand() - 0.5) * 0.05, 0, pz + (rand() - 0.5) * 0.05);
      stalk.rotation.y = (rand() - 0.5) * 1.4;
      const hScale = 0.9 + rand() * 0.2;
      stalk.scale.set(1, hScale, 1);

      const stem = new THREE.Mesh(geos.cStemGeo, mats.cornGreen);
      stem.position.y = 0.59;
      const cob = new THREE.Mesh(geos.cCobGeo, mats.cornGold);
      cob.position.set(0.11, 0.7, 0);
      cob.rotation.z = -0.35;
      const lf1 = new THREE.Mesh(geos.cLeafGeo, mats.cornGreen);
      lf1.position.set(-0.16, 0.78, 0);
      lf1.rotation.z = 0.3;
      const lf2 = new THREE.Mesh(geos.cLeafGeo, mats.cornGreen);
      lf2.position.set(0.15, 0.92, 0.04);
      lf2.rotation.z = -0.25;
      stalk.add(stem, cob, lf1, lf2);
      cornReadyGroup.add(stalk);

      cornStalks.push({
        group: stalk,
        baseRotZ: (rand() - 0.5) * 0.06,
        baseRotX: (rand() - 0.5) * 0.06,
        phase: rand() * Math.PI * 2 + px * 1.2 + pz * 0.9,
        amp: 0.032 + rand() * 0.02,
      });
    }
  }
  cornReadyGroup.visible = false;
  group.add(cornReadyGroup);

  const fertBadge = new THREE.Mesh(geos.fertBadgeGeo, mats.wheatGreen);
  fertBadge.position.set(bedSize / 2 - 0.06, 0.26, bedSize / 2 - 0.06);
  fertBadge.visible = false;
  group.add(fertBadge);

  // Distinct rectangular perimeter highlights (no big green circles on ready plots!)
  const borderMesh = new THREE.Mesh(geos.selectedBorderGeo, mats.selectedBorder);
  borderMesh.position.y = 0.02;
  borderMesh.visible = false;
  group.add(borderMesh);

  const questBorderMesh = new THREE.Mesh(geos.questBorderGeo, mats.questBorder);
  questBorderMesh.position.y = 0.022;
  questBorderMesh.visible = false;
  group.add(questBorderMesh);

  const hitMesh = new THREE.Mesh(
    geos.hitGeo,
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 0.6;
  hitMesh.userData = { targetType: 'plot', plotId };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  borderMesh.castShadow = false;
  borderMesh.receiveShadow = false;
  questBorderMesh.castShadow = false;
  questBorderMesh.receiveShadow = false;

  const rig: PlotRig = {
    group,
    hitMesh,
    soilMesh,
    ridgeMeshes,
    wheatSproutGroup,
    cornSproutGroup,
    wheatReadyGroup,
    cornReadyGroup,
    wheatStemInstanced,
    wheatLeafInstanced,
    wheatHeadInstanced,
    wheatStalks,
    cornStalks,
    fertBadge,
    borderMesh,
    questBorderMesh,
  };

  animatePlotCrops(rig, 0, plotId);
  wheatReadyGroup.visible = false;

  return rig;
}

export function createBakery3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): BuildingRig {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  addContactShadow(group, 2.55, 2.25, 0.05, 0.25, mats, geometries);

  // Compact rectangular stone hearth apron ONLY in front (no circular white pad)
  const frontApron = new THREE.Mesh(track(new THREE.BoxGeometry(3.4, 0.06, 1.85)), mats.cobble);
  frontApron.position.set(0.2, 0.03, 1.15);
  group.add(frontApron);

  // Warm cream limestone masonry base
  const base = new THREE.Mesh(track(new THREE.BoxGeometry(3.0, 0.95, 2.55)), mats.limestone);
  base.position.set(-0.2, 0.48, -0.2);
  group.add(base);

  // Stepped stone bakery dome (authentic Aegean brick/stone oven silhouette)
  const domeCourse1 = new THREE.Mesh(track(new THREE.CylinderGeometry(1.18, 1.32, 0.42, 14)), mats.limestoneWarm);
  domeCourse1.position.set(-0.2, 1.16, -0.2);
  const domeCourse2 = new THREE.Mesh(track(new THREE.CylinderGeometry(0.92, 1.16, 0.38, 14)), mats.stoneMid);
  domeCourse2.position.set(-0.2, 1.54, -0.2);
  const domeTop = new THREE.Mesh(track(new THREE.SphereGeometry(0.92, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2)), mats.limestoneWarm);
  domeTop.scale.set(1, 0.65, 1);
  domeTop.position.set(-0.2, 1.72, -0.2);
  const domeCap = new THREE.Mesh(track(new THREE.CylinderGeometry(0.32, 0.42, 0.16, 12)), mats.stoneMid);
  domeCap.position.set(-0.2, 2.34, -0.2);
  group.add(domeCourse1, domeCourse2, domeTop, domeCap);

  // Stone chimney
  const chimney = new THREE.Mesh(track(new THREE.CylinderGeometry(0.2, 0.26, 1.1, 10)), mats.limestone);
  chimney.position.set(-0.25, 2.7, -0.58);
  const chimneyRim = new THREE.Mesh(track(new THREE.BoxGeometry(0.5, 0.1, 0.5)), mats.terracottaDark);
  chimneyRim.position.set(-0.25, 3.24, -0.58);
  group.add(chimney, chimneyRim);

  // Terracotta ribbed porch awning over front hearth
  const awningGroup = new THREE.Group();
  awningGroup.position.set(-0.15, 1.65, 1.25);
  awningGroup.rotation.x = 0.3;
  const awningBase = new THREE.Mesh(track(new THREE.BoxGeometry(2.65, 0.11, 1.45)), mats.terracotta);
  awningGroup.add(awningBase);
  for (let i = -3; i <= 3; i++) {
    const rib = new THREE.Mesh(track(new THREE.BoxGeometry(0.08, 0.05, 1.48)), mats.terracottaDark);
    rib.position.set(i * 0.36, 0.07, 0);
    awningGroup.add(rib);
  }
  const beamGeo = track(new THREE.BoxGeometry(0.14, 1.52, 0.14));
  const bL = new THREE.Mesh(beamGeo, mats.woodDark);
  bL.position.set(-1.26, 0.76, 1.72);
  const bR = bL.clone();
  bR.position.x = 0.96;
  group.add(awningGroup, bL, bR);

  // Pronounced arched stone hearth mouth + recessed dark firebox
  const archFrame = new THREE.Mesh(track(new THREE.BoxGeometry(1.32, 1.05, 0.42)), mats.stoneMid);
  archFrame.position.set(-0.18, 0.56, 1.06);
  const archTop = new THREE.Mesh(track(new THREE.CylinderGeometry(0.56, 0.56, 0.44, 12)), mats.stoneMid);
  archTop.rotation.x = Math.PI / 2;
  archTop.position.set(-0.18, 0.98, 1.06);
  const hearthMesh = new THREE.Mesh(track(new THREE.BoxGeometry(0.76, 0.66, 0.24)), mats.forgeIdle);
  hearthMesh.position.set(-0.18, 0.48, 1.24);
  group.add(archFrame, archTop, hearthMesh);

  const ovenLight = new THREE.PointLight(0xff8c2b, 0, 5.5, 2);
  ovenLight.position.set(-0.18, 0.65, 1.55);
  group.add(ovenLight);

  // Wooden bread display table + golden loaves + flour sack
  const tableTop = new THREE.Mesh(track(new THREE.BoxGeometry(1.05, 0.09, 0.62)), mats.woodLight);
  tableTop.position.set(1.42, 0.62, 0.96);
  const legGeo = track(new THREE.BoxGeometry(0.09, 0.6, 0.09));
  for (const [lx, lz] of [
    [1.0, 0.72],
    [1.84, 0.72],
    [1.0, 1.2],
    [1.84, 1.2],
  ]) {
    const leg = new THREE.Mesh(legGeo, mats.woodDark);
    leg.position.set(lx, 0.3, lz);
    group.add(leg);
  }
  const loafGeo = track(new THREE.SphereGeometry(0.16, 8, 8));
  for (const lx of [1.18, 1.44, 1.7]) {
    const loaf = new THREE.Mesh(loafGeo, mats.cornGold);
    loaf.scale.set(1.15, 0.62, 0.85);
    loaf.position.set(lx, 0.73, 0.96);
    group.add(loaf);
  }
  const sack = new THREE.Mesh(track(new THREE.SphereGeometry(0.24, 10, 8)), mats.creamCanvas);
  sack.scale.set(0.95, 1.2, 0.9);
  sack.position.set(0.72, 0.28, 1.58);
  group.add(tableTop, sack);

  // Bougainvillea climbing beside bakery stone wall
  const shrub = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.45, 1)), mats.oliveLeafDark);
  shrub.position.set(-1.7, 0.5, 0.35);
  const bloom = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.26, 0)), mats.flowerPink);
  bloom.position.set(-1.76, 0.92, 0.5);
  group.add(shrub, bloom);

  // Chimney smoke puffs
  const smokePuffs: THREE.Mesh[] = [];
  const puffGeo = track(new THREE.SphereGeometry(0.18, 8, 8));
  for (let i = 0; i < 3; i++) {
    const puff = new THREE.Mesh(puffGeo, mats.smoke);
    puff.position.set(-0.25, 3.55 + i * 0.45, -0.58);
    puff.visible = false;
    smokePuffs.push(puff);
    group.add(puff);
  }

  const ringMesh = addFloorRing(2.45, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(4.2, 3.5, 4.0)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 1.75;
  hitMesh.userData = { targetType: 'building', buildingId: 'bakery' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  smokePuffs.forEach((p) => (p.castShadow = false));

  return { group, hitMesh, ringMesh, hearthMesh, ovenLight, smokePuffs };
}

export function createWarehouse3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): { group: THREE.Group; hitMesh: THREE.Mesh; ringMesh: THREE.Mesh } {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  addContactShadow(group, 2.35, 2.15, 0, 0.1, mats, geometries);

  // Stone masonry plinth foundation (no circular pad!)
  const stoneBase = new THREE.Mesh(track(new THREE.BoxGeometry(3.35, 0.32, 2.75)), mats.limestone);
  stoneBase.position.y = 0.16;
  const walls = new THREE.Mesh(track(new THREE.BoxGeometry(3.15, 1.65, 2.55)), mats.woodLight);
  walls.position.y = 1.14;
  group.add(stoneBase, walls);

  // Dark structural corner posts & gable wall beams
  const beamGeo = track(new THREE.BoxGeometry(0.16, 1.72, 0.16));
  for (const sx of [-1.54, 1.54]) {
    for (const sz of [-1.24, 1.24]) {
      const post = new THREE.Mesh(beamGeo, mats.woodDark);
      post.position.set(sx, 1.14, sz);
      group.add(post);
    }
  }

  // Ribbed terracotta tiled gable roof
  addTiledGableRoof(group, 3.35, 2.95, 1.96, 0.98, mats, track);

  // Dark recessed barn doorway + stacked golden hay bales clearly visible inside
  const doorway = new THREE.Mesh(track(new THREE.BoxGeometry(1.25, 1.38, 0.24)), mats.tunnelVoid);
  doorway.position.set(0, 1.0, 1.22);
  const hayBale1 = new THREE.Mesh(track(new THREE.BoxGeometry(0.62, 0.42, 0.48)), mats.hayGold);
  hayBale1.position.set(0.14, 0.52, 1.2);
  const hayBale2 = hayBale1.clone();
  hayBale2.position.set(-0.22, 0.52, 1.18);
  const hayBaleTop = hayBale1.clone();
  hayBaleTop.position.set(-0.04, 0.94, 1.16);

  // Big ajar double timber barn doors with crossbars
  const doorLeafGeo = track(new THREE.BoxGeometry(0.58, 1.38, 0.1));
  const dL = new THREE.Mesh(doorLeafGeo, mats.woodDark);
  dL.position.set(-0.84, 1.0, 1.46);
  dL.rotation.y = -0.68;
  const dR = new THREE.Mesh(doorLeafGeo, mats.woodDark);
  dR.position.set(0.84, 1.0, 1.46);
  dR.rotation.y = 0.68;
  group.add(doorway, hayBale1, hayBale2, hayBaleTop, dL, dR);

  // Barrels & flour sack beside barn entrance
  const barrelGeo = track(new THREE.CylinderGeometry(0.22, 0.2, 0.58, 10));
  const b1 = new THREE.Mesh(barrelGeo, mats.woodDark);
  b1.position.set(-1.42, 0.29, 1.22);
  const b2 = new THREE.Mesh(barrelGeo, mats.woodMid);
  b2.position.set(-1.82, 0.29, 0.92);
  const sack = new THREE.Mesh(track(new THREE.SphereGeometry(0.26, 10, 8)), mats.creamCanvas);
  sack.scale.set(1, 1.2, 0.9);
  sack.position.set(1.38, 0.3, 1.28);
  group.add(b1, b2, sack);

  const ringMesh = addFloorRing(2.4, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(3.8, 3.2, 3.4)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 1.6;
  hitMesh.userData = { targetType: 'warehouse' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  return { group, hitMesh, ringMesh };
}

export function createFeedMill3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): BuildingRig {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  addContactShadow(group, 1.85, 1.85, 0, 0.1, mats, geometries);

  // Warm limestone stone cylinder tower + stone plinth ring (no white pad!)
  const stonePlinth = new THREE.Mesh(track(new THREE.CylinderGeometry(1.38, 1.46, 0.28, 12)), mats.stoneMid);
  stonePlinth.position.y = 0.14;
  const tower = new THREE.Mesh(track(new THREE.CylinderGeometry(0.92, 1.28, 2.55, 12)), mats.limestone);
  tower.position.y = 1.48;
  const roofTrim = new THREE.Mesh(track(new THREE.CylinderGeometry(1.06, 1.02, 0.14, 12)), mats.woodDark);
  roofTrim.position.y = 2.75;
  const cap = new THREE.Mesh(track(new THREE.ConeGeometry(1.22, 1.12, 12)), mats.terracotta);
  cap.position.y = 3.35;
  const capFinial = new THREE.Mesh(track(new THREE.SphereGeometry(0.14, 8, 8)), mats.terracottaDark);
  capFinial.position.y = 3.92;
  group.add(stonePlinth, tower, roofTrim, cap, capFinial);

  // Arched dark timber doorway + front wooden grain hopper chute
  const door = new THREE.Mesh(track(new THREE.BoxGeometry(0.56, 1.0, 0.18)), mats.woodDark);
  door.position.set(-0.34, 0.62, 1.14);
  const hopper = new THREE.Mesh(track(new THREE.BoxGeometry(1.06, 0.68, 0.78)), mats.woodLight);
  hopper.position.set(0.38, 0.42, 1.28);
  const hopperRim = new THREE.Mesh(track(new THREE.BoxGeometry(1.14, 0.1, 0.86)), mats.woodDark);
  hopperRim.position.set(0.38, 0.78, 1.28);
  const grain = new THREE.Mesh(track(new THREE.BoxGeometry(0.84, 0.14, 0.56)), mats.hayGold);
  grain.position.set(0.38, 0.84, 1.28);
  group.add(door, hopper, hopperRim, grain);

  // Rotating 4-sail windmill rotor with visible axle shaft connecting to tower
  const sailGroup = new THREE.Group();
  sailGroup.position.set(0, 2.38, 1.16);
  const shaft = new THREE.Mesh(track(new THREE.CylinderGeometry(0.1, 0.1, 0.55, 8)), mats.woodDark);
  shaft.rotation.x = Math.PI / 2;
  shaft.position.z = -0.18;
  const hub = new THREE.Mesh(track(new THREE.CylinderGeometry(0.18, 0.18, 0.24, 10)), mats.woodDark);
  hub.rotation.x = Math.PI / 2;
  sailGroup.add(shaft, hub);

  const sparGeo = track(new THREE.BoxGeometry(0.1, 1.52, 0.08));
  const crossGeo = track(new THREE.BoxGeometry(0.46, 0.06, 0.05));
  const canvasGeo = track(new THREE.BoxGeometry(0.42, 1.08, 0.035));
  for (let i = 0; i < 4; i++) {
    const blade = new THREE.Group();
    blade.rotation.z = (i * Math.PI) / 2;
    const spar = new THREE.Mesh(sparGeo, mats.woodDark);
    spar.position.y = 0.78;
    const crossbar = new THREE.Mesh(crossGeo, mats.woodDark);
    crossbar.position.set(0.22, 1.42, 0.02);
    const cloth = new THREE.Mesh(canvasGeo, mats.creamCanvas);
    cloth.position.set(0.22, 0.88, 0.025);
    blade.add(spar, crossbar, cloth);
    sailGroup.add(blade);
  }
  group.add(sailGroup);

  const ringMesh = addFloorRing(2.0, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(3.2, 4.1, 3.2)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 2.05;
  hitMesh.userData = { targetType: 'building', buildingId: 'feed_mill' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  return { group, hitMesh, ringMesh, sailGroup };
}

function createHen3D(
  isWhite: boolean,
  mats: ValleyMaterials,
  track: <T extends THREE.BufferGeometry>(g: T) => T,
  geometries: THREE.BufferGeometry[]
): THREE.Group {
  const hen = new THREE.Group();
  const bodyMat = isWhite ? mats.chickenWhite : mats.chickenAmber;

  addContactShadow(hen, 0.28, 0.28, 0, 0, mats, geometries);

  const body = new THREE.Mesh(track(new THREE.SphereGeometry(0.23, 10, 8)), bodyMat);
  body.scale.set(0.95, 0.88, 1.25);
  body.position.y = 0.24;

  const tail = new THREE.Mesh(track(new THREE.ConeGeometry(0.11, 0.22, 6)), bodyMat);
  tail.rotation.x = -0.7;
  tail.position.set(0, 0.36, -0.24);

  const head = new THREE.Mesh(track(new THREE.SphereGeometry(0.135, 8, 8)), bodyMat);
  head.position.set(0, 0.44, 0.21);

  const beak = new THREE.Mesh(track(new THREE.ConeGeometry(0.042, 0.1, 6)), mats.cornGold);
  beak.rotation.x = Math.PI / 2;
  beak.position.set(0, 0.42, 0.34);

  const comb = new THREE.Mesh(track(new THREE.BoxGeometry(0.042, 0.075, 0.11)), mats.chickenComb);
  comb.position.set(0, 0.56, 0.19);

  hen.add(body, tail, head, beak, comb);
  return hen;
}

export function createCoop3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): BuildingRig {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  // Natural polygonal wooden fence posts & two horizontal rails (directly on meadow grass—no bright pad!)
  const fencePts: [number, number][] = [
    [-2.05, -1.55],
    [0.2, -1.85],
    [2.25, -1.15],
    [2.4, 0.88],
    [1.05, 2.02],
    [-1.35, 1.85],
    [-2.32, 0.38],
  ];
  const postGeo = track(new THREE.BoxGeometry(0.13, 0.66, 0.13));
  for (let i = 0; i < fencePts.length; i++) {
    const [x1, z1] = fencePts[i];
    const [x2, z2] = fencePts[(i + 1) % fencePts.length];
    const post = new THREE.Mesh(postGeo, mats.woodDark);
    post.position.set(x1, 0.33, z1);
    group.add(post);

    const len = Math.hypot(x2 - x1, z2 - z1);
    const rail = new THREE.Mesh(track(new THREE.BoxGeometry(len, 0.075, 0.055)), mats.woodMid);
    rail.position.set((x1 + x2) / 2, 0.46, (z1 + z2) / 2);
    rail.rotation.y = -Math.atan2(z2 - z1, x2 - x1);
    const railLow = rail.clone();
    railLow.position.y = 0.24;
    group.add(rail, railLow);
  }

  // Elevated wooden Coop House at back-right of yard
  const coopHouse = new THREE.Group();
  coopHouse.position.set(0.65, 0, -0.52);
  coopHouse.rotation.y = -0.35;
  addContactShadow(coopHouse, 1.35, 1.15, 0, 0.1, mats, geometries);

  // Corner stilt legs
  const legGeo = track(new THREE.BoxGeometry(0.14, 0.36, 0.14));
  for (const sx of [-0.72, 0.72]) {
    for (const sz of [-0.62, 0.62]) {
      const leg = new THREE.Mesh(legGeo, mats.woodDark);
      leg.position.set(sx, 0.18, sz);
      coopHouse.add(leg);
    }
  }

  const coopBody = new THREE.Mesh(track(new THREE.BoxGeometry(1.7, 1.05, 1.48)), mats.woodLight);
  coopBody.position.y = 0.84;
  coopHouse.add(coopBody);

  addTiledGableRoof(coopHouse, 1.9, 1.75, 1.36, 0.66, mats, track);

  const coopDoor = new THREE.Mesh(track(new THREE.BoxGeometry(0.5, 0.62, 0.1)), mats.tunnelVoid);
  coopDoor.position.set(0, 0.66, 0.74);

  // Wooden ramp
  const ramp = new THREE.Mesh(track(new THREE.BoxGeometry(0.48, 0.07, 0.98)), mats.woodDark);
  ramp.position.set(0, 0.24, 1.12);
  ramp.rotation.x = 0.42;

  // Side nesting box + eggs
  const nestBox = new THREE.Mesh(track(new THREE.BoxGeometry(0.52, 0.44, 0.92)), mats.woodDark);
  nestBox.position.set(-1.08, 0.6, 0);
  const nestStraw = new THREE.Mesh(track(new THREE.BoxGeometry(0.42, 0.11, 0.8)), mats.hayGold);
  nestStraw.position.set(-1.08, 0.84, 0);

  const eggNestGroup = new THREE.Group();
  eggNestGroup.position.set(-1.08, 0.94, 0);
  const eggGeo = track(new THREE.SphereGeometry(0.105, 8, 8));
  for (const ez of [-0.22, 0, 0.22]) {
    const egg = new THREE.Mesh(eggGeo, mats.eggShell);
    egg.scale.set(0.9, 1.2, 0.9);
    egg.position.set(0, 0, ez);
    eggNestGroup.add(egg);
  }
  eggNestGroup.visible = false;

  coopHouse.add(coopDoor, ramp, nestBox, nestStraw, eggNestGroup);
  group.add(coopHouse);

  // Feed trough & stone water bowl
  const trough = new THREE.Mesh(track(new THREE.BoxGeometry(0.84, 0.2, 0.34)), mats.woodDark);
  trough.position.set(-0.62, 0.1, 0.94);
  const feedFill = new THREE.Mesh(track(new THREE.BoxGeometry(0.7, 0.08, 0.24)), mats.hayGold);
  feedFill.position.set(-0.62, 0.2, 0.94);
  const bowlRim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.26, 0.22, 0.14, 12)), mats.stoneMid);
  bowlRim.position.set(0.55, 0.07, 1.12);
  const waterDisc = new THREE.Mesh(track(new THREE.CylinderGeometry(0.2, 0.2, 0.05, 12)), mats.waterBlue);
  waterDisc.position.set(0.55, 0.13, 1.12);
  group.add(trough, feedFill, bowlRim, waterDisc);

  // 3 Animated Hens inside yard
  const henConfigs = [
    { isWhite: true, x: -1.08, z: 0.25, phase: 0.0 },
    { isWhite: false, x: -0.22, z: 1.32, phase: 2.1 },
    { isWhite: true, x: 1.28, z: 0.62, phase: 4.2 },
  ];
  const henGroups = henConfigs.map((hc) => {
    const hg = createHen3D(hc.isWhite, mats, track, geometries);
    hg.position.set(hc.x, 0.01, hc.z);
    group.add(hg);
    return { group: hg, baseX: hc.x, baseZ: hc.z, phase: hc.phase };
  });

  const ringMesh = addFloorRing(2.65, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(5.0, 2.2, 4.2)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 1.1;
  hitMesh.userData = { targetType: 'building', buildingId: 'coop' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  return { group, hitMesh, ringMesh, henGroups, eggNestGroup };
}

export function createWorkshop3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): BuildingRig {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  addContactShadow(group, 2.45, 2.15, 0, 0.1, mats, geometries);

  // Compact rectangular stone cobble floor ONLY under smithy work area (no circular white platform)
  const cobbleFloor = new THREE.Mesh(track(new THREE.BoxGeometry(3.8, 0.07, 2.95)), mats.cobble);
  cobbleFloor.position.set(0, 0.035, 0.12);
  group.add(cobbleFloor);

  // Open-front & open-right stone/timber smithy (solid backWall + back-left sideWall)
  const backWall = new THREE.Mesh(track(new THREE.BoxGeometry(3.2, 1.85, 0.3)), mats.limestone);
  backWall.position.set(0, 0.96, -0.96);
  const sideWall = new THREE.Mesh(track(new THREE.BoxGeometry(0.3, 1.85, 2.15)), mats.limestone);
  sideWall.position.set(-1.45, 0.96, 0);
  group.add(backWall, sideWall);

  // Heavy dark timber posts supporting roof
  const postGeo = track(new THREE.BoxGeometry(0.18, 1.85, 0.18));
  for (const [px, pz] of [
    [-1.45, 1.05],
    [1.45, 1.05],
    [1.45, -0.95],
  ]) {
    const p = new THREE.Mesh(postGeo, mats.woodDark);
    p.position.set(px, 0.96, pz);
    group.add(p);
  }

  // Ribbed terracotta tiled gable roof + stone chimney
  addTiledGableRoof(group, 3.35, 2.65, 1.88, 0.78, mats, track);
  const chimney = new THREE.Mesh(track(new THREE.BoxGeometry(0.52, 1.15, 0.52)), mats.limestone);
  chimney.position.set(-0.85, 2.45, -0.62);
  group.add(chimney);

  // Stone Forge Hearth clearly visible inside open smithy
  const forgeBase = new THREE.Mesh(track(new THREE.BoxGeometry(1.05, 0.92, 0.88)), mats.stoneMid);
  forgeBase.position.set(-0.45, 0.5, -0.35);
  const forgeHood = new THREE.Mesh(track(new THREE.BoxGeometry(1.12, 0.65, 0.82)), mats.stoneDark);
  forgeHood.position.set(-0.45, 1.55, -0.45);
  const forgeMesh = new THREE.Mesh(track(new THREE.BoxGeometry(0.62, 0.34, 0.52)), mats.forgeIdle);
  forgeMesh.position.set(-0.45, 0.92, -0.14);
  const forgeLight = new THREE.PointLight(0xff7d29, 0, 5.5, 2);
  forgeLight.position.set(-0.45, 1.08, 0.22);
  group.add(forgeBase, forgeHood, forgeMesh, forgeLight);

  // Heavy dark-iron anvil on wooden stump clearly visible in front-center opening
  const stump = new THREE.Mesh(track(new THREE.CylinderGeometry(0.28, 0.32, 0.46, 10)), mats.woodDark);
  stump.position.set(0.45, 0.26, 0.62);
  const anvilBody = new THREE.Mesh(track(new THREE.BoxGeometry(0.72, 0.25, 0.34)), mats.ironMetal);
  anvilBody.position.set(0.45, 0.62, 0.62);
  const anvilHorn = new THREE.Mesh(track(new THREE.ConeGeometry(0.12, 0.38, 8)), mats.ironMetal);
  anvilHorn.rotation.z = -Math.PI / 2;
  anvilHorn.position.set(0.9, 0.64, 0.62);
  group.add(stump, anvilBody, anvilHorn);

  // Back wall tool rack
  const rackBar = new THREE.Mesh(track(new THREE.BoxGeometry(1.35, 0.09, 0.08)), mats.woodDark);
  rackBar.position.set(0.45, 1.32, -0.76);
  group.add(rackBar);
  for (const tx of [0.0, 0.42, 0.84]) {
    const toolHandle = new THREE.Mesh(track(new THREE.BoxGeometry(0.055, 0.42, 0.055)), mats.woodLight);
    toolHandle.position.set(tx, 1.12, -0.74);
    const toolHead = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.09, 0.075)), mats.ironMetal);
    toolHead.position.set(tx, 1.32, -0.74);
    group.add(toolHandle, toolHead);
  }

  // Oak barrels
  const barrelGeo = track(new THREE.CylinderGeometry(0.23, 0.21, 0.58, 10));
  const b1 = new THREE.Mesh(barrelGeo, mats.woodDark);
  b1.position.set(-1.38, 0.32, 0.92);
  const b2 = new THREE.Mesh(barrelGeo, mats.woodMid);
  b2.position.set(1.32, 0.32, 0.92);
  group.add(b1, b2);

  // Sparks when forging
  const sparks: THREE.Mesh[] = [];
  const sparkGeo = track(new THREE.BoxGeometry(0.07, 0.07, 0.07));
  for (let i = 0; i < 4; i++) {
    const sp = new THREE.Mesh(sparkGeo, mats.spark);
    sp.position.set(0.5, 0.88, 0.44);
    sp.visible = false;
    sparks.push(sp);
    group.add(sp);
  }

  const ringMesh = addFloorRing(2.35, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(3.8, 2.8, 3.2)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 1.4;
  hitMesh.userData = { targetType: 'building', buildingId: 'workshop' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  sparks.forEach((s) => (s.castShadow = false));
  return { group, hitMesh, ringMesh, forgeMesh, forgeLight, sparks };
}

export function createMineArea3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): {
  portalGroup: THREE.Group;
  portalHitMesh: THREE.Mesh;
  nodes: Record<'stone_ridge' | 'iron_vein' | 'mixed_boulder', MineNodeRig>;
} {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };

  // Low, stepped faceted rocky hillside backdrop (replaces giant round rock blob!)
  const portalGroup = new THREE.Group();
  addContactShadow(portalGroup, 3.6, 2.4, 0, -0.35, mats, geometries);

  const rockClusters: {
    x: number;
    y: number;
    z: number;
    sx: number;
    sy: number;
    sz: number;
    ry: number;
    mat: THREE.Material;
  }[] = [
    // Low terraced backdrop behind tunnel entrance (never overpowering the farm!)
    { x: -2.4, y: 0.72, z: -0.9, sx: 1.45, sy: 0.95, sz: 1.1, ry: 0.4, mat: mats.stoneMid },
    { x: -1.4, y: 1.1, z: -1.4, sx: 1.25, sy: 1.25, sz: 1.1, ry: -0.3, mat: mats.stoneDark },
    { x: -0.1, y: 1.35, z: -1.65, sx: 1.5, sy: 1.35, sz: 1.15, ry: 0.25, mat: mats.stoneDark },
    { x: 1.35, y: 1.15, z: -1.35, sx: 1.35, sy: 1.25, sz: 1.1, ry: 0.8, mat: mats.stoneMid },
    { x: 2.45, y: 0.78, z: -0.85, sx: 1.4, sy: 0.95, sz: 1.1, ry: -0.5, mat: mats.stoneDark },
    // Lower foreground shoulder rocks flanking tunnel frame
    { x: -1.75, y: 0.45, z: 0.05, sx: 0.95, sy: 0.68, sz: 0.85, ry: 0.7, mat: mats.stoneDark },
    { x: 1.75, y: 0.48, z: 0.05, sx: 0.95, sy: 0.72, sz: 0.85, ry: -0.6, mat: mats.stoneMid },
    // Upper crest angular crags
    { x: -0.7, y: 1.75, z: -2.0, sx: 0.95, sy: 1.05, sz: 0.85, ry: 0.9, mat: mats.stoneMid },
    { x: 0.75, y: 1.8, z: -1.95, sx: 1.05, sy: 1.1, sz: 0.9, ry: -0.4, mat: mats.stoneDark },
    { x: -2.95, y: 0.42, z: -0.35, sx: 0.88, sy: 0.58, sz: 0.78, ry: 0.3, mat: mats.stoneDark },
    { x: 3.0, y: 0.44, z: -0.25, sx: 0.88, sy: 0.6, sz: 0.82, ry: -0.7, mat: mats.stoneMid },
  ];

  const cragGeo = track(new THREE.DodecahedronGeometry(0.95, 0));
  for (const rc of rockClusters) {
    const crag = new THREE.Mesh(cragGeo, rc.mat);
    crag.position.set(rc.x, rc.y, rc.z);
    crag.scale.set(rc.sx, rc.sy, rc.sz);
    crag.rotation.set(0.12, rc.ry, 0.08);
    portalGroup.add(crag);
  }

  // Small Mediterranean hillside tufts tucked cleanly onto rock ledges
  const ledgeBushGeo = track(new THREE.DodecahedronGeometry(0.32, 1));
  for (const [bx, by, bz] of [
    [-2.05, 1.38, -0.95],
    [1.85, 1.45, -0.95],
    [0.05, 2.25, -1.55],
  ]) {
    const bush = new THREE.Mesh(ledgeBushGeo, mats.oliveLeafDark);
    bush.position.set(bx, by, bz);
    portalGroup.add(bush);
  }

  // Clearly open dark tunnel mouth framed by heavy dark timber posts, braces & lintel
  const caveRecess = new THREE.Mesh(track(new THREE.BoxGeometry(1.52, 1.56, 1.2)), mats.tunnelVoid);
  caveRecess.position.set(0, 0.78, 0.12);
  const caveBack = new THREE.Mesh(track(new THREE.BoxGeometry(1.65, 1.7, 0.35)), mats.stoneDark);
  caveBack.position.set(0, 0.85, -0.55);

  const postGeo = track(new THREE.BoxGeometry(0.24, 1.72, 0.24));
  const postL = new THREE.Mesh(postGeo, mats.woodDark);
  postL.position.set(-0.88, 0.86, 0.72);
  const postR = postL.clone();
  postR.position.x = 0.88;

  const lintel = new THREE.Mesh(track(new THREE.BoxGeometry(2.26, 0.26, 0.32)), mats.woodDark);
  lintel.position.set(0, 1.78, 0.72);
  const crossLog = new THREE.Mesh(track(new THREE.BoxGeometry(2.05, 0.18, 0.24)), mats.woodMid);
  crossLog.position.set(0, 2.0, 0.65);

  // Diagonal timber knee braces
  const braceGeo = track(new THREE.BoxGeometry(0.14, 0.58, 0.14));
  const braceL = new THREE.Mesh(braceGeo, mats.woodDark);
  braceL.position.set(-0.66, 1.46, 0.72);
  braceL.rotation.z = -0.68;
  const braceR = new THREE.Mesh(braceGeo, mats.woodDark);
  braceR.position.set(0.66, 1.46, 0.72);
  braceR.rotation.z = 0.68;

  // Two small warm mine lanterns hanging on front timber posts
  const lanternGeo = track(new THREE.SphereGeometry(0.1, 8, 8));
  const lanL = new THREE.Mesh(lanternGeo, mats.lanternGlow);
  lanL.position.set(-0.88, 1.38, 0.88);
  const lanR = new THREE.Mesh(lanternGeo, mats.lanternGlow);
  lanR.position.set(0.88, 1.38, 0.88);

  // Short steel rail track with wooden sleepers extending cleanly out of tunnel
  const railGeo = track(new THREE.BoxGeometry(0.075, 0.055, 1.85));
  const railL = new THREE.Mesh(railGeo, mats.ironMetal);
  railL.position.set(-0.3, 0.045, 1.32);
  const railR = railL.clone();
  railR.position.x = 0.3;
  const tieGeo = track(new THREE.BoxGeometry(0.88, 0.04, 0.11));
  for (const tz of [0.68, 1.05, 1.42, 1.79, 2.12]) {
    const tie = new THREE.Mesh(tieGeo, mats.woodDark);
    tie.position.set(0, 0.02, tz);
    portalGroup.add(tie);
  }

  // Small dark-iron minecart filled with stone chunks on forward rail end
  const cartBody = new THREE.Mesh(track(new THREE.BoxGeometry(0.68, 0.38, 0.78)), mats.ironMetal);
  cartBody.position.set(0, 0.33, 1.76);
  const cartOre1 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.22, 0)), mats.stoneMid);
  cartOre1.position.set(-0.08, 0.54, 1.72);
  const cartOre2 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.17, 0)), mats.stoneDark);
  cartOre2.position.set(0.13, 0.52, 1.82);

  portalGroup.add(
    caveRecess,
    caveBack,
    postL,
    postR,
    lintel,
    crossLog,
    braceL,
    braceR,
    lanL,
    lanR,
    railL,
    railR,
    cartBody,
    cartOre1,
    cartOre2
  );

  const portalHitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(3.8, 2.5, 3.2)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  portalHitMesh.position.set(0, 1.25, 0.4);
  portalHitMesh.userData = { targetType: 'mine' };
  portalHitMesh.layers.set(1);
  portalGroup.add(portalHitMesh);
  enableShadows(portalGroup, true, true);
  lanL.castShadow = false;
  lanR.castShadow = false;

  const buildNode = (
    nodeId: 'stone_ridge' | 'iron_vein' | 'mixed_boulder',
    kind: 'stone' | 'iron' | 'mixed'
  ): MineNodeRig => {
    const group = new THREE.Group();
    addContactShadow(group, 0.95, 0.88, 0, 0, mats, geometries);

    if (kind === 'stone') {
      const b1 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.58, 0)), mats.stoneMid);
      b1.scale.set(1.15, 0.82, 0.95);
      b1.position.set(0, 0.36, 0);
      b1.rotation.y = 0.4;
      const b2 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.42, 0)), mats.limestoneWarm);
      b2.position.set(0.32, 0.45, -0.15);
      b2.rotation.set(0.2, -0.5, 0.25);
      const b3 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.32, 0)), mats.stoneDark);
      b3.position.set(-0.4, 0.22, 0.28);
      group.add(b1, b2, b3);
    } else if (kind === 'iron') {
      const baseRock = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.62, 0)), mats.stoneDark);
      baseRock.scale.set(1.18, 0.85, 0.98);
      baseRock.position.y = 0.4;
      group.add(baseRock);
      const oreGeo = track(new THREE.OctahedronGeometry(0.22, 0));
      for (const [ox, oy, oz] of [
        [-0.28, 0.66, 0.32],
        [0.28, 0.58, 0.36],
        [0.04, 0.84, 0.04],
        [0.45, 0.36, -0.18],
      ]) {
        const ore = new THREE.Mesh(oreGeo, mats.copperOre);
        ore.position.set(ox, oy, oz);
        ore.rotation.set(ox, oy, oz);
        group.add(ore);
      }
    } else {
      const boulder = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.64, 0)), mats.stoneDark);
      boulder.scale.set(1.1, 0.88, 1.0);
      boulder.position.y = 0.42;
      const shelf = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.38, 0)), mats.stoneMid);
      shelf.position.set(-0.32, 0.22, 0.32);
      group.add(boulder, shelf);
      const crystalGeo = track(new THREE.ConeGeometry(0.14, 0.46, 5));
      for (const [cx, cy, cz, rz] of [
        [0.14, 0.82, 0.18, -0.25],
        [0.36, 0.62, -0.08, -0.55],
        [-0.2, 0.74, -0.12, 0.35],
      ]) {
        const crys = new THREE.Mesh(crystalGeo, mats.crystalOre);
        crys.position.set(cx, cy, cz);
        crys.rotation.z = rz;
        group.add(crys);
      }
    }

    const pickaxeGroup = new THREE.Group();
    pickaxeGroup.position.set(0, 1.32, 0);
    const handle = new THREE.Mesh(track(new THREE.CylinderGeometry(0.045, 0.045, 0.82, 6)), mats.woodDark);
    const head = new THREE.Mesh(track(new THREE.BoxGeometry(0.58, 0.11, 0.11)), mats.ironMetal);
    head.position.y = 0.38;
    pickaxeGroup.add(handle, head);
    pickaxeGroup.visible = false;
    group.add(pickaxeGroup);

    const ringMesh = addFloorRing(1.22, mats.highlightRing, geometries);
    group.add(ringMesh);

    const hitMesh = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.9, 1.6, 1.85)),
      new THREE.MeshBasicMaterial({ visible: false })
    );
    hitMesh.position.y = 0.8;
    hitMesh.userData = { targetType: 'mine', nodeId };
    hitMesh.layers.set(1);
    group.add(hitMesh);

    enableShadows(group, true, true);
    ringMesh.castShadow = false;
    return { group, hitMesh, ringMesh, pickaxeGroup };
  };

  return {
    portalGroup,
    portalHitMesh,
    nodes: {
      stone_ridge: buildNode('stone_ridge', 'stone'),
      iron_vein: buildNode('iron_vein', 'iron'),
      mixed_boulder: buildNode('mixed_boulder', 'mixed'),
    },
  };
}

export function createOrderBoard3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): { group: THREE.Group; hitMesh: THREE.Mesh; ringMesh: THREE.Mesh } {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  addContactShadow(group, 1.1, 0.65, 0, 0, mats, geometries);

  const postGeo = track(new THREE.BoxGeometry(0.14, 1.75, 0.14));
  const pL = new THREE.Mesh(postGeo, mats.woodDark);
  pL.position.set(-0.78, 0.88, 0);
  const pR = pL.clone();
  pR.position.x = 0.78;

  const board = new THREE.Mesh(track(new THREE.BoxGeometry(1.75, 1.05, 0.1)), mats.woodLight);
  board.position.set(0, 1.2, 0);

  const cap = new THREE.Mesh(track(new THREE.BoxGeometry(2.05, 0.14, 0.38)), mats.terracotta);
  cap.position.set(0, 1.8, 0);

  const noteGeo = track(new THREE.BoxGeometry(0.5, 0.62, 0.04));
  const n1 = new THREE.Mesh(noteGeo, mats.creamCanvas);
  n1.position.set(-0.38, 1.2, 0.07);
  n1.rotation.z = 0.06;
  const n2 = new THREE.Mesh(noteGeo, mats.creamCanvas);
  n2.position.set(0.38, 1.18, 0.07);
  n2.rotation.z = -0.05;

  group.add(pL, pR, board, cap, n1, n2);

  const ringMesh = addFloorRing(1.38, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(2.2, 2.1, 1.5)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 1.05;
  hitMesh.userData = { targetType: 'orders' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  return { group, hitMesh, ringMesh };
}

export function createVillageMarket3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): MarketRig {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const group = new THREE.Group();

  // Muted warm Aegean stone cobble plaza (never bright white)
  const plaza = new THREE.Mesh(track(new THREE.BoxGeometry(5.9, 0.08, 4.9)), mats.cobble);
  plaza.position.y = 0.04;
  group.add(plaza);

  // RUINED STATE (readable Aegean village market shell + repair materials matching repaired layout)
  const ruinedGroup = new THREE.Group();

  // Left Market Building Shell: low broken cream limestone walls + stone floor & rubble + askew blue shutter
  const leftBackWall = new THREE.Mesh(track(new THREE.BoxGeometry(2.25, 1.65, 0.28)), mats.limestone);
  leftBackWall.position.set(-1.55, 0.88, -2.05);
  const leftSideWall = new THREE.Mesh(track(new THREE.BoxGeometry(0.28, 1.55, 1.75)), mats.limestone);
  leftSideWall.position.set(-2.54, 0.83, -1.3);
  const leftFrontLower = new THREE.Mesh(track(new THREE.BoxGeometry(2.1, 0.82, 0.24)), mats.limestoneWarm);
  leftFrontLower.position.set(-1.55, 0.47, -0.5);
  const leftUpperCorner = new THREE.Mesh(track(new THREE.BoxGeometry(0.95, 0.85, 0.28)), mats.limestone);
  leftUpperCorner.position.set(-2.15, 1.68, -1.78);
  const leftFloor = new THREE.Mesh(track(new THREE.BoxGeometry(1.85, 0.08, 1.35)), mats.stoneDark);
  leftFloor.position.set(-1.55, 0.09, -1.25);
  const leftRubble1 = new THREE.Mesh(track(new THREE.BoxGeometry(0.45, 0.24, 0.34)), mats.limestoneWarm);
  leftRubble1.position.set(-1.95, 0.24, -1.45);
  leftRubble1.rotation.y = 0.35;
  const leftRubble2 = new THREE.Mesh(track(new THREE.BoxGeometry(0.38, 0.28, 0.36)), mats.woodMid);
  leftRubble2.position.set(-1.05, 0.26, -1.15);
  leftRubble2.rotation.y = -0.25;

  const shutterAskew = new THREE.Mesh(track(new THREE.BoxGeometry(0.46, 0.56, 0.07)), mats.shutterBlue);
  shutterAskew.position.set(-2.02, 1.22, -0.35);
  shutterAskew.rotation.z = -0.18;

  // Exposed dark timber roof rafters + small intact corner patch of terracotta tiles
  const rafterGeo = track(new THREE.BoxGeometry(0.11, 0.11, 1.95));
  for (const rx of [-2.4, -1.85, -1.3, -0.75]) {
    const rafter = new THREE.Mesh(rafterGeo, mats.woodDark);
    rafter.position.set(rx, 1.88, -1.28);
    rafter.rotation.x = 0.12;
    ruinedGroup.add(rafter);
  }
  const ridgeBeam = new THREE.Mesh(track(new THREE.BoxGeometry(2.25, 0.14, 0.14)), mats.woodDark);
  ridgeBeam.position.set(-1.55, 2.02, -1.35);
  const roofPatch = new THREE.Mesh(track(new THREE.BoxGeometry(1.05, 0.11, 1.05)), mats.terracotta);
  roofPatch.position.set(-2.1, 1.98, -1.55);
  roofPatch.rotation.z = 0.28;

  // Right Market Shop Shell: low stepped limestone corner + boarded entrance planks
  const rightBackWall = new THREE.Mesh(track(new THREE.BoxGeometry(2.15, 1.25, 0.28)), mats.limestoneWarm);
  rightBackWall.position.set(1.25, 0.68, -2.02);
  const rightSideWall = new THREE.Mesh(track(new THREE.BoxGeometry(0.28, 1.05, 1.55)), mats.limestone);
  rightSideWall.position.set(2.22, 0.58, -1.32);
  const rightStepWall = new THREE.Mesh(track(new THREE.BoxGeometry(0.95, 0.52, 0.28)), mats.limestone);
  rightStepWall.position.set(1.85, 1.52, -2.02);
  const rightDoorPlank1 = new THREE.Mesh(track(new THREE.BoxGeometry(1.1, 0.14, 0.08)), mats.woodMid);
  rightDoorPlank1.position.set(1.15, 0.65, -0.72);
  rightDoorPlank1.rotation.z = 0.08;
  const rightDoorPlank2 = new THREE.Mesh(track(new THREE.BoxGeometry(1.05, 0.14, 0.08)), mats.woodDark);
  rightDoorPlank2.position.set(1.2, 0.92, -0.72);
  rightDoorPlank2.rotation.z = -0.1;

  // Closed & boarded Market Stall in front-left courtyard (mirrors repaired left stall)
  const closedStallBody = new THREE.Mesh(track(new THREE.BoxGeometry(1.75, 0.62, 0.72)), mats.woodMid);
  closedStallBody.position.set(-1.5, 0.36, 0.35);
  const foldedTarp = new THREE.Mesh(track(new THREE.CylinderGeometry(0.11, 0.11, 1.55, 8)), mats.creamCanvas);
  foldedTarp.rotation.z = Math.PI / 2;
  foldedTarp.position.set(-1.5, 0.75, 0.32);
  const stallPostGeo = track(new THREE.BoxGeometry(0.1, 1.32, 0.1));
  const csPL = new THREE.Mesh(stallPostGeo, mats.woodDark);
  csPL.position.set(-2.36, 0.68, 0.74);
  const csPR = csPL.clone();
  csPR.position.x = -0.64;
  const stallTopRail = new THREE.Mesh(track(new THREE.BoxGeometry(1.82, 0.09, 0.09)), mats.woodDark);
  stallTopRail.position.set(-1.5, 1.32, 0.74);
  const boardBar1 = new THREE.Mesh(track(new THREE.BoxGeometry(1.85, 0.11, 0.06)), mats.woodDark);
  boardBar1.position.set(-1.5, 0.88, 0.72);
  boardBar1.rotation.z = 0.16;
  const boardBar2 = boardBar1.clone();
  boardBar2.rotation.z = -0.14;

  // Dry Limestone Courtyard Fountain matching repaired fountain footprint
  const dryRim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.76, 0.86, 0.34, 16)), mats.limestoneWarm);
  dryRim.position.set(0, 0.21, 1.4);
  const dryBasin = new THREE.Mesh(track(new THREE.CylinderGeometry(0.62, 0.62, 0.1, 16)), mats.stoneDark);
  dryBasin.position.set(0, 0.32, 1.4);
  const drySpire = new THREE.Mesh(track(new THREE.CylinderGeometry(0.12, 0.18, 0.38, 10)), mats.stoneMid);
  drySpire.position.set(0, 0.45, 1.4);

  // Neatly Stacked Repair Materials in front-right courtyard (cut limestone blocks, timber planks & supply crate)
  const blockGeo = track(new THREE.BoxGeometry(0.46, 0.26, 0.34));
  for (const [bx, by, bz, mat] of [
    [1.05, 0.19, 0.35, mats.limestone],
    [1.56, 0.19, 0.35, mats.limestoneWarm],
    [1.08, 0.19, 0.74, mats.limestoneWarm],
    [1.58, 0.19, 0.74, mats.limestone],
    [1.32, 0.45, 0.54, mats.limestoneWarm],
  ] as const) {
    const blk = new THREE.Mesh(blockGeo, mat);
    blk.position.set(bx, by, bz);
    ruinedGroup.add(blk);
  }

  const plankGeo = track(new THREE.BoxGeometry(1.25, 0.08, 0.22));
  for (let p = 0; p < 3; p++) {
    const plank = new THREE.Mesh(plankGeo, p % 2 === 0 ? mats.woodLight : mats.woodMid);
    plank.position.set(1.42, 0.12 + p * 0.09, -0.18 + (p === 2 ? 0.04 : 0));
    plank.rotation.y = 0.08;
    ruinedGroup.add(plank);
  }
  const repairCrate = new THREE.Mesh(track(new THREE.BoxGeometry(0.48, 0.38, 0.44)), mats.woodDark);
  repairCrate.position.set(2.12, 0.25, 0.48);

  ruinedGroup.add(
    leftBackWall,
    leftSideWall,
    leftFrontLower,
    leftUpperCorner,
    leftFloor,
    leftRubble1,
    leftRubble2,
    shutterAskew,
    ridgeBeam,
    roofPatch,
    rightBackWall,
    rightSideWall,
    rightStepWall,
    rightDoorPlank1,
    rightDoorPlank2,
    closedStallBody,
    foldedTarp,
    csPL,
    csPR,
    stallTopRail,
    boardBar1,
    boardBar2,
    dryRim,
    dryBasin,
    drySpire,
    repairCrate
  );
  group.add(ruinedGroup);

  // REPAIRED AEGEAN VILLAGE MARKET
  const repairedGroup = new THREE.Group();

  const b1 = new THREE.Mesh(track(new THREE.BoxGeometry(2.25, 2.05, 1.8)), mats.limestone);
  b1.position.set(-1.55, 1.08, -1.3);
  repairedGroup.add(b1);
  addTiledGableRoof(repairedGroup, 2.35, 2.0, 2.1, 0.72, mats, track);
  // Shift roof above b1
  repairedGroup.children.slice(-3).forEach((c) => {
    c.position.x -= 1.55;
    c.position.z -= 1.3;
  });
  const shutter1 = new THREE.Mesh(track(new THREE.BoxGeometry(0.5, 0.62, 0.08)), mats.shutterBlue);
  shutter1.position.set(-1.55, 1.48, -0.38);

  const b2 = new THREE.Mesh(track(new THREE.BoxGeometry(2.25, 2.35, 1.8)), mats.limestone);
  b2.position.set(1.25, 1.22, -1.3);
  repairedGroup.add(b2);
  const b2RoofStart = repairedGroup.children.length;
  addTiledGableRoof(repairedGroup, 2.35, 2.0, 2.4, 0.72, mats, track);
  repairedGroup.children.slice(b2RoofStart).forEach((c) => {
    c.position.x += 1.25;
    c.position.z -= 1.3;
  });
  const shutter2 = new THREE.Mesh(track(new THREE.BoxGeometry(0.5, 0.62, 0.08)), mats.shutterBlue);
  shutter2.position.set(1.25, 1.68, -0.38);

  repairedGroup.add(shutter1, shutter2);

  // Two Market Stalls with cream awnings & wooden produce crates
  const postGeo = track(new THREE.BoxGeometry(0.1, 1.38, 0.1));
  for (const sx of [-1.5, 1.25]) {
    const awning = new THREE.Mesh(track(new THREE.BoxGeometry(2.0, 0.09, 1.25)), mats.creamCanvas);
    awning.position.set(sx, 1.42, 0.25);
    awning.rotation.x = 0.24;

    const pL = new THREE.Mesh(postGeo, mats.woodDark);
    pL.position.set(sx - 0.88, 0.72, 0.76);
    const pR = pL.clone();
    pR.position.x = sx + 0.88;

    const stall = new THREE.Mesh(track(new THREE.BoxGeometry(1.75, 0.62, 0.72)), mats.woodLight);
    stall.position.set(sx, 0.36, 0.35);

    const crate1 = new THREE.Mesh(track(new THREE.BoxGeometry(0.6, 0.26, 0.46)), mats.woodDark);
    crate1.position.set(sx - 0.42, 0.78, 0.35);
    const fruit1 = new THREE.Mesh(track(new THREE.SphereGeometry(0.16, 8, 8)), mats.cornGold);
    fruit1.position.set(sx - 0.42, 0.94, 0.35);

    const crate2 = crate1.clone();
    crate2.position.x = sx + 0.42;
    const fruit2 = new THREE.Mesh(track(new THREE.SphereGeometry(0.16, 8, 8)), mats.flowerPink);
    fruit2.position.set(sx + 0.42, 0.94, 0.35);

    repairedGroup.add(awning, pL, pR, stall, crate1, fruit1, crate2, fruit2);
  }

  // Central courtyard stone fountain with blue water
  const fountainRim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.78, 0.88, 0.36, 16)), mats.limestone);
  fountainRim.position.set(0, 0.22, 1.4);
  const fountainWater = new THREE.Mesh(track(new THREE.CylinderGeometry(0.64, 0.64, 0.08, 16)), mats.waterBlue);
  fountainWater.position.set(0, 0.38, 1.4);
  const fountainSpire = new THREE.Mesh(track(new THREE.CylinderGeometry(0.13, 0.2, 0.6, 10)), mats.limestone);
  fountainSpire.position.set(0, 0.58, 1.4);
  repairedGroup.add(fountainRim, fountainWater, fountainSpire);

  repairedGroup.visible = false;
  group.add(repairedGroup);

  const ringMesh = addFloorRing(3.35, mats.highlightRing, geometries);
  group.add(ringMesh);

  const hitMesh = new THREE.Mesh(
    track(new THREE.BoxGeometry(6.0, 3.1, 4.9)),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitMesh.position.y = 1.55;
  hitMesh.userData = { targetType: 'village_market' };
  hitMesh.layers.set(1);
  group.add(hitMesh);

  enableShadows(group, true, true);
  ringMesh.castShadow = false;
  return { group, hitMesh, ringMesh, ruinedGroup, repairedGroup };
}

export function createOliveTree3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[],
  variant = 0
): THREE.Group {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  let seed = 3109 + variant * 757;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  const tree = new THREE.Group();
  const trunkH = 1.24 + rand() * 0.32;
  const canopyLift = trunkH + 0.44;
  addContactShadow(tree, 1.05 + rand() * 0.22, 0.98 + rand() * 0.2, 0, 0, mats, geometries);

  const trunk = new THREE.Mesh(
    track(new THREE.CylinderGeometry(0.15 + rand() * 0.04, 0.26 + rand() * 0.06, trunkH, 7)),
    mats.woodDark
  );
  trunk.position.y = trunkH * 0.5;
  trunk.rotation.z = (rand() - 0.5) * 0.1;

  const c1 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.84, 1)), mats.oliveLeaf);
  c1.position.set((rand() - 0.5) * 0.14, canopyLift, (rand() - 0.5) * 0.14);
  c1.scale.set(0.95 + rand() * 0.2, 0.78 + rand() * 0.16, 0.95 + rand() * 0.2);

  const c2 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.66, 1)), mats.oliveLeafDark);
  c2.position.set(-0.56 - rand() * 0.16, canopyLift - 0.22 + rand() * 0.12, 0.2 + (rand() - 0.5) * 0.2);
  c2.scale.set(0.88 + rand() * 0.24, 0.78 + rand() * 0.16, 0.88 + rand() * 0.22);

  const c3 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.62, 1)), mats.oliveLeaf);
  c3.position.set(0.54 + rand() * 0.16, canopyLift - 0.18 + rand() * 0.14, -0.18 + (rand() - 0.5) * 0.2);
  c3.scale.set(0.86 + rand() * 0.24, 0.8 + rand() * 0.16, 0.86 + rand() * 0.22);

  const c4 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.52, 1)), mats.oliveLeafDark);
  c4.position.set((rand() - 0.5) * 0.28, canopyLift + 0.4 + rand() * 0.14, (rand() - 0.5) * 0.26);
  c4.scale.set(0.9 + rand() * 0.2, 0.76 + rand() * 0.18, 0.9 + rand() * 0.2);

  tree.add(trunk, c1, c2, c3, c4);
  tree.rotation.y = variant * 1.37 + rand() * 0.6;
  enableShadows(tree, true, false);
  return tree;
}

export function createCypressTree3D(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[],
  variant = 0
): THREE.Group {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  let seed = 5501 + variant * 619;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  const tree = new THREE.Group();
  const hScale = 0.88 + rand() * 0.3;
  const rScale = 0.88 + rand() * 0.2;
  addContactShadow(tree, 0.68 * rScale, 0.68 * rScale, 0, 0, mats, geometries);

  const trunk = new THREE.Mesh(track(new THREE.CylinderGeometry(0.12, 0.2, 0.82, 7)), mats.woodDark);
  trunk.position.y = 0.41;
  const cone1 = new THREE.Mesh(
    track(new THREE.ConeGeometry(0.6 * rScale, 2.65 * hScale, 9)),
    mats.cypressLeaf
  );
  cone1.position.y = 0.65 + 1.32 * hScale;
  const cone2 = new THREE.Mesh(
    track(new THREE.ConeGeometry(0.41 * rScale, 1.55 * hScale, 9)),
    mats.cypressLeaf
  );
  cone2.position.y = 1.55 + 1.32 * hScale;
  tree.add(trunk, cone1, cone2);
  tree.rotation.y = variant * 1.15 + rand() * 0.5;
  enableShadows(tree, true, false);
  return tree;
}

export function createValleyDecorations(
  mats: ValleyMaterials,
  geometries: THREE.BufferGeometry[]
): THREE.Group {
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const decoGroup = new THREE.Group();

  // Cohesive Aegean border groupings: shrubs + mossy/limestone boulders tucked cleanly near corners & tree borders
  const boulderGeo = track(new THREE.DodecahedronGeometry(0.34, 0));
  const bushGeo = track(new THREE.DodecahedronGeometry(0.42, 1));
  const smallBushGeo = track(new THREE.DodecahedronGeometry(0.28, 1));
  const flowerGeo = track(new THREE.DodecahedronGeometry(0.18, 0));

  const clusters: {
    x: number;
    z: number;
    ry: number;
    flower: 'pink' | 'yellow' | 'purple';
    withBoulders: boolean;
  }[] = [
    { x: -5.4, z: 9.6, ry: 0.4, flower: 'pink', withBoulders: true },
    { x: 10.6, z: -1.4, ry: 1.2, flower: 'pink', withBoulders: true },
    { x: -8.6, z: 5.0, ry: -0.7, flower: 'purple', withBoulders: true },
    { x: 3.1, z: -3.5, ry: 0.9, flower: 'purple', withBoulders: false },
    { x: -4.8, z: -6.1, ry: -0.3, flower: 'yellow', withBoulders: true },
    { x: 8.4, z: 1.5, ry: 1.8, flower: 'yellow', withBoulders: false },
    { x: -11.5, z: 7.4, ry: 0.6, flower: 'yellow', withBoulders: true },
    { x: 3.8, z: 9.2, ry: -1.1, flower: 'pink', withBoulders: true },
  ];

  for (const cl of clusters) {
    const cg = new THREE.Group();
    cg.position.set(cl.x, 0, cl.z);
    cg.rotation.y = cl.ry;
    addContactShadow(cg, 0.85, 0.72, 0, 0, mats, geometries);

    const mainBush = new THREE.Mesh(bushGeo, mats.oliveLeafDark);
    mainBush.position.set(0, 0.32, 0);
    mainBush.scale.set(1.05, 0.86, 0.98);
    const sideBush = new THREE.Mesh(smallBushGeo, mats.oliveLeaf);
    sideBush.position.set(0.42, 0.22, 0.22);

    const flMat =
      cl.flower === 'pink'
        ? mats.flowerPink
        : cl.flower === 'yellow'
          ? mats.flowerYellow
          : mats.flowerPurple;
    const f1 = new THREE.Mesh(flowerGeo, flMat);
    f1.position.set(-0.16, 0.56, 0.16);
    const f2 = new THREE.Mesh(flowerGeo, flMat);
    f2.position.set(0.2, 0.5, -0.1);
    cg.add(mainBush, sideBush, f1, f2);

    if (cl.withBoulders) {
      const rock1 = new THREE.Mesh(boulderGeo, mats.stoneMid);
      rock1.position.set(-0.52, 0.18, 0.28);
      rock1.scale.set(1.1, 0.72, 0.95);
      rock1.rotation.set(0.2, 0.7, 0.1);
      const rock2 = new THREE.Mesh(boulderGeo, mats.limestoneWarm);
      rock2.position.set(-0.22, 0.13, 0.52);
      rock2.scale.set(0.75, 0.55, 0.72);
      cg.add(rock1, rock2);
    }

    enableShadows(cg, true, true);
    decoGroup.add(cg);
  }

  // Subtle InstancedMesh grass tufts scattered across outer meadow (single draw call)
  const tuftGeo = track(new THREE.ConeGeometry(0.11, 0.24, 5));
  const tuftCount = 85;
  const tufts = new THREE.InstancedMesh(tuftGeo, mats.grassDark, tuftCount);
  const dummy = new THREE.Object3D();
  let seed = 9012;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  let placed = 0;
  while (placed < tuftCount) {
    const gx = (rand() - 0.5) * 44;
    const gz = (rand() - 0.5) * 38;
    if (Math.abs(gx) < 12.5 && Math.abs(gz) < 9.8) continue;
    dummy.position.set(gx, 0.1, gz);
    dummy.rotation.y = rand() * Math.PI * 2;
    dummy.scale.setScalar(0.75 + rand() * 0.55);
    dummy.updateMatrix();
    tufts.setMatrixAt(placed, dummy.matrix);
    placed++;
  }
  tufts.instanceMatrix.needsUpdate = true;
  tufts.computeBoundingSphere();
  decoGroup.add(tufts);

  return decoGroup;
}
