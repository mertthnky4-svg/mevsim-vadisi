export function formatRemainingMs(ms: number): string {
  if (ms <= 0) return 'Hazır';
  const totalSec = Math.ceil(ms / 1000);
  if (totalSec < 60) {
    return `${totalSec} sn`;
  }
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return secs > 0 ? `${mins} dk ${secs} sn` : `${mins} dk`;
}

export function formatShortTimer(ms: number): string {
  if (ms <= 0) return 'Hazır';
  const totalSec = Math.ceil(ms / 1000);
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  if (mins === 0) return `${secs}s`;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
