import {
  BUILDINGS,
  CROPS,
  GAME_CONFIG,
  ITEMS,
  MINE_NODES,
  ORDER_TEMPLATES,
  QUEST_STEPS,
  type OrderTemplate,
  type QuestStepConfig,
} from './config';
import type {
  ActionResult,
  BuildingId,
  CropId,
  GameState,
  Inventory,
  ItemId,
  MineNodeId,
  OrderSlot,
} from './types';

export function computeLevel(xp: number): number {
  const thresholds = GAME_CONFIG.levelThresholds;
  let lvl = 1;
  for (let i = 0; i < thresholds.length; i++) {
    if (xp >= thresholds[i]) {
      lvl = i + 1;
    }
  }
  return lvl;
}

export function getXpProgress(xp: number): {
  level: number;
  currentLevelXp: number;
  nextLevelXp: number | null;
  progressRatio: number;
} {
  const level = computeLevel(xp);
  const thresholds = GAME_CONFIG.levelThresholds;
  const currentThreshold = thresholds[level - 1] ?? 0;
  const nextThreshold = thresholds[level] ?? null;
  if (nextThreshold === null) {
    return {
      level,
      currentLevelXp: xp - currentThreshold,
      nextLevelXp: null,
      progressRatio: 1,
    };
  }
  const span = Math.max(1, nextThreshold - currentThreshold);
  return {
    level,
    currentLevelXp: xp - currentThreshold,
    nextLevelXp: nextThreshold - currentThreshold,
    progressRatio: Math.min(1, Math.max(0, (xp - currentThreshold) / span)),
  };
}

export function getInventoryUsed(inventory: Inventory): number {
  return (Object.keys(inventory) as ItemId[]).reduce(
    (sum, key) => sum + Math.max(0, Math.floor(inventory[key] || 0)),
    0
  );
}

export function getBuildingDurationMs(buildingId: BuildingId, level: number): number {
  const cfg = BUILDINGS[buildingId];
  const clampedLevel = Math.max(1, Math.min(cfg.maxLevel, level));
  const multiplier = 1 - (clampedLevel - 1) * GAME_CONFIG.buildingSpeedReductionPerLevel;
  return Math.max(GAME_CONFIG.minProductionDurationMs, Math.round(cfg.baseDurationMs * multiplier));
}

export function pickOrderFromPool(
  level: number,
  marketRepaired: boolean,
  slotIndex: number,
  excludeIds: string[] = []
): OrderSlot {
  const eligible = ORDER_TEMPLATES.filter((t) => {
    if (t.minLevel > level) return false;
    if (t.requiresMarketRepaired && !marketRepaired) return false;
    return true;
  });

  const nonDuplicate = eligible.filter((t) => !excludeIds.includes(t.id));
  const pool: OrderTemplate[] = nonDuplicate.length > 0 ? nonDuplicate : eligible;

  // Prefer unlocked higher-tier orders slightly when newly unlocked, otherwise deterministic-friendly random
  const chosen = pool[Math.floor(Math.random() * pool.length)] ?? ORDER_TEMPLATES[0];

  return {
    slotIndex,
    id: `${chosen.id}_${Date.now()}_${slotIndex}`,
    customerName: chosen.customerName,
    title: chosen.title,
    isMarketSpecial: Boolean(chosen.requiresMarketRepaired),
    status: 'active',
    requirements: chosen.requirements.map((r) => ({ ...r })),
    goldReward: chosen.goldReward,
    xpReward: chosen.xpReward,
    cooldownEndsAt: null,
  };
}

export function createInitialGameState(now: number = Date.now()): GameState {
  const plots = Array.from({ length: GAME_CONFIG.plotCount }, (_, i) => ({
    id: i,
    status: 'empty' as const,
    cropId: null,
    plantedAt: null,
    completesAt: null,
    fertilized: false,
  }));

  const orders: OrderSlot[] = [
    {
      slotIndex: 0,
      id: `init_ord_0_${now}`,
      customerName: ORDER_TEMPLATES[0].customerName,
      title: ORDER_TEMPLATES[0].title,
      isMarketSpecial: false,
      status: 'active',
      requirements: ORDER_TEMPLATES[0].requirements.map((r) => ({ ...r })),
      goldReward: ORDER_TEMPLATES[0].goldReward,
      xpReward: ORDER_TEMPLATES[0].xpReward,
      cooldownEndsAt: null,
    },
    {
      slotIndex: 1,
      id: `init_ord_1_${now}`,
      customerName: ORDER_TEMPLATES[1].customerName,
      title: ORDER_TEMPLATES[1].title,
      isMarketSpecial: false,
      status: 'active',
      requirements: ORDER_TEMPLATES[1].requirements.map((r) => ({ ...r })),
      goldReward: ORDER_TEMPLATES[1].goldReward,
      xpReward: ORDER_TEMPLATES[1].xpReward,
      cooldownEndsAt: null,
    },
    {
      slotIndex: 2,
      id: `init_ord_2_${now}`,
      customerName: ORDER_TEMPLATES[2].customerName,
      title: ORDER_TEMPLATES[2].title,
      isMarketSpecial: false,
      status: 'active',
      requirements: ORDER_TEMPLATES[2].requirements.map((r) => ({ ...r })),
      goldReward: ORDER_TEMPLATES[2].goldReward,
      xpReward: ORDER_TEMPLATES[2].xpReward,
      cooldownEndsAt: null,
    },
  ];

  return {
    version: GAME_CONFIG.saveVersion,
    gold: GAME_CONFIG.initialGold,
    xp: 0,
    level: 1,
    warehouseCapacity: GAME_CONFIG.initialWarehouseCapacity,
    inventory: { ...GAME_CONFIG.initialInventory },
    plots,
    buildings: {
      bakery: { id: 'bakery', level: 1, status: 'idle', startedAt: null, completesAt: null },
      feed_mill: { id: 'feed_mill', level: 1, status: 'idle', startedAt: null, completesAt: null },
      coop: { id: 'coop', level: 1, status: 'idle', startedAt: null, completesAt: null },
      workshop: { id: 'workshop', level: 1, status: 'idle', startedAt: null, completesAt: null },
    },
    mine: {
      status: 'idle',
      activeNodeId: null,
      startedAt: null,
      completesAt: null,
    },
    orders,
    villageMarket: {
      delivered: {
        bread: 0,
        egg: 0,
        stone: 0,
      },
      repaired: false,
      repairedAt: null,
    },
    stats: {
      cropsHarvested: 0,
      wheatHarvested: 0,
      cornHarvested: 0,
      breadBaked: 0,
      feedProduced: 0,
      eggsCollected: 0,
      fertilizerUsed: 0,
      mineWorksCompleted: 0,
      stoneMined: 0,
      ironMined: 0,
      toolsCrafted: 0,
      buildingsUpgraded: 0,
      warehouseUpgraded: 0,
      ordersDelivered: 0,
    },
    claimedQuestIds: [],
    tutorialDismissed: false,
    lastSavedAt: now,
  };
}

function addXp(state: GameState, amount: number): { xp: number; level: number; leveledUpTo?: number } {
  const nextXp = Math.max(0, state.xp + Math.max(0, amount));
  const prevLevel = state.level;
  const nextLevel = computeLevel(nextXp);
  return {
    xp: nextXp,
    level: nextLevel,
    leveledUpTo: nextLevel > prevLevel ? nextLevel : undefined,
  };
}

export function refreshReadyOrders(state: GameState, now: number = Date.now()): GameState {
  let changed = false;
  const currentTitles = state.orders
    .filter((o) => o.status === 'active')
    .map((o) => o.title);

  const nextOrders = state.orders.map((slot) => {
    if (slot.status === 'cooldown' && slot.cooldownEndsAt !== null && now >= slot.cooldownEndsAt) {
      changed = true;
      const eligibleTemplates = ORDER_TEMPLATES.filter((t) => {
        if (t.minLevel > state.level) return false;
        if (t.requiresMarketRepaired && !state.villageMarket.repaired) return false;
        return !currentTitles.includes(t.title);
      });
      const fallbackTemplates = ORDER_TEMPLATES.filter(
        (t) => t.minLevel <= state.level && (!t.requiresMarketRepaired || state.villageMarket.repaired)
      );
      const pool = eligibleTemplates.length > 0 ? eligibleTemplates : fallbackTemplates;
      const chosen = pool[Math.floor(Math.random() * pool.length)] ?? ORDER_TEMPLATES[0];
      currentTitles.push(chosen.title);
      return {
        slotIndex: slot.slotIndex,
        id: `${chosen.id}_${now}_${slot.slotIndex}`,
        customerName: chosen.customerName,
        title: chosen.title,
        isMarketSpecial: Boolean(chosen.requiresMarketRepaired),
        status: 'active' as const,
        requirements: chosen.requirements.map((r) => ({ ...r })),
        goldReward: chosen.goldReward,
        xpReward: chosen.xpReward,
        cooldownEndsAt: null,
      };
    }
    return slot;
  });

  if (!changed) return state;
  return { ...state, orders: nextOrders };
}

export function plantCrop(
  state: GameState,
  plotId: number,
  cropId: CropId,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const plot = state.plots.find((p) => p.id === plotId);
  if (!plot) {
    return { state, result: { ok: false, message: 'Geçersiz tarla parseli.' } };
  }
  if (plot.status !== 'empty') {
    return { state, result: { ok: false, message: 'Bu parselde zaten büyüyen bir ekin var.' } };
  }

  const crop = CROPS[cropId];
  if (state.level < crop.unlockLevel) {
    return {
      state,
      result: {
        ok: false,
        message: `${crop.name} ekmek için ${crop.unlockLevel}. seviyeye ulaşmalısın.`,
      },
    };
  }
  if (state.gold < crop.seedCost) {
    return {
      state,
      result: {
        ok: false,
        message: `${crop.name} ekmek için ${crop.seedCost} Altın gerekli. Ücretsiz Buğday ekerek altın kazanabilirsin.`,
      },
    };
  }

  const nextPlots = state.plots.map((p) =>
    p.id === plotId
      ? {
          ...p,
          status: 'growing' as const,
          cropId,
          plantedAt: now,
          completesAt: now + crop.durationMs,
          fertilized: false,
        }
      : p
  );

  return {
    state: {
      ...state,
      gold: state.gold - crop.seedCost,
      plots: nextPlots,
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${crop.name} ekildi.`,
    },
  };
}

export function applyFertilizer(
  state: GameState,
  plotId: number,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const plot = state.plots.find((p) => p.id === plotId);
  if (!plot || plot.status !== 'growing' || !plot.completesAt || !plot.cropId) {
    return { state, result: { ok: false, message: 'Gübre yalnızca büyümekte olan ekine uygulanabilir.' } };
  }
  if (plot.fertilized) {
    return { state, result: { ok: false, message: 'Bu ekime zaten bir kez gübre uygulandı.' } };
  }
  if (now >= plot.completesAt) {
    return { state, result: { ok: false, message: 'Bu ekin zaten hasada hazır.' } };
  }
  if ((state.inventory.fertilizer || 0) < 1) {
    return {
      state,
      result: {
        ok: false,
        message: 'Depoda Doğal Gübre yok. Tavuk Kümesi’nden yumurta toplarken gübre elde edebilirsin.',
      },
    };
  }

  const remaining = plot.completesAt - now;
  const reduced = Math.round(remaining * (1 - GAME_CONFIG.fertilizerReductionRatio));
  const clampedRemaining =
    remaining <= GAME_CONFIG.minRemainingAfterFertilizerMs
      ? remaining
      : Math.max(GAME_CONFIG.minRemainingAfterFertilizerMs, reduced);

  const nextPlots = state.plots.map((p) =>
    p.id === plotId
      ? {
          ...p,
          completesAt: now + clampedRemaining,
          fertilized: true,
        }
      : p
  );

  return {
    state: {
      ...state,
      inventory: {
        ...state.inventory,
        fertilizer: state.inventory.fertilizer - 1,
      },
      plots: nextPlots,
      stats: {
        ...state.stats,
        fertilizerUsed: state.stats.fertilizerUsed + 1,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${CROPS[plot.cropId].name} gübrelendi! Büyüme süresi hızlandı.`,
    },
  };
}

export function harvestPlot(
  state: GameState,
  plotId: number,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const plot = state.plots.find((p) => p.id === plotId);
  if (!plot || plot.status !== 'growing' || !plot.cropId || plot.completesAt === null) {
    return { state, result: { ok: false, message: 'Bu parselde hasat edilecek ürün yok.' } };
  }
  if (now < plot.completesAt) {
    const secs = Math.ceil((plot.completesAt - now) / 1000);
    return { state, result: { ok: false, message: `Henüz hazır değil (${secs} sn kaldı).` } };
  }

  const crop = CROPS[plot.cropId];
  const used = getInventoryUsed(state.inventory);
  if (used + crop.yieldAmount > state.warehouseCapacity) {
    return {
      state,
      result: {
        ok: false,
        message: 'Depo dolu! Hasat yapmadan önce Depo’dan ürün sat veya taşla kapasiteyi artır.',
      },
    };
  }

  const nextPlots = state.plots.map((p) =>
    p.id === plotId
      ? {
          ...p,
          status: 'empty' as const,
          cropId: null,
          plantedAt: null,
          completesAt: null,
          fertilized: false,
        }
      : p
  );

  const xpData = addXp(state, crop.xpOnHarvest);

  return {
    state: {
      ...state,
      xp: xpData.xp,
      level: xpData.level,
      inventory: {
        ...state.inventory,
        [crop.id]: (state.inventory[crop.id] || 0) + crop.yieldAmount,
      },
      plots: nextPlots,
      stats: {
        ...state.stats,
        cropsHarvested: state.stats.cropsHarvested + 1,
        wheatHarvested: state.stats.wheatHarvested + (crop.id === 'wheat' ? 1 : 0),
        cornHarvested: state.stats.cornHarvested + (crop.id === 'corn' ? 1 : 0),
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `+${crop.yieldAmount} ${crop.name} hasat edildi.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function startBuildingProduction(
  state: GameState,
  buildingId: BuildingId,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const bState = state.buildings[buildingId];
  const bCfg = BUILDINGS[buildingId];
  if (!bState || !bCfg) {
    return { state, result: { ok: false, message: 'Bina bulunamadı.' } };
  }
  if (state.level < bCfg.unlockLevel) {
    return {
      state,
      result: {
        ok: false,
        message: `${bCfg.name} ${bCfg.unlockLevel}. seviyede açılır.`,
      },
    };
  }
  if (bState.status !== 'idle') {
    return { state, result: { ok: false, message: `${bCfg.name} şu an çalışıyor.` } };
  }

  for (const req of bCfg.inputs) {
    if ((state.inventory[req.itemId] || 0) < req.amount) {
      return {
        state,
        result: {
          ok: false,
          message: `Eksik malzeme: ${req.amount} ${ITEMS[req.itemId].name} gerekli.`,
        },
      };
    }
  }

  const nextInventory = { ...state.inventory };
  for (const req of bCfg.inputs) {
    nextInventory[req.itemId] = nextInventory[req.itemId] - req.amount;
  }

  const duration = getBuildingDurationMs(buildingId, bState.level);

  return {
    state: {
      ...state,
      inventory: nextInventory,
      buildings: {
        ...state.buildings,
        [buildingId]: {
          ...bState,
          status: 'producing',
          startedAt: now,
          completesAt: now + duration,
        },
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${bCfg.name} üretimi başladı.`,
    },
  };
}

export function collectBuildingProduction(
  state: GameState,
  buildingId: BuildingId,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const bState = state.buildings[buildingId];
  const bCfg = BUILDINGS[buildingId];
  if (!bState || bState.status !== 'producing' || bState.completesAt === null) {
    return { state, result: { ok: false, message: 'Toplanacak hazır ürün yok.' } };
  }
  if (now < bState.completesAt) {
    const secs = Math.ceil((bState.completesAt - now) / 1000);
    return { state, result: { ok: false, message: `Üretim sürüyor (${secs} sn kaldı).` } };
  }

  const totalOut = bCfg.outputs.reduce((sum, o) => sum + o.amount, 0);
  const used = getInventoryUsed(state.inventory);
  if (used + totalOut > state.warehouseCapacity) {
    return {
      state,
      result: {
        ok: false,
        message: 'Depo dolu! Ürünleri almadan önce Depo’dan satış yap veya kapasiteyi artır.',
      },
    };
  }

  const nextInventory = { ...state.inventory };
  for (const out of bCfg.outputs) {
    nextInventory[out.itemId] = (nextInventory[out.itemId] || 0) + out.amount;
  }

  const xpData = addXp(state, bCfg.xpOnCollect);
  const outLabel = bCfg.outputs.map((o) => `+${o.amount} ${ITEMS[o.itemId].name}`).join(', ');

  return {
    state: {
      ...state,
      xp: xpData.xp,
      level: xpData.level,
      inventory: nextInventory,
      buildings: {
        ...state.buildings,
        [buildingId]: {
          ...bState,
          status: 'idle',
          startedAt: null,
          completesAt: null,
        },
      },
      stats: {
        ...state.stats,
        breadBaked: state.stats.breadBaked + (buildingId === 'bakery' ? 1 : 0),
        feedProduced: state.stats.feedProduced + (buildingId === 'feed_mill' ? 1 : 0),
        eggsCollected: state.stats.eggsCollected + (buildingId === 'coop' ? 1 : 0),
        toolsCrafted: state.stats.toolsCrafted + (buildingId === 'workshop' ? 1 : 0),
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${outLabel} alındı.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function upgradeBuilding(
  state: GameState,
  buildingId: BuildingId,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const bState = state.buildings[buildingId];
  const bCfg = BUILDINGS[buildingId];
  if (!bState || !bCfg) {
    return { state, result: { ok: false, message: 'Bina bulunamadı.' } };
  }
  if (state.level < 3) {
    return { state, result: { ok: false, message: 'Bina geliştirme 3. seviyede açılır.' } };
  }
  if (bState.level >= bCfg.maxLevel) {
    return { state, result: { ok: false, message: `${bCfg.name} en yüksek seviyede.` } };
  }
  if (bState.status === 'producing') {
    return { state, result: { ok: false, message: 'Üretim bitince geliştirme yapabilirsin.' } };
  }

  const nextLevel = bState.level + 1;
  const cost = GAME_CONFIG.buildingUpgradeCosts[nextLevel];
  if (!cost) {
    return { state, result: { ok: false, message: 'Geliştirme yapılamıyor.' } };
  }
  if ((state.inventory.tool_part || 0) < cost.tool_part || (state.inventory.stone || 0) < cost.stone) {
    return {
      state,
      result: {
        ok: false,
        message: `Eksik malzeme: ${cost.tool_part} Alet Parçası ve ${cost.stone} Vadi Taşı gerekli.`,
      },
    };
  }

  const xpData = addXp(state, 12);

  return {
    state: {
      ...state,
      xp: xpData.xp,
      level: xpData.level,
      inventory: {
        ...state.inventory,
        tool_part: state.inventory.tool_part - cost.tool_part,
        stone: state.inventory.stone - cost.stone,
      },
      buildings: {
        ...state.buildings,
        [buildingId]: {
          ...bState,
          level: nextLevel,
        },
      },
      stats: {
        ...state.stats,
        buildingsUpgraded: state.stats.buildingsUpgraded + 1,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${bCfg.name} Seviye ${nextLevel} oldu! Üretim %15 hızlandı.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function startMineWork(
  state: GameState,
  nodeId: MineNodeId,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  if (state.level < 3) {
    return { state, result: { ok: false, message: 'Maden 3. seviyede açılır.' } };
  }
  if (state.mine.status !== 'idle') {
    return { state, result: { ok: false, message: 'Madende aynı anda yalnızca bir iş yürütülebilir.' } };
  }

  const node = MINE_NODES[nodeId];
  return {
    state: {
      ...state,
      mine: {
        status: 'working',
        activeNodeId: nodeId,
        startedAt: now,
        completesAt: now + node.durationMs,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${node.name} çalışması başladı.`,
    },
  };
}

export function collectMineWork(
  state: GameState,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  if (state.mine.status !== 'working' || !state.mine.activeNodeId || state.mine.completesAt === null) {
    return { state, result: { ok: false, message: 'Madende toplanacak kaynak yok.' } };
  }
  if (now < state.mine.completesAt) {
    const secs = Math.ceil((state.mine.completesAt - now) / 1000);
    return { state, result: { ok: false, message: `Çalışma sürüyor (${secs} sn kaldı).` } };
  }

  const node = MINE_NODES[state.mine.activeNodeId];
  const totalOut = node.outputs.reduce((sum, o) => sum + o.amount, 0);
  const used = getInventoryUsed(state.inventory);
  if (used + totalOut > state.warehouseCapacity) {
    return {
      state,
      result: {
        ok: false,
        message: 'Depo dolu! Madenden kaynak almadan önce Depo’da yer aç.',
      },
    };
  }

  const nextInventory = { ...state.inventory };
  let stoneAdded = 0;
  let ironAdded = 0;
  for (const out of node.outputs) {
    nextInventory[out.itemId] = (nextInventory[out.itemId] || 0) + out.amount;
    if (out.itemId === 'stone') stoneAdded += out.amount;
    if (out.itemId === 'iron_ore') ironAdded += out.amount;
  }

  const xpData = addXp(state, node.xpOnCollect);
  const outLabel = node.outputs.map((o) => `+${o.amount} ${ITEMS[o.itemId].name}`).join(', ');

  return {
    state: {
      ...state,
      xp: xpData.xp,
      level: xpData.level,
      inventory: nextInventory,
      mine: {
        status: 'idle',
        activeNodeId: null,
        startedAt: null,
        completesAt: null,
      },
      stats: {
        ...state.stats,
        mineWorksCompleted: state.stats.mineWorksCompleted + 1,
        stoneMined: state.stats.stoneMined + stoneAdded,
        ironMined: state.stats.ironMined + ironAdded,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${outLabel} çıkarıldı.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function fulfillOrder(
  state: GameState,
  slotIndex: number,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const slot = state.orders.find((o) => o.slotIndex === slotIndex);
  if (!slot || slot.status !== 'active') {
    return { state, result: { ok: false, message: 'Bu sipariş şu an teslim edilemez.' } };
  }

  for (const req of slot.requirements) {
    if ((state.inventory[req.itemId] || 0) < req.amount) {
      return {
        state,
        result: {
          ok: false,
          message: `Eksik ürün: ${req.amount} ${ITEMS[req.itemId].name} gerekli.`,
        },
      };
    }
  }

  const nextInventory = { ...state.inventory };
  for (const req of slot.requirements) {
    nextInventory[req.itemId] = nextInventory[req.itemId] - req.amount;
  }

  const xpData = addXp(state, slot.xpReward);
  const existingTitles = state.orders
    .filter((o) => o.slotIndex !== slotIndex && o.status === 'active')
    .map((o) => o.title);

  // Pick a fresh order matching new level & market state
  const eligible = ORDER_TEMPLATES.filter((t) => {
    if (t.minLevel > xpData.level) return false;
    if (t.requiresMarketRepaired && !state.villageMarket.repaired) return false;
    return !existingTitles.includes(t.title) && t.title !== slot.title;
  });
  const fallback = ORDER_TEMPLATES.filter(
    (t) => t.minLevel <= xpData.level && (!t.requiresMarketRepaired || state.villageMarket.repaired)
  );
  const pool = eligible.length > 0 ? eligible : fallback;
  const nextTemplate = pool[Math.floor(Math.random() * pool.length)] ?? ORDER_TEMPLATES[0];

  const nextOrders = state.orders.map((o) =>
    o.slotIndex === slotIndex
      ? {
          slotIndex,
          id: `${nextTemplate.id}_${now}_${slotIndex}`,
          customerName: nextTemplate.customerName,
          title: nextTemplate.title,
          isMarketSpecial: Boolean(nextTemplate.requiresMarketRepaired),
          status: 'active' as const,
          requirements: nextTemplate.requirements.map((r) => ({ ...r })),
          goldReward: nextTemplate.goldReward,
          xpReward: nextTemplate.xpReward,
          cooldownEndsAt: null,
        }
      : o
  );

  return {
    state: {
      ...state,
      gold: state.gold + slot.goldReward,
      xp: xpData.xp,
      level: xpData.level,
      inventory: nextInventory,
      orders: nextOrders,
      stats: {
        ...state.stats,
        ordersDelivered: state.stats.ordersDelivered + 1,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `Sipariş teslim edildi! +${slot.goldReward} Altın, +${slot.xpReward} XP.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function cancelOrder(
  state: GameState,
  slotIndex: number,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const slot = state.orders.find((o) => o.slotIndex === slotIndex);
  if (!slot || slot.status !== 'active') {
    return { state, result: { ok: false, message: 'Bu sipariş zaten yenileniyor.' } };
  }

  const nextOrders = state.orders.map((o) =>
    o.slotIndex === slotIndex
      ? {
          ...o,
          status: 'cooldown' as const,
          cooldownEndsAt: now + GAME_CONFIG.orderCancelCooldownMs,
        }
      : o
  );

  return {
    state: {
      ...state,
      orders: nextOrders,
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: 'Sipariş iptal edildi. Kısa süre sonra yeni bir sipariş gelecek.',
    },
  };
}

export function sellItem(
  state: GameState,
  itemId: ItemId,
  quantity: number,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  const owned = state.inventory[itemId] || 0;
  const sellQty = Math.min(owned, Math.max(1, Math.floor(quantity)));
  if (owned < 1 || sellQty < 1) {
    return { state, result: { ok: false, message: `Depoda satılacak ${ITEMS[itemId].name} yok.` } };
  }

  const unitPrice = ITEMS[itemId].sellPrice;
  const earnedGold = sellQty * unitPrice;

  return {
    state: {
      ...state,
      gold: state.gold + earnedGold,
      inventory: {
        ...state.inventory,
        [itemId]: owned - sellQty,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `${sellQty} ${ITEMS[itemId].name} satıldı (+${earnedGold} Altın).`,
    },
  };
}

export function getNextWarehouseUpgrade(currentCapacity: number): { targetCapacity: number; stoneCost: number } | null {
  return GAME_CONFIG.warehouseUpgrades.find((u) => u.targetCapacity > currentCapacity) ?? null;
}

export function upgradeWarehouse(
  state: GameState,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  if (state.level < 3) {
    return { state, result: { ok: false, message: 'Depo genişletme 3. seviyede açılır.' } };
  }
  const nextTier = getNextWarehouseUpgrade(state.warehouseCapacity);
  if (!nextTier) {
    return { state, result: { ok: false, message: 'Depo zaten en büyük kapasitede.' } };
  }
  if ((state.inventory.stone || 0) < nextTier.stoneCost) {
    return {
      state,
      result: {
        ok: false,
        message: `Depo genişletmek için ${nextTier.stoneCost} Vadi Taşı gerekli.`,
      },
    };
  }

  const xpData = addXp(state, 10);

  return {
    state: {
      ...state,
      xp: xpData.xp,
      level: xpData.level,
      warehouseCapacity: nextTier.targetCapacity,
      inventory: {
        ...state.inventory,
        stone: state.inventory.stone - nextTier.stoneCost,
      },
      stats: {
        ...state.stats,
        warehouseUpgraded: state.stats.warehouseUpgraded + 1,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `Depo kapasitesi ${nextTier.targetCapacity} birime çıkarıldı!`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function deliverVillageResource(
  state: GameState,
  itemId: 'bread' | 'egg' | 'stone',
  amount: number,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  if (state.level < 3) {
    return { state, result: { ok: false, message: 'Köy Pazarı onarımı 3. seviyede açılır.' } };
  }
  if (state.villageMarket.repaired) {
    return { state, result: { ok: false, message: 'Köy Pazarı zaten onarıldı ve hizmete açıldı.' } };
  }

  const required = GAME_CONFIG.villageMarketRequirements[itemId];
  const alreadyDelivered = state.villageMarket.delivered[itemId];
  const remainingNeed = Math.max(0, required - alreadyDelivered);
  if (remainingNeed <= 0) {
    return {
      state,
      result: { ok: false, message: `${ITEMS[itemId].name} ihtiyacı zaten tamamlandı.` },
    };
  }

  const owned = state.inventory[itemId] || 0;
  const deliverCount = Math.min(owned, remainingNeed, Math.max(1, Math.floor(amount)));
  if (deliverCount <= 0) {
    return {
      state,
      result: {
        ok: false,
        message: `Depoda teslim edilecek ${ITEMS[itemId].name} yok.`,
      },
    };
  }

  const nextDelivered = {
    ...state.villageMarket.delivered,
    [itemId]: alreadyDelivered + deliverCount,
  };

  const allComplete =
    nextDelivered.bread >= GAME_CONFIG.villageMarketRequirements.bread &&
    nextDelivered.egg >= GAME_CONFIG.villageMarketRequirements.egg &&
    nextDelivered.stone >= GAME_CONFIG.villageMarketRequirements.stone;

  let nextGold = state.gold;
  let xpToAdd = deliverCount * 3;
  let repaired = false;
  let repairedAt: number | null = null;

  if (allComplete) {
    repaired = true;
    repairedAt = now;
    nextGold += GAME_CONFIG.villageMarketCompletionReward.gold;
    xpToAdd += GAME_CONFIG.villageMarketCompletionReward.xp;
  }

  const xpData = addXp(state, xpToAdd);

  return {
    state: {
      ...state,
      gold: nextGold,
      xp: xpData.xp,
      level: xpData.level,
      inventory: {
        ...state.inventory,
        [itemId]: owned - deliverCount,
      },
      villageMarket: {
        delivered: nextDelivered,
        repaired,
        repairedAt,
      },
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: allComplete
        ? `Köy Pazarı onarımı tamamlandı! +${GAME_CONFIG.villageMarketCompletionReward.gold} Altın ve özel pazar siparişleri açıldı!`
        : `${deliverCount} ${ITEMS[itemId].name} Köy Pazarı’na teslim edildi.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}

export function getActiveQuest(state: GameState): QuestStepConfig | null {
  for (const q of QUEST_STEPS) {
    if (!state.claimedQuestIds.includes(q.id)) {
      return q;
    }
  }
  return null;
}

export function claimQuestReward(
  state: GameState,
  questId: string,
  now: number = Date.now()
): { state: GameState; result: ActionResult } {
  if (state.claimedQuestIds.includes(questId)) {
    return { state, result: { ok: false, message: 'Bu görevin ödülü zaten alındı.' } };
  }
  const quest = QUEST_STEPS.find((q) => q.id === questId);
  if (!quest) {
    return { state, result: { ok: false, message: 'Görev bulunamadı.' } };
  }
  if (!quest.checkCompleted(state)) {
    return { state, result: { ok: false, message: 'Görev henüz tamamlanmadı.' } };
  }

  const xpData = addXp(state, quest.xpBonus);

  return {
    state: {
      ...state,
      gold: state.gold + quest.goldBonus,
      xp: xpData.xp,
      level: xpData.level,
      claimedQuestIds: [...state.claimedQuestIds, questId],
      lastSavedAt: now,
    },
    result: {
      ok: true,
      message: `Görev ödülü alındı: +${quest.goldBonus} Altın, +${quest.xpBonus} XP.`,
      leveledUpTo: xpData.leveledUpTo,
    },
  };
}
