export type ItemId =
  | 'wheat'
  | 'corn'
  | 'bread'
  | 'chicken_feed'
  | 'egg'
  | 'fertilizer'
  | 'stone'
  | 'iron_ore'
  | 'tool_part';

export type CropId = 'wheat' | 'corn';

export type BuildingId = 'bakery' | 'feed_mill' | 'coop' | 'workshop';

export type MineNodeId = 'stone_ridge' | 'iron_vein' | 'mixed_boulder';

export type MapFocusTarget =
  | 'plots'
  | 'bakery'
  | 'feed_mill'
  | 'coop'
  | 'mine'
  | 'workshop'
  | 'orders'
  | 'village_market'
  | 'warehouse';

export type Inventory = Record<ItemId, number>;

export interface PlotState {
  id: number;
  status: 'empty' | 'growing';
  cropId: CropId | null;
  plantedAt: number | null;
  completesAt: number | null;
  fertilized: boolean;
}

export interface BuildingState {
  id: BuildingId;
  level: number;
  status: 'idle' | 'producing';
  startedAt: number | null;
  completesAt: number | null;
}

export interface MineState {
  status: 'idle' | 'working';
  activeNodeId: MineNodeId | null;
  startedAt: number | null;
  completesAt: number | null;
}

export interface OrderRequirement {
  itemId: ItemId;
  amount: number;
}

export interface OrderSlot {
  slotIndex: number;
  id: string;
  customerName: string;
  title: string;
  isMarketSpecial: boolean;
  status: 'active' | 'cooldown';
  requirements: OrderRequirement[];
  goldReward: number;
  xpReward: number;
  cooldownEndsAt: number | null;
}

export interface VillageMarketState {
  delivered: {
    bread: number;
    egg: number;
    stone: number;
  };
  repaired: boolean;
  repairedAt: number | null;
}

export interface PlayerStats {
  cropsHarvested: number;
  wheatHarvested: number;
  cornHarvested: number;
  breadBaked: number;
  feedProduced: number;
  eggsCollected: number;
  fertilizerUsed: number;
  mineWorksCompleted: number;
  stoneMined: number;
  ironMined: number;
  toolsCrafted: number;
  buildingsUpgraded: number;
  warehouseUpgraded: number;
  ordersDelivered: number;
}

export interface GameState {
  version: number;
  gold: number;
  xp: number;
  level: number;
  warehouseCapacity: number;
  inventory: Inventory;
  plots: PlotState[];
  buildings: Record<BuildingId, BuildingState>;
  mine: MineState;
  orders: OrderSlot[];
  villageMarket: VillageMarketState;
  stats: PlayerStats;
  claimedQuestIds: string[];
  tutorialDismissed: boolean;
  lastSavedAt: number;
}

export interface ActionResult {
  ok: boolean;
  message: string;
  leveledUpTo?: number;
}
