import type { BuildingId, CropId, GameState, Inventory, ItemId, MineNodeId, OrderRequirement } from './types';

export interface ItemConfig {
  id: ItemId;
  name: string;
  category: 'Tarım' | 'Hayvancılık' | 'Üretim' | 'Madencilik';
  sellPrice: number;
  origin: string;
  usage: string;
}

export interface CropConfig {
  id: CropId;
  name: string;
  seedCost: number;
  durationMs: number;
  yieldAmount: number;
  xpOnHarvest: number;
  unlockLevel: number;
  description: string;
}

export interface BuildingConfig {
  id: BuildingId;
  name: string;
  unlockLevel: number;
  description: string;
  inputs: { itemId: ItemId; amount: number }[];
  outputs: { itemId: ItemId; amount: number }[];
  baseDurationMs: number;
  xpOnCollect: number;
  maxLevel: number;
  idleLabel: string;
  activeLabel: string;
  collectLabel: string;
}

export interface MineNodeConfig {
  id: MineNodeId;
  name: string;
  description: string;
  durationMs: number;
  outputs: { itemId: ItemId; amount: number }[];
  xpOnCollect: number;
}

export interface OrderTemplate {
  id: string;
  customerName: string;
  title: string;
  minLevel: number;
  requiresMarketRepaired?: boolean;
  requirements: OrderRequirement[];
  goldReward: number;
  xpReward: number;
}

export interface QuestStepConfig {
  id: string;
  title: string;
  instruction: string;
  target: 'plots' | 'bakery' | 'orders' | 'feed_mill' | 'coop' | 'mine' | 'workshop' | 'village_market' | 'warehouse';
  minLevelToShow: number;
  xpBonus: number;
  goldBonus: number;
  checkCompleted: (state: GameState) => boolean;
}

// ============================================================================
// SINGLE BALANCE CONFIGURATION SECTION
// ============================================================================
export const GAME_CONFIG = {
  saveKey: 'mevsim_vadisi_save_v1',
  saveVersion: 1,

  plotCount: 6,
  initialGold: 15,
  initialWarehouseCapacity: 20,

  // XP required to reach level N (index 0 = Lv1, index 1 = Lv2, index 2 = Lv3, index 3 = Lv4, index 4 = Lv5)
  levelThresholds: [0, 25, 70, 145, 250],

  // Fertilizer balance: reduces remaining grow time by 40%, never below 2s
  fertilizerReductionRatio: 0.4,
  minRemainingAfterFertilizerMs: 2000,

  // Building upgrade balance: each level cuts duration by 15% (Lv2: 0.85, Lv3: 0.70), never below 4s
  buildingSpeedReductionPerLevel: 0.15,
  minProductionDurationMs: 4000,

  buildingUpgradeCosts: {
    2: { tool_part: 1, stone: 2 },
    3: { tool_part: 2, stone: 4 },
  } as Record<number, { tool_part: number; stone: number }>,

  // Warehouse upgrade tiers using stone
  warehouseUpgrades: [
    { targetCapacity: 28, stoneCost: 3 },
    { targetCapacity: 36, stoneCost: 5 },
    { targetCapacity: 46, stoneCost: 8 },
  ],

  // Order cooldown when cancelled (ms)
  orderCancelCooldownMs: 12000,

  // Village Market community repair goal across all 3 pillars
  villageMarketRequirements: {
    bread: 4,
    egg: 4,
    stone: 6,
  },
  villageMarketCompletionReward: {
    gold: 45,
    xp: 35,
  },

  initialInventory: {
    wheat: 2,
    corn: 2,
    bread: 0,
    chicken_feed: 1,
    egg: 0,
    fertilizer: 0,
    stone: 0,
    iron_ore: 0,
    tool_part: 0,
  } as Inventory,
};

export const ITEMS: Record<ItemId, ItemConfig> = {
  wheat: {
    id: 'wheat',
    name: 'Buğday',
    category: 'Tarım',
    sellPrice: 2,
    origin: 'Tarla parsellerinde ücretsiz ekilip hasat edilir.',
    usage: 'Fırında ekmek pişirmede ve doğrudan siparişlerde kullanılır.',
  },
  corn: {
    id: 'corn',
    name: 'Mısır',
    category: 'Tarım',
    sellPrice: 3,
    origin: '2. seviyeden itibaren tarla parsellerinde yetiştirilir.',
    usage: 'Yem Değirmeni’nde tavuk yemine dönüştürülür ve siparişlerde kullanılır.',
  },
  bread: {
    id: 'bread',
    name: 'Köy Ekmeği',
    category: 'Üretim',
    sellPrice: 7,
    origin: 'Fırında 2 Buğday kullanılarak pişirilir.',
    usage: 'Sipariş panosunda yüksek altın kazandırır ve Köy Pazarı onarımında kullanılır.',
  },
  chicken_feed: {
    id: 'chicken_feed',
    name: 'Tavuk Yemi',
    category: 'Üretim',
    sellPrice: 4,
    origin: 'Yem Değirmeni’nde 2 Mısır öğütülerek üretilir.',
    usage: 'Tavuk Kümesi’nde yumurta ve gübre üretimi başlatmak için kullanılır.',
  },
  egg: {
    id: 'egg',
    name: 'Taze Yumurta',
    category: 'Hayvancılık',
    sellPrice: 6,
    origin: 'Tavuk Kümesi’ne Tavuk Yemi verilerek elde edilir.',
    usage: 'Sipariş panosunda satılır ve Köy Pazarı onarımında kullanılır.',
  },
  fertilizer: {
    id: 'fertilizer',
    name: 'Doğal Gübre',
    category: 'Hayvancılık',
    sellPrice: 3,
    origin: 'Tavuk Kümesi’nden yumurta toplanırken yan ürün olarak elde edilir.',
    usage: 'Büyüyen bir ekine bir kez uygulanarak kalan süreyi %40 azaltır.',
  },
  stone: {
    id: 'stone',
    name: 'Vadi Taşı',
    category: 'Madencilik',
    sellPrice: 3,
    origin: '3. seviyede açılan Maden’deki kaya noktalarından çıkarılır.',
    usage: 'Depo genişletme, bina geliştirme ve Köy Pazarı onarımında kullanılır.',
  },
  iron_ore: {
    id: 'iron_ore',
    name: 'Demir Cevheri',
    category: 'Madencilik',
    sellPrice: 5,
    origin: '3. seviyede açılan Maden’deki demir damarlarından çıkarılır.',
    usage: 'Atölye’de Alet Parçası üretmek için işlenir.',
  },
  tool_part: {
    id: 'tool_part',
    name: 'Alet Parçası',
    category: 'Üretim',
    sellPrice: 12,
    origin: 'Atölye’de 2 Demir Cevheri işlenerek üretilir.',
    usage: 'Fırın, Yem Değirmeni, Tavuk Kümesi ve Atölye’yi geliştirmede kullanılır.',
  },
};

export const CROPS: Record<CropId, CropConfig> = {
  wheat: {
    id: 'wheat',
    name: 'Buğday',
    seedCost: 0,
    durationMs: 10000,
    yieldAmount: 2,
    xpOnHarvest: 3,
    unlockLevel: 1,
    description: 'Ücretsiz temel ekin. Parasız kaldığında bile ekebilirsin.',
  },
  corn: {
    id: 'corn',
    name: 'Mısır',
    seedCost: 2,
    durationMs: 14000,
    yieldAmount: 2,
    xpOnHarvest: 4,
    unlockLevel: 2,
    description: 'Tavuk yemi üretiminin ana hammaddesi.',
  },
};

export const BUILDINGS: Record<BuildingId, BuildingConfig> = {
  bakery: {
    id: 'bakery',
    name: 'Taş Fırın',
    unlockLevel: 1,
    description: 'Odun ateşinde buğdaydan sıcak köy ekmeği pişirir.',
    inputs: [{ itemId: 'wheat', amount: 2 }],
    outputs: [{ itemId: 'bread', amount: 1 }],
    baseDurationMs: 12000,
    xpOnCollect: 7,
    maxLevel: 3,
    idleLabel: 'Ekmek Pişir',
    activeLabel: 'Fırında Pişiyor',
    collectLabel: 'Ekmeği Al',
  },
  feed_mill: {
    id: 'feed_mill',
    name: 'Yem Değirmeni',
    unlockLevel: 2,
    description: 'Altın mısır tanelerini tavuklar için besleyici yeme öğütür.',
    inputs: [{ itemId: 'corn', amount: 2 }],
    outputs: [{ itemId: 'chicken_feed', amount: 2 }],
    baseDurationMs: 10000,
    xpOnCollect: 6,
    maxLevel: 3,
    idleLabel: 'Yem Öğüt',
    activeLabel: 'Yem Öğütülüyor',
    collectLabel: 'Yemi Al',
  },
  coop: {
    id: 'coop',
    name: 'Tavuk Kümesi',
    unlockLevel: 2,
    description: 'Yem verilen tavuklar taze yumurta ve doğal gübre üretir. Açlıktan ölmezler.',
    inputs: [{ itemId: 'chicken_feed', amount: 1 }],
    outputs: [
      { itemId: 'egg', amount: 2 },
      { itemId: 'fertilizer', amount: 1 },
    ],
    baseDurationMs: 15000,
    xpOnCollect: 8,
    maxLevel: 3,
    idleLabel: 'Yem Ver',
    activeLabel: 'Tavuklar Kuluçkada',
    collectLabel: 'Yumurta ve Gübre Topla',
  },
  workshop: {
    id: 'workshop',
    name: 'Demir Atölyesi',
    unlockLevel: 3,
    description: 'Demir cevherini binaları güçlendiren dayanıklı alet parçalarına döver.',
    inputs: [{ itemId: 'iron_ore', amount: 2 }],
    outputs: [{ itemId: 'tool_part', amount: 1 }],
    baseDurationMs: 14000,
    xpOnCollect: 10,
    maxLevel: 3,
    idleLabel: 'Alet Parçası Üret',
    activeLabel: 'Örste İşleniyor',
    collectLabel: 'Alet Parçasını Al',
  },
};

export const MINE_NODES: Record<MineNodeId, MineNodeConfig> = {
  stone_ridge: {
    id: 'stone_ridge',
    name: 'Kireçtaşı Yamacı',
    description: 'Onarım ve depo büyütme için bolca vadi taşı çıkarır.',
    durationMs: 10000,
    outputs: [{ itemId: 'stone', amount: 2 }],
    xpOnCollect: 6,
  },
  iron_vein: {
    id: 'iron_vein',
    name: 'Kızıl Demir Damarı',
    description: 'Atölyede alet parçasına dönüşecek ham demir cevheri verir.',
    durationMs: 14000,
    outputs: [{ itemId: 'iron_ore', amount: 2 }],
    xpOnCollect: 8,
  },
  mixed_boulder: {
    id: 'mixed_boulder',
    name: 'Karma Vadi Kayası',
    description: 'Aynı çalışmada hem taş hem demir cevheri sağlar.',
    durationMs: 15000,
    outputs: [
      { itemId: 'stone', amount: 1 },
      { itemId: 'iron_ore', amount: 1 },
    ],
    xpOnCollect: 8,
  },
};

export const ORDER_TEMPLATES: OrderTemplate[] = [
  // Level 1 orders (Wheat & Bread only)
  {
    id: 'ord_l1_wheat',
    customerName: 'Fırıncı Zeliha',
    title: 'Sabahlık Buğday',
    minLevel: 1,
    requirements: [{ itemId: 'wheat', amount: 3 }],
    goldReward: 8,
    xpReward: 10,
  },
  {
    id: 'ord_l1_bread',
    customerName: 'Zeytinlik Bekçisi Halil',
    title: 'Sıcak Köy Ekmeği',
    minLevel: 1,
    requirements: [{ itemId: 'bread', amount: 1 }],
    goldReward: 11,
    xpReward: 15,
  },
  {
    id: 'ord_l1_combo',
    customerName: 'Komşu Ayşe Teyze',
    title: 'Haftalık Kiler',
    minLevel: 1,
    requirements: [
      { itemId: 'wheat', amount: 2 },
      { itemId: 'bread', amount: 1 },
    ],
    goldReward: 15,
    xpReward: 16,
  },
  // Level 2 orders (Corn, Feed, Egg)
  {
    id: 'ord_l2_eggs',
    customerName: 'Pastacı Kerem',
    title: 'Taze Çiftlik Yumurtası',
    minLevel: 2,
    requirements: [{ itemId: 'egg', amount: 2 }],
    goldReward: 16,
    xpReward: 16,
  },
  {
    id: 'ord_l2_breakfast',
    customerName: 'Öğretmen Defne',
    title: 'Vadi Kahvaltısı',
    minLevel: 2,
    requirements: [
      { itemId: 'bread', amount: 1 },
      { itemId: 'egg', amount: 2 },
    ],
    goldReward: 24,
    xpReward: 22,
  },
  {
    id: 'ord_l2_corn',
    customerName: 'Değirmenci Osman',
    title: 'Taze Mısır Desteği',
    minLevel: 2,
    requirements: [{ itemId: 'corn', amount: 3 }],
    goldReward: 12,
    xpReward: 14,
  },
  // Level 3 orders (Stone, Iron, Tools)
  {
    id: 'ord_l3_stone',
    customerName: 'Duvar Ustası Selim',
    title: 'Bahçe Duvarı Taşı',
    minLevel: 3,
    requirements: [{ itemId: 'stone', amount: 3 }],
    goldReward: 15,
    xpReward: 18,
  },
  {
    id: 'ord_l3_supply',
    customerName: 'Marangoz İlyas',
    title: 'Tamir Paketi',
    minLevel: 3,
    requirements: [
      { itemId: 'tool_part', amount: 1 },
      { itemId: 'bread', amount: 1 },
    ],
    goldReward: 28,
    xpReward: 26,
  },
  // Village Market Repaired special orders
  {
    id: 'ord_market_feast',
    customerName: 'Köy Pazarı Esnafı',
    title: 'Pazar Günü Tezgahı',
    minLevel: 3,
    requiresMarketRepaired: true,
    requirements: [
      { itemId: 'bread', amount: 2 },
      { itemId: 'egg', amount: 3 },
    ],
    goldReward: 38,
    xpReward: 32,
  },
  {
    id: 'ord_market_artisan',
    customerName: 'Ege Kooperatifi',
    title: 'Vadi Usta Siparişi',
    minLevel: 3,
    requiresMarketRepaired: true,
    requirements: [
      { itemId: 'tool_part', amount: 1 },
      { itemId: 'egg', amount: 2 },
      { itemId: 'corn', amount: 2 },
    ],
    goldReward: 42,
    xpReward: 36,
  },
];

export const QUEST_STEPS: QuestStepConfig[] = [
  {
    id: 'q1_wheat',
    title: '1. İlk Hasat',
    instruction: 'Boş bir tarla parseline dokun, Buğday ek ve hasat et.',
    target: 'plots',
    minLevelToShow: 1,
    xpBonus: 5,
    goldBonus: 4,
    checkCompleted: (s) => s.stats.wheatHarvested >= 1,
  },
  {
    id: 'q2_bread',
    title: '2. Taş Fırını Yak',
    instruction: 'Taş Fırın’a dokunup 2 Buğday ile 1 Köy Ekmeği pişir ve al.',
    target: 'bakery',
    minLevelToShow: 1,
    xpBonus: 5,
    goldBonus: 5,
    checkCompleted: (s) => s.stats.breadBaked >= 1,
  },
  {
    id: 'q3_order',
    title: '3. İlk Köy Siparişi',
    instruction: 'Sipariş Panosu’ndan bir siparişi teslim edip 2. seviyeye geç.',
    target: 'orders',
    minLevelToShow: 1,
    xpBonus: 8,
    goldBonus: 6,
    checkCompleted: (s) => s.stats.ordersDelivered >= 1,
  },
  {
    id: 'q4_feed_mill',
    title: '4. Mısırdan Yem Üret',
    instruction: 'Mısır yetiştir ve Yem Değirmeni’nde Tavuk Yemi öğüt.',
    target: 'feed_mill',
    minLevelToShow: 2,
    xpBonus: 10,
    goldBonus: 8,
    checkCompleted: (s) => s.stats.feedProduced >= 1,
  },
  {
    id: 'q5_coop',
    title: '5. Tavuk Kümesi',
    instruction: 'Tavuk Kümesi’ne yem ver; Yumurta ve Doğal Gübre topla.',
    target: 'coop',
    minLevelToShow: 2,
    xpBonus: 12,
    goldBonus: 8,
    checkCompleted: (s) => s.stats.eggsCollected >= 1,
  },
  {
    id: 'q6_fertilizer',
    title: '6. Doğal Gübre Kullan',
    instruction: 'Büyümekte olan bir ekine dokunup 1 kez Gübre uygula.',
    target: 'plots',
    minLevelToShow: 2,
    xpBonus: 15,
    goldBonus: 8,
    checkCompleted: (s) => s.stats.fertilizerUsed >= 1,
  },
  {
    id: 'q7_mine',
    title: '7. Vadi Madeni',
    instruction: 'Maden’de bir kaya noktası seçerek Taş veya Demir Cevheri çıkar.',
    target: 'mine',
    minLevelToShow: 3,
    xpBonus: 14,
    goldBonus: 10,
    checkCompleted: (s) => s.stats.mineWorksCompleted >= 1,
  },
  {
    id: 'q8_workshop',
    title: '8. Atölye ve Geliştirme',
    instruction: 'Atölye’de Alet Parçası üret ve bir binayı geliştir (veya Depo büyüt).',
    target: 'workshop',
    minLevelToShow: 3,
    xpBonus: 16,
    goldBonus: 12,
    checkCompleted: (s) =>
      s.stats.toolsCrafted >= 1 && (s.stats.buildingsUpgraded >= 1 || s.stats.warehouseUpgraded >= 1),
  },
  {
    id: 'q9_market',
    title: '9. Köy Pazarını Canlandır',
    instruction: 'Köy Pazarı’na Ekmek, Yumurta ve Taş teslim ederek onarımı tamamla.',
    target: 'village_market',
    minLevelToShow: 3,
    xpBonus: 25,
    goldBonus: 20,
    checkCompleted: (s) => s.villageMarket.repaired,
  },
];
