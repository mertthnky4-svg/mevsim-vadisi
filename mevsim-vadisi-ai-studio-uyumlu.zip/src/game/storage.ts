import { BUILDINGS, CROPS, GAME_CONFIG, ITEMS, MINE_NODES } from './config';
import { computeLevel, createInitialGameState, refreshReadyOrders } from './engine';
import type { BuildingId, CropId, GameState, Inventory, ItemId, MineNodeId, OrderSlot } from './types';

function nonNegativeInt(val: unknown, fallback: number = 0): number {
  if (typeof val !== 'number' || !Number.isFinite(val)) return fallback;
  return Math.max(0, Math.floor(val));
}

function validTimestamp(val: unknown): number | null {
  if (typeof val !== 'number' || !Number.isFinite(val) || val <= 0) return null;
  return Math.floor(val);
}

export function sanitizeLoadedState(raw: unknown, now: number = Date.now()): {
  state: GameState;
  recoveredFromCorrupt: boolean;
} {
  const base = createInitialGameState(now);
  if (!raw || typeof raw !== 'object') {
    return { state: base, recoveredFromCorrupt: true };
  }

  try {
    const obj = raw as Record<string, unknown>;

    const xp = nonNegativeInt(obj.xp, base.xp);
    const level = computeLevel(xp);
    const gold = nonNegativeInt(obj.gold, base.gold);
    const warehouseCapacity = Math.max(
      GAME_CONFIG.initialWarehouseCapacity,
      nonNegativeInt(obj.warehouseCapacity, base.warehouseCapacity)
    );

    const rawInv = (obj.inventory && typeof obj.inventory === 'object'
      ? obj.inventory
      : {}) as Record<string, unknown>;
    const inventory: Inventory = { ...base.inventory };
    for (const itemId of Object.keys(ITEMS) as ItemId[]) {
      inventory[itemId] = nonNegativeInt(rawInv[itemId], base.inventory[itemId]);
    }

    const rawPlots = Array.isArray(obj.plots) ? obj.plots : [];
    const plots = base.plots.map((defaultPlot, idx) => {
      const candidate = rawPlots[idx] as Record<string, unknown> | undefined;
      if (!candidate || typeof candidate !== 'object') return defaultPlot;
      const cropId =
        typeof candidate.cropId === 'string' && candidate.cropId in CROPS
          ? (candidate.cropId as CropId)
          : null;
      const status: 'empty' | 'growing' =
        candidate.status === 'growing' && cropId ? 'growing' : 'empty';
      const plantedAt = status === 'growing' ? validTimestamp(candidate.plantedAt) ?? now : null;
      const completesAt =
        status === 'growing'
          ? validTimestamp(candidate.completesAt) ?? now + (cropId ? CROPS[cropId].durationMs : 10000)
          : null;
      return {
        id: idx,
        status,
        cropId: status === 'growing' ? cropId : null,
        plantedAt,
        completesAt,
        fertilized: status === 'growing' ? Boolean(candidate.fertilized) : false,
      };
    });

    const rawBuildings = (obj.buildings && typeof obj.buildings === 'object'
      ? obj.buildings
      : {}) as Record<string, unknown>;
    const buildings = { ...base.buildings };
    for (const bId of Object.keys(BUILDINGS) as BuildingId[]) {
      const candidate = rawBuildings[bId] as Record<string, unknown> | undefined;
      if (!candidate || typeof candidate !== 'object') continue;
      const bLevel = Math.max(
        1,
        Math.min(BUILDINGS[bId].maxLevel, nonNegativeInt(candidate.level, 1) || 1)
      );
      const status: 'idle' | 'producing' =
        candidate.status === 'producing' ? 'producing' : 'idle';
      const startedAt = status === 'producing' ? validTimestamp(candidate.startedAt) ?? now : null;
      const completesAt =
        status === 'producing'
          ? validTimestamp(candidate.completesAt) ?? now + BUILDINGS[bId].baseDurationMs
          : null;
      buildings[bId] = {
        id: bId,
        level: bLevel,
        status,
        startedAt,
        completesAt,
      };
    }

    const rawMine = (obj.mine && typeof obj.mine === 'object' ? obj.mine : {}) as Record<string, unknown>;
    const activeNodeId =
      typeof rawMine.activeNodeId === 'string' && rawMine.activeNodeId in MINE_NODES
        ? (rawMine.activeNodeId as MineNodeId)
        : null;
    const mineWorking = rawMine.status === 'working' && activeNodeId !== null;
    const mine = {
      status: mineWorking ? ('working' as const) : ('idle' as const),
      activeNodeId: mineWorking ? activeNodeId : null,
      startedAt: mineWorking ? validTimestamp(rawMine.startedAt) ?? now : null,
      completesAt: mineWorking
        ? validTimestamp(rawMine.completesAt) ?? now + (activeNodeId ? MINE_NODES[activeNodeId].durationMs : 10000)
        : null,
    };

    const rawOrders = Array.isArray(obj.orders) ? obj.orders : [];
    const orders: OrderSlot[] = base.orders.map((defaultSlot, idx) => {
      const candidate = rawOrders[idx] as Record<string, unknown> | undefined;
      if (!candidate || typeof candidate !== 'object') return defaultSlot;
      const reqs = Array.isArray(candidate.requirements)
        ? candidate.requirements
            .map((r): { itemId: ItemId; amount: number } | null => {
              if (!r || typeof r !== 'object') return null;
              const rec = r as Record<string, unknown>;
              if (typeof rec.itemId !== 'string' || !(rec.itemId in ITEMS)) return null;
              const amt = nonNegativeInt(rec.amount);
              if (amt <= 0) return null;
              return { itemId: rec.itemId as ItemId, amount: amt };
            })
            .filter((r): r is { itemId: ItemId; amount: number } => r !== null)
        : [];
      if (reqs.length === 0) return defaultSlot;

      return {
        slotIndex: idx,
        id: typeof candidate.id === 'string' ? candidate.id : defaultSlot.id,
        customerName:
          typeof candidate.customerName === 'string' ? candidate.customerName : defaultSlot.customerName,
        title: typeof candidate.title === 'string' ? candidate.title : defaultSlot.title,
        isMarketSpecial: Boolean(candidate.isMarketSpecial),
        status: candidate.status === 'cooldown' ? 'cooldown' : 'active',
        requirements: reqs,
        goldReward: nonNegativeInt(candidate.goldReward, defaultSlot.goldReward),
        xpReward: nonNegativeInt(candidate.xpReward, defaultSlot.xpReward),
        cooldownEndsAt:
          candidate.status === 'cooldown'
            ? validTimestamp(candidate.cooldownEndsAt) ?? now + GAME_CONFIG.orderCancelCooldownMs
            : null,
      };
    });

    const rawMarket = (obj.villageMarket && typeof obj.villageMarket === 'object'
      ? obj.villageMarket
      : {}) as Record<string, unknown>;
    const rawDelivered = (rawMarket.delivered && typeof rawMarket.delivered === 'object'
      ? rawMarket.delivered
      : {}) as Record<string, unknown>;

    const delivered = {
      bread: Math.min(
        GAME_CONFIG.villageMarketRequirements.bread,
        nonNegativeInt(rawDelivered.bread, 0)
      ),
      egg: Math.min(
        GAME_CONFIG.villageMarketRequirements.egg,
        nonNegativeInt(rawDelivered.egg, 0)
      ),
      stone: Math.min(
        GAME_CONFIG.villageMarketRequirements.stone,
        nonNegativeInt(rawDelivered.stone, 0)
      ),
    };

    const villageMarket = {
      delivered,
      repaired: Boolean(rawMarket.repaired),
      repairedAt: validTimestamp(rawMarket.repairedAt),
    };

    const rawStats = (obj.stats && typeof obj.stats === 'object'
      ? obj.stats
      : {}) as Record<string, unknown>;
    const stats = {
      cropsHarvested: nonNegativeInt(rawStats.cropsHarvested, 0),
      wheatHarvested: nonNegativeInt(rawStats.wheatHarvested, 0),
      cornHarvested: nonNegativeInt(rawStats.cornHarvested, 0),
      breadBaked: nonNegativeInt(rawStats.breadBaked, 0),
      feedProduced: nonNegativeInt(rawStats.feedProduced, 0),
      eggsCollected: nonNegativeInt(rawStats.eggsCollected, 0),
      fertilizerUsed: nonNegativeInt(rawStats.fertilizerUsed, 0),
      mineWorksCompleted: nonNegativeInt(rawStats.mineWorksCompleted, 0),
      stoneMined: nonNegativeInt(rawStats.stoneMined, 0),
      ironMined: nonNegativeInt(rawStats.ironMined, 0),
      toolsCrafted: nonNegativeInt(rawStats.toolsCrafted, 0),
      buildingsUpgraded: nonNegativeInt(rawStats.buildingsUpgraded, 0),
      warehouseUpgraded: nonNegativeInt(rawStats.warehouseUpgraded, 0),
      ordersDelivered: nonNegativeInt(rawStats.ordersDelivered, 0),
    };

    const claimedQuestIds = Array.isArray(obj.claimedQuestIds)
      ? obj.claimedQuestIds.filter((id): id is string => typeof id === 'string')
      : [];

    const sanitized: GameState = {
      version: GAME_CONFIG.saveVersion,
      gold,
      xp,
      level,
      warehouseCapacity,
      inventory,
      plots,
      buildings,
      mine,
      orders,
      villageMarket,
      stats,
      claimedQuestIds,
      tutorialDismissed: Boolean(obj.tutorialDismissed),
      lastSavedAt: validTimestamp(obj.lastSavedAt) ?? now,
    };

    return {
      state: refreshReadyOrders(sanitized, now),
      recoveredFromCorrupt: false,
    };
  } catch {
    return { state: base, recoveredFromCorrupt: true };
  }
}

export function loadGameState(now: number = Date.now()): {
  state: GameState;
  recoveredFromCorrupt: boolean;
} {
  try {
    const rawStr = localStorage.getItem(GAME_CONFIG.saveKey);
    if (!rawStr) {
      return { state: createInitialGameState(now), recoveredFromCorrupt: false };
    }
    const parsed = JSON.parse(rawStr);
    return sanitizeLoadedState(parsed, now);
  } catch {
    return { state: createInitialGameState(now), recoveredFromCorrupt: true };
  }
}

export function saveGameState(state: GameState): void {
  try {
    localStorage.setItem(GAME_CONFIG.saveKey, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors cleanly without crashing gameplay
  }
}

export function resetSavedGame(now: number = Date.now()): GameState {
  const fresh = createInitialGameState(now);
  saveGameState(fresh);
  return fresh;
}
