import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { MapControls } from 'three/addons/controls/MapControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Compass, RotateCw } from 'lucide-react';
import { BUILDINGS, CROPS, MINE_NODES } from '../game/config';
import type { BuildingId, GameState, MapFocusTarget, MineNodeId } from '../game/types';
import {
  animatePlotCrops,
  createBakery3D,
  createCoop3D,
  createCypressTree3D,
  createFeedMill3D,
  createMineArea3D,
  createOliveTree3D,
  createOrderBoard3D,
  createPlot3D,
  createValleyDecorations,
  createVillageMarket3D,
  createWarehouse3D,
  createWorkshop3D,
  type BuildingRig,
  type MarketRig,
  type MineNodeRig,
  type PlotRig,
} from '../three/builders';
import { createValleyMaterials, type GroundMapSpec } from '../three/materials';
import { ItemIcon } from './ItemIcon';

export type SelectedEntity =
  | { kind: 'plot'; plotId: number }
  | { kind: 'building'; buildingId: BuildingId }
  | { kind: 'mine'; nodeId?: MineNodeId }
  | { kind: 'orders' }
  | { kind: 'warehouse' }
  | { kind: 'village_market' }
  | null;

interface Valley3DSceneProps {
  state: GameState;
  now: number;
  highlightTarget: MapFocusTarget | null;
  selectedEntity: SelectedEntity;
  focusRequest: { target: MapFocusTarget; seq: number } | null;
  onSelectPlot: (plotId: number) => void;
  onSelectBuilding: (buildingId: BuildingId) => void;
  onSelectMine: (preferredNode?: MineNodeId) => void;
  onSelectOrders: () => void;
  onSelectWarehouse: () => void;
  onSelectVillageMarket: () => void;
}

type AnchorKey =
  | 'plot_0'
  | 'plot_1'
  | 'plot_2'
  | 'plot_3'
  | 'plot_4'
  | 'plot_5'
  | 'bakery'
  | 'warehouse'
  | 'feed_mill'
  | 'coop'
  | 'mine'
  | 'workshop'
  | 'orders'
  | 'village_market'
  | 'node_stone_ridge'
  | 'node_iron_vein'
  | 'node_mixed_boulder';

// Convert isometric screen-aligned (u = right, v = down) into 3D world (x, z) for 45° azimuth
function isoToWorld(u: number, v: number): [number, number] {
  const s = Math.SQRT1_2;
  return [(u + v) * s, (-u + v) * s];
}

// 2x3 center crop plots with clear grassy walking aisles
const PLOT_COORDS: [number, number][] = [
  isoToWorld(-3.05, -1.65),
  isoToWorld(0, -1.65),
  isoToWorld(3.05, -1.65),
  isoToWorld(-3.05, 1.65),
  isoToWorld(0, 1.65),
  isoToWorld(3.05, 1.65),
];

// Reference layout positions (cohesive composition with zero edge clipping)
const BUILDING_COORDS: Record<BuildingId, [number, number]> = {
  bakery: isoToWorld(-7.6, 3.6), // Sol alt (bottom-left)
  feed_mill: isoToWorld(-1.4, -5.9), // Arka orta (back-center)
  coop: isoToWorld(7.6, 2.8), // Sağ alt çitli kümes (right yard)
  workshop: isoToWorld(9.4, -0.8), // Maden yakınında sağ orta (mid-right)
};

const WAREHOUSE_COORD: [number, number] = isoToWorld(-7.2, -1.5); // Sol orta (mid-left)
const MARKET_COORD: [number, number] = isoToWorld(-8.6, -5.8); // Sol arka (top-left)
const ORDERS_COORD: [number, number] = isoToWorld(4.3, 5.75); // Alt yol kenarı (Plot 5 ile çakışmaz)
const MINE_PORTAL_COORD: [number, number] = isoToWorld(5.8, -6.5); // Sağ arka kayalık yamaç (top-right)
const MINE_NODE_COORDS: Record<MineNodeId, [number, number]> = {
  stone_ridge: isoToWorld(3.7, -3.1),
  iron_vein: isoToWorld(5.8, -2.75),
  mixed_boulder: isoToWorld(7.8, -3.25),
};

const DEFAULT_CENTER = isoToWorld(-0.4, -1.7);

const TARGET_WORLD_FOCUS: Record<MapFocusTarget, [number, number]> = {
  plots: [0, 0],
  bakery: BUILDING_COORDS.bakery,
  warehouse: WAREHOUSE_COORD,
  feed_mill: BUILDING_COORDS.feed_mill,
  coop: BUILDING_COORDS.coop,
  mine: isoToWorld(5.9, -4.2),
  workshop: BUILDING_COORDS.workshop,
  orders: ORDERS_COORD,
  village_market: MARKET_COORD,
};

// True isometric camera constants: azimuth 45° + 90° steps, elevation 35.264°
const ISO_POLAR = Math.acos(1 / Math.sqrt(3));
const ISO_BASE_AZIMUTH = Math.PI / 4;
const CAM_DIST = 34;

const _projVec = new THREE.Vector3();

function computeIsoOffset(azimuth: number, out: THREE.Vector3): THREE.Vector3 {
  const sinP = Math.sin(ISO_POLAR);
  const cosP = Math.cos(ISO_POLAR);
  out.set(
    CAM_DIST * sinP * Math.sin(azimuth),
    CAM_DIST * cosP,
    CAM_DIST * sinP * Math.cos(azimuth)
  );
  return out;
}

function updateOrthoFrustum(camera: THREE.OrthographicCamera, width: number, height: number) {
  // Reserve compact top/bottom HUD clearance on narrow viewports when calculating usable framing
  const safeTopPad = width < 640 ? 44 : 12;
  const usableH = Math.max(180, height - safeTopPad);
  const aspect = Math.max(0.35, width / Math.max(1, height));

  let baseHalfHeight: number;
  if (aspect >= 1.25) {
    // Desktop/landscape: tight framing minimizing unused bottom space while keeping Market & Mine unclipped
    baseHalfHeight = 6.75;
  } else {
    // Portrait/tablet: widen orthographic halfWidth to frame core farm & buildings comfortably
    const desiredHalfWidth = Math.min(11.6, 9.6 + (1.25 - aspect) * 2.8);
    baseHalfHeight = Math.min(21.5, desiredHalfWidth / aspect);
    baseHalfHeight *= height / usableH;
  }

  const halfWidth = baseHalfHeight * aspect;
  camera.left = -halfWidth;
  camera.right = halfWidth;
  camera.top = baseHalfHeight;
  camera.bottom = -baseHalfHeight;
  camera.updateProjectionMatrix();
}

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function buildGroundMapSpec(): GroundMapSpec {
  const pt = (u: number, v: number) => {
    const [x, z] = isoToWorld(u, v);
    return { x, z };
  };

  return {
    worldSize: 64,
    paths: [
      // Left avenue: Bakery -> Plots junction -> Barn -> Village Market
      {
        width: 1.25,
        pts: [
          pt(-6.2, 3.6),
          pt(-5.2, 2.2),
          pt(-5.0, 0.2),
          pt(-5.4, -1.5),
          pt(-6.5, -3.5),
          pt(-7.8, -4.6),
        ],
      },
      // Barn doorstep spur
      {
        width: 1.15,
        pts: [pt(-7.1, -0.5), pt(-5.4, -1.2)],
      },
      // Upper valley road: Plots/Barn junction -> Feed Mill -> Mine clearing -> Workshop
      {
        width: 1.2,
        pts: [
          pt(-5.0, -2.5),
          pt(-2.8, -3.9),
          pt(-1.0, -4.4),
          pt(2.4, -4.1),
          pt(5.8, -3.9),
          pt(8.2, -2.0),
          pt(9.0, -0.2),
        ],
      },
      // Feed Mill spur
      {
        width: 1.05,
        pts: [pt(-1.3, -5.2), pt(-1.0, -4.3)],
      },
      // Mine tunnel entrance spur
      {
        width: 1.1,
        pts: [pt(5.8, -5.0), pt(5.8, -3.9)],
      },
      // Lower valley avenue: Bakery -> South of Plots -> Order Board -> Coop Gate
      {
        width: 1.22,
        pts: [
          pt(-5.8, 3.8),
          pt(-3.2, 4.1),
          pt(0.2, 4.3),
          pt(4.1, 4.85),
          pt(5.9, 3.85),
          pt(7.2, 2.7),
        ],
      },
      // Order Board spur
      {
        width: 1.0,
        pts: [pt(4.2, 4.85), pt(4.3, 5.55)],
      },
      // Right connector: Coop -> Workshop
      {
        width: 1.05,
        pts: [pt(7.6, 1.5), pt(8.6, 0.2)],
      },
      // Central shortcut from plots north edge to upper path
      {
        width: 1.0,
        pts: [pt(0, -3.1), pt(0, -4.3)],
      },
    ],
    earthPatches: [
      { x: WAREHOUSE_COORD[0], z: WAREHOUSE_COORD[1], rx: 2.3, rz: 1.9, rot: 0.2 },
      { x: BUILDING_COORDS.feed_mill[0], z: BUILDING_COORDS.feed_mill[1], rx: 1.7, rz: 1.6 },
      { x: MINE_PORTAL_COORD[0] + 0.3, z: MINE_PORTAL_COORD[1] + 1.5, rx: 3.3, rz: 2.3, rot: -0.2 },
    ],
    grassDarkPatches: [
      { x: BUILDING_COORDS.coop[0], z: BUILDING_COORDS.coop[1], r: 3.1 },
      { x: BUILDING_COORDS.bakery[0] - 1.2, z: BUILDING_COORDS.bakery[1] + 0.8, r: 2.6 },
      { x: MARKET_COORD[0] - 1.5, z: MARKET_COORD[1] - 0.5, r: 3.2 },
    ],
  };
}

export const Valley3DScene: React.FC<Valley3DSceneProps> = ({
  state,
  now,
  highlightTarget,
  selectedEntity,
  focusRequest,
  onSelectPlot,
  onSelectBuilding,
  onSelectMine,
  onSelectOrders,
  onSelectWarehouse,
  onSelectVillageMarket,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const labelRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [webglError, setWebglError] = useState<string | null>(null);

  const stateRef = useRef(state);
  stateRef.current = state;
  const nowRef = useRef(now);
  nowRef.current = now;
  const highlightRef = useRef(highlightTarget);
  highlightRef.current = highlightTarget;
  const selectedRef = useRef(selectedEntity);
  selectedRef.current = selectedEntity;

  const callbacksRef = useRef({
    onSelectPlot,
    onSelectBuilding,
    onSelectMine,
    onSelectOrders,
    onSelectWarehouse,
    onSelectVillageMarket,
  });
  callbacksRef.current = {
    onSelectPlot,
    onSelectBuilding,
    onSelectMine,
    onSelectOrders,
    onSelectWarehouse,
    onSelectVillageMarket,
  };

  const camGoalRef = useRef<{
    targetX: number;
    targetZ: number;
    azimuth: number;
    zoom: number;
    active: boolean;
  }>({
    targetX: DEFAULT_CENTER[0],
    targetZ: DEFAULT_CENTER[1],
    azimuth: ISO_BASE_AZIMUTH,
    zoom: 1,
    active: false,
  });
  const azimuthStepRef = useRef<number>(0);

  const triggerCameraFocus = (tx: number, tz: number, step?: number, zoom?: number) => {
    if (typeof step === 'number') {
      azimuthStepRef.current = step;
    }
    camGoalRef.current.targetX = tx;
    camGoalRef.current.targetZ = tz;
    camGoalRef.current.azimuth = ISO_BASE_AZIMUTH + azimuthStepRef.current * (Math.PI / 2);
    if (typeof zoom === 'number') {
      camGoalRef.current.zoom = zoom;
    }
    camGoalRef.current.active = true;
  };

  useEffect(() => {
    if (focusRequest) {
      const [fx, fz] = TARGET_WORLD_FOCUS[focusRequest.target];
      triggerCameraFocus(fx, fz);
    }
  }, [focusRequest]);

  // Mount Three.js scene ONCE
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    let renderer: THREE.WebGLRenderer;

    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError('3B görünüm başlatılamadı (WebGL desteklenmiyor).');
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.96;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.touchAction = 'none';

    container.appendChild(renderer.domElement);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      setWebglError('3B grafik bağlamı kesildi. Sayfayı yenileyebilirsin.');
    };
    const onContextRestored = () => {
      setWebglError(null);
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x739747); // Seamless olive meadow ground color (zero sky/fog washout)

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    scene.environmentIntensity = 0.34;
    pmremGenerator.dispose();

    const camera = new THREE.OrthographicCamera(-10, 10, 10, -10, 0.5, 140);
    updateOrthoFrustum(camera, container.clientWidth, container.clientHeight);

    const initialOffset = computeIsoOffset(ISO_BASE_AZIMUTH, new THREE.Vector3());
    camera.position.set(
      DEFAULT_CENTER[0] + initialOffset.x,
      initialOffset.y,
      DEFAULT_CENTER[1] + initialOffset.z
    );

    const controls = new MapControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.enableRotate = false; // Lock isometric elevation & free tilt
    controls.enableZoom = true;
    controls.minZoom = 0.45;
    controls.maxZoom = 1.85;
    controls.enablePan = true;
    controls.screenSpacePanning = false;
    controls.target.set(DEFAULT_CENTER[0], 0, DEFAULT_CENTER[1]);
    controls.update();

    const cancelAutoCam = () => {
      camGoalRef.current.active = false;
    };
    controls.addEventListener('start', cancelAutoCam);

    // Warm upper-left Aegean sun + cool-sky/warm-earth hemisphere balance for clear facade separation
    const hemiLight = new THREE.HemisphereLight(0xdceaf4, 0x594a31, 0.48);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xffe7b6, 1.40);
    sunLight.position.set(-10, 24, 16);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 2;
    sunLight.shadow.camera.far = 65;
    const shadowExtent = 18;
    sunLight.shadow.camera.left = -shadowExtent;
    sunLight.shadow.camera.right = shadowExtent;
    sunLight.shadow.camera.top = shadowExtent;
    sunLight.shadow.camera.bottom = -shadowExtent;
    sunLight.shadow.bias = -0.0004;
    sunLight.shadow.normalBias = 0.02;
    scene.add(sunLight);

    const fillLight = new THREE.DirectionalLight(0xcbe0ed, 0.28);
    fillLight.position.set(14, 10, -12);
    scene.add(fillLight);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
    const groundSpec = buildGroundMapSpec();
    const mats = createValleyMaterials(groundSpec, maxAnisotropy);
    const geometries: THREE.BufferGeometry[] = [];
    const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
      geometries.push(g);
      return g;
    };

    // Expansive continuous outer meadow + unified 64x64 procedural road/earth meadow center
    const outerGround = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(150, 150)), mats.grassOuter);
    outerGround.rotation.x = -Math.PI / 2;
    outerGround.position.y = -0.005;
    outerGround.receiveShadow = true;
    scene.add(outerGround);

    const centerGround = new THREE.Mesh(
      trackGeo(new THREE.PlaneGeometry(groundSpec.worldSize, groundSpec.worldSize)),
      mats.groundMeadow
    );
    centerGround.rotation.x = -Math.PI / 2;
    centerGround.position.y = 0;
    centerGround.receiveShadow = true;
    scene.add(centerGround);

    // Non-blocking environment decorations (layer 0 only)
    scene.add(createValleyDecorations(mats, geometries));

    // Perimeter olive & cypress trees framing the valley without obscuring gameplay buildings or paths
    const treePlacements: { type: 'olive' | 'cypress'; u: number; v: number; s: number }[] = [
      { type: 'olive', u: -13.2, v: -3.2, s: 1.04 },
      { type: 'olive', u: -12.4, v: 1.4, s: 1.06 },
      { type: 'olive', u: -11.4, v: 5.0, s: 0.96 },
      { type: 'olive', u: -4.6, v: -6.4, s: 1.0 },
      { type: 'cypress', u: 1.6, v: -7.1, s: 1.1 },
      { type: 'cypress', u: 2.8, v: -6.8, s: 0.98 },
      { type: 'olive', u: 5.0, v: 0.35, s: 0.84 },
      { type: 'olive', u: 12.2, v: 3.6, s: 1.05 },
      { type: 'cypress', u: 11.6, v: -4.6, s: 1.05 },
    ];
    treePlacements.forEach((tp, idx) => {
      const [tx, tz] = isoToWorld(tp.u, tp.v);
      const tMesh =
        tp.type === 'olive'
          ? createOliveTree3D(mats, geometries, idx)
          : createCypressTree3D(mats, geometries, idx);
      tMesh.position.set(tx, 0, tz);
      tMesh.scale.setScalar(tp.s);
      scene.add(tMesh);
    });

    // Interactive Entities
    const clickableMeshes: THREE.Object3D[] = [];

    // 6 Plots rotated 45° so the 2x3 grid sits cleanly horizontally/vertically
    const plotRigs: PlotRig[] = PLOT_COORDS.map(([px, pz], idx) => {
      const rig = createPlot3D(idx, mats, geometries);
      rig.group.position.set(px, 0.01, pz);
      rig.group.rotation.y = Math.PI / 4;
      scene.add(rig.group);
      clickableMeshes.push(rig.hitMesh);
      return rig;
    });

    // Buildings aligned consistently with world isometric axes so roofs & 2 facades read clearly
    const bakeryRig = createBakery3D(mats, geometries);
    bakeryRig.group.position.set(BUILDING_COORDS.bakery[0], 0, BUILDING_COORDS.bakery[1]);
    bakeryRig.group.rotation.y = 0.06;
    scene.add(bakeryRig.group);

    const feedMillRig = createFeedMill3D(mats, geometries);
    feedMillRig.group.position.set(BUILDING_COORDS.feed_mill[0], 0, BUILDING_COORDS.feed_mill[1]);
    feedMillRig.group.rotation.y = 0.08;
    scene.add(feedMillRig.group);

    const coopRig = createCoop3D(mats, geometries);
    coopRig.group.position.set(BUILDING_COORDS.coop[0], 0, BUILDING_COORDS.coop[1]);
    coopRig.group.rotation.y = 0;
    scene.add(coopRig.group);

    const workshopRig = createWorkshop3D(mats, geometries);
    workshopRig.group.position.set(BUILDING_COORDS.workshop[0], 0, BUILDING_COORDS.workshop[1]);
    workshopRig.group.rotation.y = 0;
    scene.add(workshopRig.group);

    const buildingRigs: Record<BuildingId, BuildingRig> = {
      bakery: bakeryRig,
      feed_mill: feedMillRig,
      coop: coopRig,
      workshop: workshopRig,
    };
    Object.values(buildingRigs).forEach((r) => clickableMeshes.push(r.hitMesh));

    // Warehouse
    const warehouseRig = createWarehouse3D(mats, geometries);
    warehouseRig.group.position.set(WAREHOUSE_COORD[0], 0, WAREHOUSE_COORD[1]);
    warehouseRig.group.rotation.y = 0;
    scene.add(warehouseRig.group);
    clickableMeshes.push(warehouseRig.hitMesh);

    // Order Board
    const orderRig = createOrderBoard3D(mats, geometries);
    orderRig.group.position.set(ORDERS_COORD[0], 0, ORDERS_COORD[1]);
    orderRig.group.rotation.y = 0.08;
    scene.add(orderRig.group);
    clickableMeshes.push(orderRig.hitMesh);

    // Village Market
    const marketRig: MarketRig = createVillageMarket3D(mats, geometries);
    marketRig.group.position.set(MARKET_COORD[0], 0, MARKET_COORD[1]);
    marketRig.group.rotation.y = 0;
    scene.add(marketRig.group);
    clickableMeshes.push(marketRig.hitMesh);

    // Mine Portal + 3 Ore Rock Nodes
    const mineArea = createMineArea3D(mats, geometries);
    mineArea.portalGroup.position.set(MINE_PORTAL_COORD[0], 0, MINE_PORTAL_COORD[1]);
    mineArea.portalGroup.rotation.y = -0.1;
    scene.add(mineArea.portalGroup);
    clickableMeshes.push(mineArea.portalHitMesh);

    const mineNodes: Record<MineNodeId, MineNodeRig> = mineArea.nodes;
    (Object.keys(mineNodes) as MineNodeId[]).forEach((nodeId) => {
      const [nx, nz] = MINE_NODE_COORDS[nodeId];
      mineNodes[nodeId].group.position.set(nx, 0, nz);
      scene.add(mineNodes[nodeId].group);
      clickableMeshes.push(mineNodes[nodeId].hitMesh);
    });

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Layer-1 raycasting with multi-touch, pointercancel & >8px drag guard
    const raycaster = new THREE.Raycaster();
    raycaster.layers.set(1);
    const pointerNdc = new THREE.Vector2();
    const activePointers = new Set<number>();
    let tapCandidate: { x: number; y: number; id: number } | null = null;

    const handlePointerDown = (e: PointerEvent) => {
      if (e.target !== renderer.domElement) return;
      activePointers.add(e.pointerId);
      if (activePointers.size > 1) {
        tapCandidate = null;
        return;
      }
      tapCandidate = { x: e.clientX, y: e.clientY, id: e.pointerId };
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!tapCandidate || tapCandidate.id !== e.pointerId) return;
      if (Math.hypot(e.clientX - tapCandidate.x, e.clientY - tapCandidate.y) > 8) {
        tapCandidate = null;
      }
    };

    const handlePointerCancel = (e: PointerEvent) => {
      activePointers.delete(e.pointerId);
      if (tapCandidate?.id === e.pointerId) {
        tapCandidate = null;
      }
    };

    const handlePointerUp = (e: PointerEvent) => {
      activePointers.delete(e.pointerId);
      if (!tapCandidate || tapCandidate.id !== e.pointerId) return;
      const dist = Math.hypot(e.clientX - tapCandidate.x, e.clientY - tapCandidate.y);
      tapCandidate = null;
      if (dist > 8 || activePointers.size > 0) return;

      const rect = renderer.domElement.getBoundingClientRect();
      pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointerNdc, camera);
      const hits = raycaster.intersectObjects(clickableMeshes, false);
      if (hits.length === 0) return;

      const data = hits[0].object.userData;
      const cb = callbacksRef.current;
      if (data.targetType === 'plot' && typeof data.plotId === 'number') {
        cb.onSelectPlot(data.plotId);
      } else if (data.targetType === 'building' && data.buildingId) {
        cb.onSelectBuilding(data.buildingId as BuildingId);
      } else if (data.targetType === 'mine') {
        cb.onSelectMine(data.nodeId as MineNodeId | undefined);
      } else if (data.targetType === 'orders') {
        cb.onSelectOrders();
      } else if (data.targetType === 'warehouse') {
        cb.onSelectWarehouse();
      } else if (data.targetType === 'village_market') {
        cb.onSelectVillageMarket();
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);
    renderer.domElement.addEventListener('pointermove', handlePointerMove);
    renderer.domElement.addEventListener('pointerup', handlePointerUp);
    renderer.domElement.addEventListener('pointercancel', handlePointerCancel);

    const handleResize = () => {
      if (!container) return;
      const w = Math.max(1, container.clientWidth);
      const h = Math.max(1, container.clientHeight);
      updateOrthoFrustum(camera, w, h);
      renderer.setSize(w, h);
    };
    const resizeObs = new ResizeObserver(handleResize);
    resizeObs.observe(container);

    const worldAnchors: Record<AnchorKey, [number, number, number]> = {
      plot_0: [PLOT_COORDS[0][0], 1.54, PLOT_COORDS[0][1]],
      plot_1: [PLOT_COORDS[1][0], 1.54, PLOT_COORDS[1][1]],
      plot_2: [PLOT_COORDS[2][0], 1.54, PLOT_COORDS[2][1]],
      plot_3: [PLOT_COORDS[3][0], 1.52, PLOT_COORDS[3][1]],
      plot_4: [PLOT_COORDS[4][0], 1.52, PLOT_COORDS[4][1]],
      plot_5: [PLOT_COORDS[5][0], 1.52, PLOT_COORDS[5][1]],
      bakery: [BUILDING_COORDS.bakery[0], 3.3, BUILDING_COORDS.bakery[1]],
      warehouse: [WAREHOUSE_COORD[0], 3.1, WAREHOUSE_COORD[1]],
      feed_mill: [BUILDING_COORDS.feed_mill[0], 4.0, BUILDING_COORDS.feed_mill[1]],
      coop: [BUILDING_COORDS.coop[0], 2.35, BUILDING_COORDS.coop[1]],
      mine: [MINE_PORTAL_COORD[0], 2.6, MINE_PORTAL_COORD[1]],
      workshop: [BUILDING_COORDS.workshop[0], 2.7, BUILDING_COORDS.workshop[1]],
      orders: [ORDERS_COORD[0], 2.05, ORDERS_COORD[1]],
      village_market: [MARKET_COORD[0], 3.0, MARKET_COORD[1]],
      node_stone_ridge: [MINE_NODE_COORDS.stone_ridge[0], 1.4, MINE_NODE_COORDS.stone_ridge[1]],
      node_iron_vein: [MINE_NODE_COORDS.iron_vein[0], 1.4, MINE_NODE_COORDS.iron_vein[1]],
      node_mixed_boulder: [MINE_NODE_COORDS.mixed_boulder[0], 1.4, MINE_NODE_COORDS.mixed_boulder[1]],
    };

    const _goalOffset = new THREE.Vector3();
    let currentAzimuth = ISO_BASE_AZIMUTH;

    const startMs = performance.now();
    let prevMs = startMs;
    let frameId = 0;
    let disposed = false;

    const scheduleNext = (cb: () => void) => {
      if (disposed) return;
      if (isSoftwareGl) {
        frameId = window.setTimeout(() => {
          if (!disposed) {
            frameId = requestAnimationFrame(cb);
          }
        }, 45);
      } else {
        frameId = requestAnimationFrame(cb);
      }
    };

    const tick = () => {
      if (disposed) return;
      const nowMs = performance.now();
      const delta = Math.min(0.1, Math.max(0.001, (nowMs - prevMs) / 1000));
      prevMs = nowMs;
      const elapsed = (nowMs - startMs) / 1000;
      const curState = stateRef.current;
      const curNow = nowRef.current;
      const hi = highlightRef.current;
      const sel = selectedRef.current;

      if (camGoalRef.current.active) {
        controls.target.x = THREE.MathUtils.damp(
          controls.target.x,
          camGoalRef.current.targetX,
          7,
          delta
        );
        controls.target.z = THREE.MathUtils.damp(
          controls.target.z,
          camGoalRef.current.targetZ,
          7,
          delta
        );
        currentAzimuth = THREE.MathUtils.damp(currentAzimuth, camGoalRef.current.azimuth, 7, delta);
        camera.zoom = THREE.MathUtils.damp(camera.zoom, camGoalRef.current.zoom, 7, delta);
        camera.updateProjectionMatrix();

        computeIsoOffset(currentAzimuth, _goalOffset);
        camera.position.set(
          controls.target.x + _goalOffset.x,
          _goalOffset.y,
          controls.target.z + _goalOffset.z
        );

        if (
          Math.abs(controls.target.x - camGoalRef.current.targetX) < 0.04 &&
          Math.abs(controls.target.z - camGoalRef.current.targetZ) < 0.04 &&
          Math.abs(currentAzimuth - camGoalRef.current.azimuth) < 0.01 &&
          Math.abs(camera.zoom - camGoalRef.current.zoom) < 0.01
        ) {
          camGoalRef.current.active = false;
        }
      }

      controls.target.x = THREE.MathUtils.clamp(controls.target.x, -12, 12);
      controls.target.z = THREE.MathUtils.clamp(controls.target.z, -11, 11);
      controls.update();

      // Highlight ONLY a single suggested plot when quest points to 'plots' (no 6-ring clutter!)
      const firstEmptyPlotIdx = curState.plots.findIndex((p) => p.status === 'empty');
      const questPlotIdx = firstEmptyPlotIdx >= 0 ? firstEmptyPlotIdx : 0;

      curState.plots.forEach((plot, idx) => {
        const rig = plotRigs[idx];
        if (!rig) return;
        const isGrowing = plot.status === 'growing' && plot.cropId !== null;
        const rem = isGrowing && plot.completesAt ? Math.max(0, plot.completesAt - curNow) : 0;
        const total =
          isGrowing && plot.plantedAt && plot.completesAt
            ? Math.max(1000, plot.completesAt - plot.plantedAt)
            : 1000;
        const progress = isGrowing ? Math.min(1, Math.max(0, 1 - rem / total)) : 0;
        const isReady = isGrowing && rem <= 0;
        const isSelected = sel?.kind === 'plot' && sel.plotId === idx;
        const isQuestPlot = hi === 'plots' && idx === questPlotIdx;

        const soilMat = isGrowing ? mats.soilWet : mats.soilDry;
        rig.soilMesh.material = soilMat;
        rig.ridgeMeshes.forEach((rm) => (rm.material = soilMat));
        rig.fertBadge.visible = isGrowing && plot.fertilized;

        rig.wheatSproutGroup.visible = isGrowing && !isReady && plot.cropId === 'wheat';
        rig.cornSproutGroup.visible = isGrowing && !isReady && plot.cropId === 'corn';
        if (rig.wheatSproutGroup.visible) {
          rig.wheatSproutGroup.scale.set(1, 0.4 + progress * 0.65, 1);
        }
        if (rig.cornSproutGroup.visible) {
          rig.cornSproutGroup.scale.set(1, 0.4 + progress * 0.72, 1);
        }

        rig.wheatReadyGroup.visible = isReady && plot.cropId === 'wheat';
        rig.cornReadyGroup.visible = isReady && plot.cropId === 'corn';
        if (isReady) {
          animatePlotCrops(rig, elapsed, idx);
        }

        // Only highlight selected plot (solid gold frame) or single quest-suggested plot (corner brackets)
        // Ready plots show ONLY the small crop icon above them — no large green circles
        rig.borderMesh.visible = isSelected;
        rig.questBorderMesh.visible = isQuestPlot && !isSelected;
      });

      // Bakery
      const bakeryState = curState.buildings.bakery;
      const bakeryActive = bakeryState.status === 'producing';
      const bakeryReady =
        bakeryActive && bakeryState.completesAt !== null && curNow >= bakeryState.completesAt;
      const bakeryProducingNow = bakeryActive && !bakeryReady;
      const bakerySel = sel?.kind === 'building' && sel.buildingId === 'bakery';

      if (bakeryRig.hearthMesh) {
        bakeryRig.hearthMesh.material = bakeryProducingNow ? mats.forgeGlow : mats.forgeIdle;
      }
      if (bakeryRig.ovenLight) {
        bakeryRig.ovenLight.intensity = bakeryProducingNow ? 1.8 + Math.sin(elapsed * 8) * 0.25 : 0;
      }
      bakeryRig.smokePuffs?.forEach((puff, i) => {
        if (bakeryProducingNow) {
          puff.visible = true;
          const phase = (elapsed * 0.55 + i * 0.33) % 1;
          puff.position.y = 3.55 + phase * 1.35;
          puff.scale.setScalar(0.75 + phase * 0.65);
        } else {
          puff.visible = false;
        }
      });
      bakeryRig.ringMesh.visible = bakerySel || bakeryReady || hi === 'bakery';
      bakeryRig.ringMesh.material = bakerySel
        ? mats.selectedRing
        : bakeryReady
          ? mats.readyRing
          : mats.highlightRing;

      // Feed Mill
      const millState = curState.buildings.feed_mill;
      const millActive = millState.status === 'producing';
      const millReady =
        millActive && millState.completesAt !== null && curNow >= millState.completesAt;
      const millSel = sel?.kind === 'building' && sel.buildingId === 'feed_mill';
      if (feedMillRig.sailGroup && millActive && !millReady) {
        feedMillRig.sailGroup.rotation.z -= delta * 2.1;
      }
      feedMillRig.ringMesh.visible = millSel || millReady || hi === 'feed_mill';
      feedMillRig.ringMesh.material = millSel
        ? mats.selectedRing
        : millReady
          ? mats.readyRing
          : mats.highlightRing;

      // Chicken Coop
      const coopState = curState.buildings.coop;
      const coopActive = coopState.status === 'producing';
      const coopReady =
        coopActive && coopState.completesAt !== null && curNow >= coopState.completesAt;
      const coopSel = sel?.kind === 'building' && sel.buildingId === 'coop';

      coopRig.henGroups?.forEach((h) => {
        const speed = coopActive && !coopReady ? 2.2 : 1.0;
        const t = elapsed * speed + h.phase;
        h.group.position.x = h.baseX + Math.sin(t) * 0.26;
        h.group.position.z = h.baseZ + Math.cos(t * 0.85) * 0.22;
        h.group.rotation.y = Math.atan2(Math.cos(t) * 0.26, -Math.sin(t * 0.85) * 0.22);
        const peck = Math.max(0, Math.sin(elapsed * 3.8 + h.phase * 2));
        h.group.rotation.x = peck > 0.7 ? (peck - 0.7) * 1.1 : 0;
      });
      if (coopRig.eggNestGroup) {
        coopRig.eggNestGroup.visible = coopReady;
      }
      coopRig.ringMesh.visible = coopSel || coopReady || hi === 'coop';
      coopRig.ringMesh.material = coopSel
        ? mats.selectedRing
        : coopReady
          ? mats.readyRing
          : mats.highlightRing;

      // Workshop
      const wsState = curState.buildings.workshop;
      const wsActive = wsState.status === 'producing';
      const wsReady = wsActive && wsState.completesAt !== null && curNow >= wsState.completesAt;
      const wsProducingNow = wsActive && !wsReady;
      const wsSel = sel?.kind === 'building' && sel.buildingId === 'workshop';

      if (workshopRig.forgeMesh) {
        workshopRig.forgeMesh.material = wsProducingNow ? mats.forgeGlow : mats.forgeIdle;
      }
      if (workshopRig.forgeLight) {
        workshopRig.forgeLight.intensity = wsProducingNow ? 1.9 + Math.sin(elapsed * 10) * 0.3 : 0;
      }
      workshopRig.sparks?.forEach((sp, i) => {
        if (wsProducingNow) {
          sp.visible = true;
          const phase = (elapsed * 1.9 + i * 0.25) % 1;
          sp.position.set(
            0.45 + Math.sin(i * 2.1) * phase * 0.45,
            0.88 + Math.sin(phase * Math.PI) * 0.65,
            0.62 + Math.cos(i * 1.7) * phase * 0.35
          );
        } else {
          sp.visible = false;
        }
      });
      workshopRig.ringMesh.visible = wsSel || wsReady || hi === 'workshop';
      workshopRig.ringMesh.material = wsSel
        ? mats.selectedRing
        : wsReady
          ? mats.readyRing
          : mats.highlightRing;

      // Warehouse, Order Board, Village Market
      const whSel = sel?.kind === 'warehouse';
      warehouseRig.ringMesh.visible = whSel || hi === 'warehouse';
      warehouseRig.ringMesh.material = whSel ? mats.selectedRing : mats.highlightRing;

      const ordSel = sel?.kind === 'orders';
      orderRig.ringMesh.visible = ordSel || hi === 'orders';
      orderRig.ringMesh.material = ordSel ? mats.selectedRing : mats.highlightRing;

      const mktSel = sel?.kind === 'village_market';
      marketRig.ruinedGroup.visible = !curState.villageMarket.repaired;
      marketRig.repairedGroup.visible = curState.villageMarket.repaired;
      marketRig.ringMesh.visible = mktSel || hi === 'village_market';
      marketRig.ringMesh.material = mktSel ? mats.selectedRing : mats.highlightRing;

      // Mine Nodes
      const mineWorking = curState.mine.status === 'working' && curState.mine.activeNodeId !== null;
      const mineReady =
        mineWorking && curState.mine.completesAt !== null && curNow >= curState.mine.completesAt;
      (Object.keys(mineNodes) as MineNodeId[]).forEach((nodeId) => {
        const rig = mineNodes[nodeId];
        const isThis = mineWorking && curState.mine.activeNodeId === nodeId;
        const isSel = sel?.kind === 'mine' && (sel.nodeId === nodeId || !sel.nodeId);
        rig.pickaxeGroup.visible = isThis && !mineReady;
        if (rig.pickaxeGroup.visible) {
          rig.pickaxeGroup.rotation.z = Math.sin(elapsed * 7) * 0.55;
        }
        rig.ringMesh.visible = isSel || (isThis && mineReady) || hi === 'mine';
        rig.ringMesh.material = isSel
          ? mats.selectedRing
          : isThis && mineReady
            ? mats.readyRing
            : mats.highlightRing;
      });

      renderer.render(scene, camera);

      const w = container.clientWidth;
      const h = container.clientHeight;
      const plotIconScale = THREE.MathUtils.clamp(0.76 + camera.zoom * 0.22, 0.78, 1.14);
      (Object.keys(worldAnchors) as AnchorKey[]).forEach((key) => {
        const el = labelRefs.current[key];
        if (!el) return;
        const [ax, ay, az] = worldAnchors[key];
        _projVec.set(ax, ay, az).project(camera);
        if (_projVec.z > 1 || _projVec.z < -1) {
          el.style.opacity = '0';
          return;
        }
        const rawX = ((_projVec.x + 1) * 0.5) * w;
        const rawY = ((-_projVec.y + 1) * 0.5) * h;
        const isPlotKey = key.startsWith('plot_');
        const padX = isPlotKey ? 24 : 48;
        const minY = isPlotKey ? 44 : 36;
        const maxY = isPlotKey ? h - 72 : h - 16;
        const clampedX = Math.max(padX, Math.min(w - padX, rawX));
        const clampedY = Math.max(minY, Math.min(maxY, rawY));
        el.style.opacity = '1';
        el.style.transform = isPlotKey
          ? `translate3d(${clampedX.toFixed(1)}px, ${clampedY.toFixed(1)}px, 0) translate(-50%, -100%) scale(${plotIconScale.toFixed(3)})`
          : `translate3d(${clampedX.toFixed(1)}px, ${clampedY.toFixed(1)}px, 0) translate(-50%, -100%)`;
      });

      scheduleNext(tick);
    };

    // Render frame 1 immediately so 3D scene and anchor labels appear without delay
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObs.disconnect();
      controls.removeEventListener('start', cancelAutoCam);
      controls.dispose();
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('pointerup', handlePointerUp);
      renderer.domElement.removeEventListener('pointercancel', handlePointerCancel);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);
      geometries.forEach((g) => g.dispose());
      mats.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const deliverableOrdersCount = useMemo(
    () =>
      state.orders.filter(
        (o) =>
          o.status === 'active' &&
          o.requirements.every((r) => (state.inventory[r.itemId] || 0) >= r.amount)
      ).length,
    [state.orders, state.inventory]
  );

  const firstEmptyPlotIdx = useMemo(() => {
    const idx = state.plots.findIndex((p) => p.status === 'empty');
    return idx >= 0 ? idx : 0;
  }, [state.plots]);

  const setAnchorRef = (key: AnchorKey) => (el: HTMLDivElement | null) => {
    labelRefs.current[key] = el;
  };

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#739747] select-none">
      <div ref={mountRef} className="w-full h-full" />

      {webglError && (
        <div className="absolute inset-0 flex items-center justify-center p-6 bg-[#F4EFE6]">
          <div className="max-w-sm rounded-2xl border border-[#DED4C1] bg-[#FFFDF9] p-5 text-center space-y-2 shadow-sm">
            <div className="font-display text-lg font-bold text-[#2C2A24]">3B Görünüm Hatası</div>
            <p className="text-xs text-[#6B6456]">{webglError}</p>
          </div>
        </div>
      )}

      {/* Normal view: ONLY Ready-to-collect indicators & Active Quest indicator */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
        {state.plots.map((plot, idx) => {
          const isGrowing = plot.status === 'growing' && plot.cropId && plot.completesAt;
          const rem = isGrowing && plot.completesAt ? Math.max(0, plot.completesAt - now) : 0;
          const isReady = Boolean(isGrowing && rem <= 0);
          const showQuestHint = highlightTarget === 'plots' && idx === firstEmptyPlotIdx && !isReady;

          if (!isReady && !showQuestHint) {
            return (
              <div
                key={plot.id}
                ref={setAnchorRef(`plot_${idx}` as AnchorKey)}
                className="hidden"
              />
            );
          }

          return (
            <div
              key={plot.id}
              ref={setAnchorRef(`plot_${idx}` as AnchorKey)}
              className="absolute top-0 left-0 will-change-transform origin-bottom"
            >
              {isReady && plot.cropId ? (
                <button
                  type="button"
                  onPointerDown={(e) => e.stopPropagation()}
                  onPointerUp={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectPlot(plot.id);
                  }}
                  aria-label={`${CROPS[plot.cropId].name} hasat et`}
                  className="pointer-events-auto w-7 h-7 sm:w-8 sm:h-8 rounded-full border border-[#C69C43] bg-[#FFFDF9]/95 shadow-md flex items-center justify-center hover:scale-105 active:scale-95 transition-transform cursor-pointer"
                >
                  <ItemIcon itemId={plot.cropId} size={18} className="sm:w-5 sm:h-5" />
                </button>
              ) : (
                <div className="px-1.5 sm:px-2 py-0.5 rounded-lg bg-[#C86D3B] text-white text-[10px] sm:text-[11px] font-semibold shadow-sm whitespace-nowrap">
                  Parsele dokun
                </div>
              )}
            </div>
          );
        })}

        {(['bakery', 'feed_mill', 'coop', 'workshop'] as BuildingId[]).map((bId) => {
          const cfg = BUILDINGS[bId];
          const bState = state.buildings[bId];
          const unlocked = state.level >= cfg.unlockLevel;
          const isReady =
            unlocked &&
            bState.status === 'producing' &&
            bState.completesAt !== null &&
            now >= bState.completesAt;
          const isHi = highlightTarget === bId;

          if (!isReady && !isHi) {
            return <div key={bId} ref={setAnchorRef(bId)} className="hidden" />;
          }

          return (
            <div
              key={bId}
              ref={setAnchorRef(bId)}
              className="absolute top-0 left-0 will-change-transform"
            >
              {isReady ? (
                <div className="px-1.5 sm:px-2.5 py-0.5 rounded-lg border border-[#1F4E42] bg-[#2F6F5E] text-white text-[9.5px] sm:text-[11px] font-semibold shadow-sm whitespace-nowrap">
                  {cfg.name} · Hazır
                </div>
              ) : (
                <div className="px-1.5 sm:px-2.5 py-0.5 rounded-lg bg-[#C86D3B] text-white text-[10px] sm:text-[11px] font-semibold shadow-sm whitespace-nowrap">
                  {cfg.name}
                </div>
              )}
            </div>
          );
        })}

        <div
          ref={setAnchorRef('orders')}
          className={`absolute top-0 left-0 will-change-transform ${
            deliverableOrdersCount > 0 || highlightTarget === 'orders' ? '' : 'hidden'
          }`}
        >
          {highlightTarget === 'orders' ? (
            <div className="px-2 sm:px-2.5 py-0.5 rounded-lg bg-[#C86D3B] text-white text-[10px] sm:text-[11px] font-semibold shadow-sm whitespace-nowrap">
              Sipariş Panosu
            </div>
          ) : deliverableOrdersCount > 0 ? (
            <div className="px-1.5 sm:px-2.5 py-0.5 rounded-lg border border-[#1F4E42] bg-[#2F6F5E] text-white text-[9.5px] sm:text-[11px] font-semibold shadow-sm whitespace-nowrap tabular-nums">
              {deliverableOrdersCount} Sipariş
            </div>
          ) : null}
        </div>

        <div
          ref={setAnchorRef('warehouse')}
          className={`absolute top-0 left-0 will-change-transform ${
            highlightTarget === 'warehouse' ? '' : 'hidden'
          }`}
        >
          <div className="px-2.5 py-0.5 rounded-lg bg-[#C86D3B] text-white text-[11px] font-semibold shadow-sm whitespace-nowrap">
            Ambar
          </div>
        </div>

        <div
          ref={setAnchorRef('village_market')}
          className={`absolute top-0 left-0 will-change-transform ${
            highlightTarget === 'village_market' ? '' : 'hidden'
          }`}
        >
          <div className="px-2.5 py-0.5 rounded-lg bg-[#C86D3B] text-white text-[11px] font-semibold shadow-sm whitespace-nowrap">
            Köy Pazarı
          </div>
        </div>

        <div
          ref={setAnchorRef('mine')}
          className={`absolute top-0 left-0 will-change-transform ${
            highlightTarget === 'mine' ? '' : 'hidden'
          }`}
        >
          <div className="px-2.5 py-0.5 rounded-lg bg-[#C86D3B] text-white text-[11px] font-semibold shadow-sm whitespace-nowrap">
            Kaya seç
          </div>
        </div>

        {(Object.keys(MINE_NODES) as MineNodeId[]).map((nodeId) => {
          const isActive = state.mine.status === 'working' && state.mine.activeNodeId === nodeId;
          const rem =
            isActive && state.mine.completesAt ? Math.max(0, state.mine.completesAt - now) : 0;
          const isReady = isActive && rem <= 0;

          if (!isReady) {
            return (
              <div
                key={nodeId}
                ref={setAnchorRef(`node_${nodeId}` as AnchorKey)}
                className="hidden"
              />
            );
          }

          return (
            <div
              key={nodeId}
              ref={setAnchorRef(`node_${nodeId}` as AnchorKey)}
              className="absolute top-0 left-0 will-change-transform"
            >
              <div className="px-2 py-0.5 rounded-lg border border-[#1F4E42] bg-[#2F6F5E] text-white text-[11px] font-semibold shadow-sm whitespace-nowrap">
                {MINE_NODES[nodeId].name.split(' ')[0]} · Hazır!
              </div>
            </div>
          );
        })}
      </div>

      {/* Camera Isometric Controls */}
      <div className="absolute top-2.5 right-2.5 sm:top-3 sm:right-3 z-20 flex items-center gap-1.5 sm:gap-2">
        <button
          type="button"
          onClick={() => triggerCameraFocus(DEFAULT_CENTER[0], DEFAULT_CENTER[1], azimuthStepRef.current + 1)}
          className="min-h-[36px] sm:min-h-[40px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-[#FFFDF9] border border-[#D4C4A8] text-xs font-semibold text-[#2C2A24] shadow-sm hover:bg-[#F7F3EA] active:scale-95 transition-all flex items-center gap-1.5"
          title="Çiftliği 90° döndür"
        >
          <RotateCw className="w-4 h-4 text-[#2F6F5E]" />
          <span className="hidden sm:inline">Döndür</span>
        </button>
        <button
          type="button"
          onClick={() =>
            triggerCameraFocus(
              DEFAULT_CENTER[0],
              DEFAULT_CENTER[1],
              Math.round(azimuthStepRef.current / 4) * 4,
              1
            )
          }
          className="min-h-[36px] sm:min-h-[40px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-[#FFFDF9] border border-[#D4C4A8] text-xs font-semibold text-[#2C2A24] shadow-sm hover:bg-[#F7F3EA] active:scale-95 transition-all flex items-center gap-1.5"
          title="Başlangıç açısına ve merkeze dön"
        >
          <Compass className="w-4 h-4 text-[#2F6F5E]" />
          <span>Ortala</span>
        </button>
      </div>
    </div>
  );
};
