import React, { useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Hammer,
  Info,
  Lock,
  Pickaxe,
  RefreshCw,
  RotateCcw,
  Sprout,
  Store,
  Trash2,
  Warehouse,
} from 'lucide-react';
import { BUILDINGS, CROPS, GAME_CONFIG, ITEMS, MINE_NODES } from '../game/config';
import {
  getBuildingDurationMs,
  getInventoryUsed,
  getNextWarehouseUpgrade,
} from '../game/engine';
import { formatRemainingMs } from '../game/format';
import type { BuildingId, CropId, GameState, ItemId, MineNodeId } from '../game/types';
import { ItemIcon } from './ItemIcon';

interface PlotInspectorProps {
  state: GameState;
  plotId: number;
  now: number;
  onPlant: (plotId: number, cropId: CropId) => void;
  onFertilize: (plotId: number) => void;
  onHarvest: (plotId: number) => void;
}

export const PlotInspector: React.FC<PlotInspectorProps> = ({
  state,
  plotId,
  now,
  onPlant,
  onFertilize,
  onHarvest,
}) => {
  const plot = state.plots.find((p) => p.id === plotId);
  if (!plot) return null;

  if (plot.status === 'empty') {
    return (
      <div className="space-y-4">
        <div>
          <h3 className="font-display text-lg font-bold text-[#2C2A24]">
            Parsel {plotId + 1} · Ekim Seç
          </h3>
          <p className="text-xs text-[#6B6456] mt-0.5">
            Tarlana ekmek istediğin ürünü seç. Hazır ekinler oyundan çıksan da çürümez.
          </p>
        </div>

        <div className="space-y-2.5">
          {(Object.keys(CROPS) as CropId[]).map((cropId) => {
            const crop = CROPS[cropId];
            const locked = state.level < crop.unlockLevel;
            const enoughGold = state.gold >= crop.seedCost;

            return (
              <div
                key={cropId}
                className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl bg-[#F4EFE6] border border-[#E2D8C5] flex items-center justify-center shrink-0">
                    <ItemIcon itemId={cropId} size={28} />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-[#2C2A24]">{crop.name}</span>
                      <span className="text-xs text-[#6B6456] tabular-nums">
                        {formatRemainingMs(crop.durationMs)} · +{crop.yieldAmount} Ürün
                      </span>
                    </div>
                    <p className="text-xs text-[#6B6456] mt-0.5 leading-snug">{crop.description}</p>
                    <div className="text-xs font-medium text-[#5E5748] mt-1 tabular-nums">
                      Maliyet: {crop.seedCost === 0 ? 'Ücretsiz' : `${crop.seedCost} Altın`} · Depoda:{' '}
                      {state.inventory[cropId]}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={locked || !enoughGold}
                  onClick={() => onPlant(plotId, cropId)}
                  className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all active:scale-95 ${
                    locked || !enoughGold
                      ? 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                      : 'bg-[#2F6F5E] text-white hover:bg-[#25594B] shadow-xs'
                  }`}
                >
                  {locked ? `Sv. ${crop.unlockLevel}` : !enoughGold ? 'Altın Az' : 'Ek'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  const crop = plot.cropId ? CROPS[plot.cropId] : null;
  const remainingMs = plot.completesAt ? Math.max(0, plot.completesAt - now) : 0;
  const totalMs =
    plot.plantedAt && plot.completesAt ? Math.max(1000, plot.completesAt - plot.plantedAt) : 1000;
  const progress = Math.min(1, Math.max(0, 1 - remainingMs / totalMs));
  const isReady = remainingMs <= 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-[#F4EFE6] border border-[#E2D8C5] flex items-center justify-center">
          {crop && <ItemIcon itemId={crop.id} size={30} />}
        </div>
        <div>
          <h3 className="font-display text-lg font-bold text-[#2C2A24]">
            Parsel {plotId + 1} · {crop?.name}
          </h3>
          <div className="text-xs text-[#6B6456] tabular-nums">
            {isReady ? `Hasada hazır (+${crop?.yieldAmount} ${crop?.name})` : `Kalan süre: ${formatRemainingMs(remainingMs)}`}
          </div>
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="h-2.5 w-full rounded-full bg-[#E6DEC8] overflow-hidden">
          <div
            className="h-full bg-[#2F6F5E] transition-all duration-300"
            style={{ width: `${Math.round(progress * 100)}%` }}
          />
        </div>
      </div>

      {isReady ? (
        <button
          type="button"
          onClick={() => onHarvest(plotId)}
          className="w-full min-h-[48px] rounded-xl bg-[#2F6F5E] text-white font-semibold text-sm hover:bg-[#25594B] active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-sm"
        >
          <Sprout className="w-4 h-4" />
          <span>Hasat Et (+{crop?.yieldAmount} {crop?.name})</span>
        </button>
      ) : (
        <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ItemIcon itemId="fertilizer" size={22} />
              <span className="text-sm font-semibold text-[#2C2A24]">Doğal Gübre</span>
            </div>
            <span className="text-xs font-semibold text-[#5E5748] tabular-nums">
              Depoda: {state.inventory.fertilizer}
            </span>
          </div>

          <p className="text-xs text-[#6B6456]">
            {plot.fertilized
              ? 'Bu ekime zaten gübre uygulandı. Her ekime en fazla bir kez gübre uygulanabilir.'
              : 'Büyüme süresini %40 azaltır (en az 2 sn kalır). Tavuk Kümesi’nden elde edilir.'}
          </p>

          <button
            type="button"
            disabled={plot.fertilized || state.inventory.fertilizer < 1}
            onClick={() => onFertilize(plotId)}
            className={`w-full min-h-[44px] rounded-xl text-xs font-semibold transition-all active:scale-95 ${
              plot.fertilized || state.inventory.fertilizer < 1
                ? 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                : 'bg-[#C86D3B] text-white hover:bg-[#B25C2E]'
            }`}
          >
            {plot.fertilized
              ? 'Gübre Uygulandı'
              : state.inventory.fertilizer < 1
                ? 'Doğal Gübre Yok'
                : 'Gübre Uygula (-%40 Süre)'}
          </button>
        </div>
      )}
    </div>
  );
};

interface BuildingInspectorProps {
  state: GameState;
  buildingId: BuildingId;
  now: number;
  onStartProduction: (buildingId: BuildingId) => void;
  onCollectProduction: (buildingId: BuildingId) => void;
  onUpgradeBuilding: (buildingId: BuildingId) => void;
}

export const BuildingInspector: React.FC<BuildingInspectorProps> = ({
  state,
  buildingId,
  now,
  onStartProduction,
  onCollectProduction,
  onUpgradeBuilding,
}) => {
  const cfg = BUILDINGS[buildingId];
  const bState = state.buildings[buildingId];
  const isLocked = state.level < cfg.unlockLevel;
  const isProducing = bState.status === 'producing';
  const remainingMs =
    isProducing && bState.completesAt ? Math.max(0, bState.completesAt - now) : 0;
  const totalMs =
    isProducing && bState.startedAt && bState.completesAt
      ? Math.max(1000, bState.completesAt - bState.startedAt)
      : getBuildingDurationMs(buildingId, bState.level);
  const progress = isProducing ? Math.min(1, Math.max(0, 1 - remainingMs / totalMs)) : 0;
  const isReady = isProducing && remainingMs <= 0;

  const hasAllInputs = cfg.inputs.every(
    (req) => (state.inventory[req.itemId] || 0) >= req.amount
  );

  const nextLevel = bState.level + 1;
  const upgradeCost =
    bState.level < cfg.maxLevel ? GAME_CONFIG.buildingUpgradeCosts[nextLevel] : undefined;
  const canAffordUpgrade =
    upgradeCost !== undefined &&
    (state.inventory.tool_part || 0) >= upgradeCost.tool_part &&
    (state.inventory.stone || 0) >= upgradeCost.stone;

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="font-display text-lg font-bold text-[#2C2A24]">{cfg.name}</h3>
          <div className="text-xs text-[#6B6456] mt-0.5 tabular-nums">
            Seviye {bState.level}/{cfg.maxLevel} · Üretim süresi:{' '}
            {formatRemainingMs(getBuildingDurationMs(buildingId, bState.level))}
          </div>
        </div>
      </div>

      <p className="text-xs text-[#5E5748] leading-relaxed">{cfg.description}</p>

      {isLocked ? (
        <div className="rounded-2xl border border-[#DED4C1] bg-[#F4EFE6] p-4 flex items-center gap-3">
          <Lock className="w-5 h-5 text-[#6B6456] shrink-0" />
          <div className="text-xs text-[#2C2A24]">
            Bu bina <span className="font-semibold">{cfg.unlockLevel}. seviyede</span> açılır.
            Tarla ve siparişlerle deneyim kazanarak seviyeni yükseltebilirsin.
          </div>
        </div>
      ) : (
        <>
          {/* Recipe Preview: Required Inputs -> Expected Outputs */}
          <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-3">
            <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
              <div className="space-y-1.5">
                <div className="text-[11px] font-semibold text-[#6B6456]">Gerekli Malzeme</div>
                {cfg.inputs.map((inp) => {
                  const owned = state.inventory[inp.itemId] || 0;
                  const enough = owned >= inp.amount;
                  return (
                    <div key={inp.itemId} className="flex items-center gap-2">
                      <ItemIcon itemId={inp.itemId} size={22} />
                      <div className="text-xs">
                        <div className="font-semibold text-[#2C2A24]">{ITEMS[inp.itemId].name}</div>
                        <div
                          className={`tabular-nums font-medium ${
                            enough ? 'text-[#2F6F5E]' : 'text-[#B43F2E]'
                          }`}
                        >
                          {owned} / {inp.amount} {!enough && '· Eksik'}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <ArrowRight className="w-4 h-4 text-[#8B8270]" />

              <div className="space-y-1.5">
                <div className="text-[11px] font-semibold text-[#6B6456]">Alınacak Ürün</div>
                {cfg.outputs.map((out) => (
                  <div key={out.itemId} className="flex items-center gap-2">
                    <ItemIcon itemId={out.itemId} size={22} />
                    <div className="text-xs">
                      <div className="font-semibold text-[#2C2A24]">
                        +{out.amount} {ITEMS[out.itemId].name}
                      </div>
                      <div className="text-[#6B6456] tabular-nums">+{cfg.xpOnCollect} XP</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {isProducing ? (
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between text-xs font-medium text-[#2C2A24] tabular-nums">
                  <span>{isReady ? 'Üretim tamamlandı!' : cfg.activeLabel}</span>
                  <span>{formatRemainingMs(remainingMs)}</span>
                </div>
                <div className="h-2.5 w-full rounded-full bg-[#E6DEC8] overflow-hidden">
                  <div
                    className="h-full bg-[#2F6F5E] transition-all duration-300"
                    style={{ width: `${Math.round(progress * 100)}%` }}
                  />
                </div>
                {isReady && (
                  <button
                    type="button"
                    onClick={() => onCollectProduction(buildingId)}
                    className="w-full min-h-[48px] rounded-xl bg-[#2F6F5E] text-white font-semibold text-sm hover:bg-[#25594B] active:scale-[0.98] transition-all"
                  >
                    {cfg.collectLabel}
                  </button>
                )}
              </div>
            ) : (
              <button
                type="button"
                disabled={!hasAllInputs}
                onClick={() => onStartProduction(buildingId)}
                className={`w-full min-h-[48px] rounded-xl font-semibold text-sm transition-all active:scale-[0.98] ${
                  hasAllInputs
                    ? 'bg-[#C86D3B] text-white hover:bg-[#B25C2E] shadow-xs'
                    : 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                }`}
              >
                {hasAllInputs
                  ? `${cfg.idleLabel} (${formatRemainingMs(getBuildingDurationMs(buildingId, bState.level))})`
                  : 'Eksik Malzeme Nedeniyle Başlatılamaz'}
              </button>
            )}
          </div>

          {/* Building Upgrade Section */}
          {state.level >= 3 && (
            <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-sm font-semibold text-[#2C2A24]">
                  <Hammer className="w-4 h-4 text-[#2F6F5E]" />
                  <span>Bina Geliştirme</span>
                </div>
                <span className="text-xs font-medium text-[#6B6456] tabular-nums">
                  Sv. {bState.level} / {cfg.maxLevel}
                </span>
              </div>

              {upgradeCost ? (
                <>
                  <p className="text-xs text-[#6B6456]">
                    Seviye {nextLevel}’e yükselterek üretim süresini %15 kısalt (süre en az 4 sn ile
                    sınırlıdır).
                  </p>
                  <div className="flex items-center gap-4 text-xs tabular-nums">
                    <div className="flex items-center gap-1.5">
                      <ItemIcon itemId="tool_part" size={18} />
                      <span
                        className={
                          state.inventory.tool_part >= upgradeCost.tool_part
                            ? 'text-[#2F6F5E] font-semibold'
                            : 'text-[#B43F2E] font-semibold'
                        }
                      >
                        {state.inventory.tool_part}/{upgradeCost.tool_part} Alet Parçası
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <ItemIcon itemId="stone" size={18} />
                      <span
                        className={
                          state.inventory.stone >= upgradeCost.stone
                            ? 'text-[#2F6F5E] font-semibold'
                            : 'text-[#B43F2E] font-semibold'
                        }
                      >
                        {state.inventory.stone}/{upgradeCost.stone} Vadi Taşı
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={!canAffordUpgrade || isProducing}
                    onClick={() => onUpgradeBuilding(buildingId)}
                    className={`w-full min-h-[44px] rounded-xl text-xs font-semibold transition-all active:scale-95 ${
                      canAffordUpgrade && !isProducing
                        ? 'bg-[#2F6F5E] text-white hover:bg-[#25594B]'
                        : 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                    }`}
                  >
                    {isProducing
                      ? 'Üretim Bitince Geliştir'
                      : canAffordUpgrade
                        ? `Seviye ${nextLevel}’e Geliştir`
                        : 'Malzeme Eksik'}
                  </button>
                </>
              ) : (
                <p className="text-xs font-medium text-[#2F6F5E]">
                  Bu bina en yüksek geliştirme seviyesine ulaştı.
                </p>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
};

interface MineInspectorProps {
  state: GameState;
  preferredNode?: MineNodeId;
  now: number;
  onStartMine: (nodeId: MineNodeId) => void;
  onCollectMine: () => void;
}

export const MineInspector: React.FC<MineInspectorProps> = ({
  state,
  preferredNode,
  now,
  onStartMine,
  onCollectMine,
}) => {
  const isLocked = state.level < 3;
  const isWorking = state.mine.status === 'working' && state.mine.activeNodeId !== null;
  const remainingMs =
    isWorking && state.mine.completesAt ? Math.max(0, state.mine.completesAt - now) : 0;
  const isReady = isWorking && remainingMs <= 0;

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-display text-lg font-bold text-[#2C2A24]">Vadi Madeni</h3>
        <p className="text-xs text-[#6B6456] mt-0.5">
          Görünür kaya noktalarından birini seçerek taş ve demir cevheri çıkar. Altın veya enerji
          gerekmez; aynı anda bir maden işi yürütülür.
        </p>
      </div>

      {isLocked ? (
        <div className="rounded-2xl border border-[#DED4C1] bg-[#F4EFE6] p-4 flex items-center gap-3">
          <Lock className="w-5 h-5 text-[#6B6456] shrink-0" />
          <div className="text-xs text-[#2C2A24]">
            Vadi Madeni <span className="font-semibold">3. seviyede</span> açılır. Önce tarım ve
            tavukçuluk görevlerini tamamla.
          </div>
        </div>
      ) : (
        <div className="space-y-2.5">
          {(Object.keys(MINE_NODES) as MineNodeId[]).map((nodeId) => {
            const node = MINE_NODES[nodeId];
            const isActiveNode = isWorking && state.mine.activeNodeId === nodeId;
            const totalMs =
              isActiveNode && state.mine.startedAt && state.mine.completesAt
                ? Math.max(1000, state.mine.completesAt - state.mine.startedAt)
                : node.durationMs;
            const progress = isActiveNode
              ? Math.min(1, Math.max(0, 1 - remainingMs / totalMs))
              : 0;

            return (
              <div
                key={nodeId}
                className={`rounded-2xl border p-3.5 space-y-2.5 transition-colors ${
                  isActiveNode
                    ? 'border-[#C86D3B] bg-[#FFF9EF]'
                    : preferredNode === nodeId
                      ? 'border-[#2F6F5E] bg-[#FFFDF9]'
                      : 'border-[#E2D8C5] bg-[#FFFDF9]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold text-sm text-[#2C2A24]">{node.name}</div>
                    <p className="text-xs text-[#6B6456] mt-0.5">{node.description}</p>
                  </div>
                  <span className="text-xs font-semibold text-[#5E5748] tabular-nums whitespace-nowrap">
                    {formatRemainingMs(node.durationMs)}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs font-medium text-[#2C2A24]">
                  {node.outputs.map((out) => (
                    <div key={out.itemId} className="flex items-center gap-1.5">
                      <ItemIcon itemId={out.itemId} size={18} />
                      <span>
                        +{out.amount} {ITEMS[out.itemId].name}
                      </span>
                    </div>
                  ))}
                  <span className="text-[#6B6456] tabular-nums">· +{node.xpOnCollect} XP</span>
                </div>

                {isActiveNode ? (
                  <div className="space-y-2">
                    <div className="h-2 w-full rounded-full bg-[#E6DEC8] overflow-hidden">
                      <div
                        className="h-full bg-[#2F6F5E] transition-all duration-300"
                        style={{ width: `${Math.round(progress * 100)}%` }}
                      />
                    </div>
                    {isReady ? (
                      <button
                        type="button"
                        onClick={onCollectMine}
                        className="w-full min-h-[44px] rounded-xl bg-[#2F6F5E] text-white text-xs font-semibold hover:bg-[#25594B] active:scale-95 transition-all"
                      >
                        Kaynakları Al
                      </button>
                    ) : (
                      <div className="text-xs font-semibold text-[#C86D3B] tabular-nums">
                        Çalışılıyor · {formatRemainingMs(remainingMs)} kaldı
                      </div>
                    )}
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={isWorking}
                    onClick={() => onStartMine(nodeId)}
                    className={`w-full min-h-[44px] rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                      isWorking
                        ? 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                        : 'bg-[#C86D3B] text-white hover:bg-[#B25C2E]'
                    }`}
                  >
                    <Pickaxe className="w-3.5 h-3.5" />
                    <span>{isWorking ? 'Başka Bir Noktada Çalışılıyor' : 'Kazıyı Başlat'}</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

interface OrdersPanelProps {
  state: GameState;
  now: number;
  onFulfillOrder: (slotIndex: number) => void;
  onCancelOrder: (slotIndex: number) => void;
}

export const OrdersPanel: React.FC<OrdersPanelProps> = ({
  state,
  now,
  onFulfillOrder,
  onCancelOrder,
}) => {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-display text-lg font-bold text-[#2C2A24]">Sipariş Panosu</h3>
        <p className="text-xs text-[#6B6456] mt-0.5">
          Köylülerin siparişlerini teslim ederek altın ve deneyim kazan. İstemezsen ücretsiz iptal
          edip yenisini bekleyebilirsin.
        </p>
      </div>

      <div className="space-y-3">
        {state.orders.map((order) => {
          if (order.status === 'cooldown') {
            const rem = order.cooldownEndsAt ? Math.max(0, order.cooldownEndsAt - now) : 0;
            return (
              <div
                key={order.slotIndex}
                className="rounded-2xl border border-dashed border-[#CFC6B4] bg-[#F7F3EA] p-4 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-2.5 text-xs text-[#6B6456]">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#C86D3B]" />
                  <span>Yeni sipariş hazırlanıyor...</span>
                </div>
                <span className="text-xs font-semibold text-[#C86D3B] tabular-nums">
                  {formatRemainingMs(rem)}
                </span>
              </div>
            );
          }

          const canFulfill = order.requirements.every(
            (r) => (state.inventory[r.itemId] || 0) >= r.amount
          );

          return (
            <div
              key={order.id}
              className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs text-[#6B6456]">
                    {order.customerName}
                    {order.isMarketSpecial && ' · Köy Pazarı Siparişi'}
                  </div>
                  <div className="font-semibold text-sm text-[#2C2A24]">{order.title}</div>
                </div>
                <div className="text-right text-xs font-semibold text-[#2C2A24] tabular-nums">
                  <div className="flex items-center justify-end gap-1">
                    <ItemIcon itemId="gold" size={16} />
                    <span>+{order.goldReward}</span>
                  </div>
                  <div className="text-[#2F6F5E]">+{order.xpReward} XP</div>
                </div>
              </div>

              <div className="space-y-1.5">
                {order.requirements.map((req) => {
                  const owned = state.inventory[req.itemId] || 0;
                  const ok = owned >= req.amount;
                  return (
                    <div key={req.itemId} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <ItemIcon itemId={req.itemId} size={20} />
                        <span className="font-medium text-[#2C2A24]">
                          {ITEMS[req.itemId].name}
                        </span>
                      </div>
                      <span
                        className={`font-semibold tabular-nums ${
                          ok ? 'text-[#2F6F5E]' : 'text-[#B43F2E]'
                        }`}
                      >
                        {owned} / {req.amount}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={!canFulfill}
                  onClick={() => onFulfillOrder(order.slotIndex)}
                  className={`flex-1 min-h-[44px] rounded-xl text-xs font-semibold transition-all active:scale-95 ${
                    canFulfill
                      ? 'bg-[#2F6F5E] text-white hover:bg-[#25594B] shadow-xs'
                      : 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                  }`}
                >
                  {canFulfill ? 'Teslim Et' : 'Ürün Eksik'}
                </button>
                <button
                  type="button"
                  onClick={() => onCancelOrder(order.slotIndex)}
                  aria-label="Siparişi iptal et"
                  className="min-h-[44px] px-3 rounded-xl border border-[#DED4C1] bg-[#F7F3EA] text-xs font-medium text-[#5E5748] hover:bg-[#EAE4D7] active:scale-95 transition-all flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>İptal</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface WarehousePanelProps {
  state: GameState;
  onSellItem: (itemId: ItemId, qty: number) => void;
  onUpgradeWarehouse: () => void;
}

export const WarehousePanel: React.FC<WarehousePanelProps> = ({
  state,
  onSellItem,
  onUpgradeWarehouse,
}) => {
  const used = getInventoryUsed(state.inventory);
  const ratio = Math.min(1, used / Math.max(1, state.warehouseCapacity));
  const nextUpgrade = getNextWarehouseUpgrade(state.warehouseCapacity);
  const canUpgrade =
    state.level >= 3 &&
    nextUpgrade !== null &&
    (state.inventory.stone || 0) >= nextUpgrade.stoneCost;

  const sortedItems = (Object.keys(ITEMS) as ItemId[]).sort((a, b) => {
    const countDiff = (state.inventory[b] > 0 ? 1 : 0) - (state.inventory[a] > 0 ? 1 : 0);
    if (countDiff !== 0) return countDiff;
    return 0;
  });

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center justify-between">
          <h3 className="font-display text-lg font-bold text-[#2C2A24]">Ambar ve Envanter</h3>
          <span
            className={`text-sm font-bold tabular-nums ${
              used >= state.warehouseCapacity ? 'text-[#B43F2E]' : 'text-[#2F6F5E]'
            }`}
          >
            {used} / {state.warehouseCapacity}
          </span>
        </div>
        <div className="h-2.5 w-full rounded-full bg-[#E6DEC8] overflow-hidden mt-2">
          <div
            className={`h-full transition-all duration-300 ${
              used >= state.warehouseCapacity ? 'bg-[#B43F2E]' : 'bg-[#2F6F5E]'
            }`}
            style={{ width: `${Math.round(ratio * 100)}%` }}
          />
        </div>
        {used >= state.warehouseCapacity && (
          <p className="text-xs font-medium text-[#B43F2E] mt-1.5">
            Depo dolu! Yeni ürün hasat etmek için aşağıdan ürün sat veya taşla depoyu büyüt.
          </p>
        )}
      </div>

      {/* Warehouse Stone Upgrade Card */}
      <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#2C2A24]">
            <Warehouse className="w-4 h-4 text-[#2F6F5E]" />
            <span>Depo Kapasitesini Büyüt</span>
          </div>
          {nextUpgrade && (
            <span className="text-xs font-semibold text-[#2F6F5E] tabular-nums">
              {state.warehouseCapacity} → {nextUpgrade.targetCapacity}
            </span>
          )}
        </div>

        {state.level < 3 ? (
          <p className="text-xs text-[#6B6456]">
            Taş kullanarak depo büyütme 3. seviyede Maden ile birlikte açılır.
          </p>
        ) : nextUpgrade ? (
          <div className="flex items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-1.5 text-xs tabular-nums">
              <ItemIcon itemId="stone" size={18} />
              <span
                className={
                  state.inventory.stone >= nextUpgrade.stoneCost
                    ? 'text-[#2F6F5E] font-semibold'
                    : 'text-[#B43F2E] font-semibold'
                }
              >
                {state.inventory.stone} / {nextUpgrade.stoneCost} Vadi Taşı
              </span>
            </div>
            <button
              type="button"
              disabled={!canUpgrade}
              onClick={onUpgradeWarehouse}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-95 ${
                canUpgrade
                  ? 'bg-[#2F6F5E] text-white hover:bg-[#25594B]'
                  : 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
              }`}
            >
              Genişlet
            </button>
          </div>
        ) : (
          <p className="text-xs font-medium text-[#2F6F5E]">Depo en yüksek kapasiteye ulaştı.</p>
        )}
      </div>

      {/* Item List with Origins, Usages & Direct Sell */}
      <div className="space-y-2.5">
        {sortedItems.map((itemId) => {
          const item = ITEMS[itemId];
          const count = state.inventory[itemId] || 0;

          return (
            <div
              key={itemId}
              className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3 space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-[#F4EFE6] border border-[#E2D8C5] flex items-center justify-center shrink-0">
                    <ItemIcon itemId={itemId} size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-[#2C2A24]">{item.name}</span>
                      <span className="text-[11px] text-[#6B6456]">{item.category}</span>
                    </div>
                    <div className="text-xs text-[#6B6456] tabular-nums">
                      Satış değeri: {item.sellPrice} Altın
                    </div>
                  </div>
                </div>
                <span className="text-base font-bold text-[#2C2A24] tabular-nums px-1">
                  {count}
                </span>
              </div>

              <div className="text-[11px] text-[#5E5748] space-y-0.5 leading-snug">
                <div>
                  <span className="font-semibold text-[#2C2A24]">Nereden:</span> {item.origin}
                </div>
                <div>
                  <span className="font-semibold text-[#2C2A24]">Kullanım:</span> {item.usage}
                </div>
              </div>

              {count > 0 && (
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => onSellItem(itemId, 1)}
                    className="flex-1 min-h-[40px] rounded-xl border border-[#DED4C1] bg-[#F7F3EA] text-xs font-semibold text-[#2C2A24] hover:bg-[#EAE4D7] active:scale-95 transition-all tabular-nums"
                  >
                    1 Sat (+{item.sellPrice} Altın)
                  </button>
                  {count > 1 && (
                    <button
                      type="button"
                      onClick={() => onSellItem(itemId, count)}
                      className="min-h-[40px] px-3 rounded-xl border border-[#DED4C1] bg-[#FFFDF9] text-xs font-semibold text-[#C86D3B] hover:bg-[#FFF5E4] active:scale-95 transition-all tabular-nums"
                    >
                      Hepsini Sat (+{count * item.sellPrice})
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface VillageMarketPanelProps {
  state: GameState;
  onDeliverResource: (itemId: 'bread' | 'egg' | 'stone', amount: number) => void;
}

export const VillageMarketPanel: React.FC<VillageMarketPanelProps> = ({
  state,
  onDeliverResource,
}) => {
  const reqs = GAME_CONFIG.villageMarketRequirements;
  const delivered = state.villageMarket.delivered;
  const totalReq = reqs.bread + reqs.egg + reqs.stone;
  const totalDel = delivered.bread + delivered.egg + delivered.stone;
  const isLocked = state.level < 3;

  const entries: { itemId: 'bread' | 'egg' | 'stone'; pillar: string }[] = [
    { itemId: 'bread', pillar: 'Tarım · Fırın' },
    { itemId: 'egg', pillar: 'Hayvancılık · Kümes' },
    { itemId: 'stone', pillar: 'Madencilik · Ocak' },
  ];

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center gap-2">
          <Store className="w-5 h-5 text-[#2F6F5E]" />
          <h3 className="font-display text-lg font-bold text-[#2C2A24]">Köy Pazarı Onarımı</h3>
        </div>
        <p className="text-xs text-[#6B6456] mt-1 leading-relaxed">
          {state.villageMarket.repaired
            ? 'Köy Pazarı yeniden canlandı! Meydandaki tezgahlar açıldı ve yüksek ödüllü Köy Pazarı Siparişleri artık sipariş panosunda çıkıyor.'
            : 'Köyün ortak pazarını ayağa kaldırmak için tarım, hayvancılık ve madencilikten ürünleri parça parça teslim et.'}
        </p>
      </div>

      {isLocked ? (
        <div className="rounded-2xl border border-[#DED4C1] bg-[#F4EFE6] p-4 flex items-center gap-3">
          <Lock className="w-5 h-5 text-[#6B6456] shrink-0" />
          <div className="text-xs text-[#2C2A24]">
            Köy Pazarı onarımı <span className="font-semibold">3. seviyede</span> açılır.
          </div>
        </div>
      ) : (
        <>
          <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-[#2C2A24]">Ortak Onarım İlerlemesi</span>
              <span className="text-[#2F6F5E] tabular-nums">
                {totalDel} / {totalReq} Kaynak
              </span>
            </div>
            <div className="h-2.5 w-full rounded-full bg-[#E6DEC8] overflow-hidden">
              <div
                className="h-full bg-[#2F6F5E] transition-all duration-300"
                style={{ width: `${Math.round((totalDel / totalReq) * 100)}%` }}
              />
            </div>
            {!state.villageMarket.repaired && (
              <div className="text-[11px] text-[#6B6456] tabular-nums">
                Tamamlama ödülü: +{GAME_CONFIG.villageMarketCompletionReward.gold} Altın · +
                {GAME_CONFIG.villageMarketCompletionReward.xp} XP · Özel Pazar Siparişleri
              </div>
            )}
          </div>

          {state.villageMarket.repaired ? (
            <div className="rounded-2xl border border-[#2F6F5E]/30 bg-[#EEF5F1] p-4 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2F6F5E] shrink-0" />
              <div className="text-xs text-[#2C2A24] leading-snug">
                <div className="font-semibold text-sm">Pazar Açık ve Canlı!</div>
                Köy halkı yeniden meydanda buluşuyor. Sipariş Panosu’nu kontrol ederek yeni Pazar
                siparişlerini teslim edebilirsin.
              </div>
            </div>
          ) : (
            <div className="space-y-2.5">
              {entries.map(({ itemId, pillar }) => {
                const needed = reqs[itemId];
                const done = delivered[itemId];
                const remaining = Math.max(0, needed - done);
                const owned = state.inventory[itemId] || 0;
                const isComplete = remaining === 0;

                return (
                  <div
                    key={itemId}
                    className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <ItemIcon itemId={itemId} size={24} />
                        <div>
                          <div className="font-semibold text-sm text-[#2C2A24]">
                            {ITEMS[itemId].name}
                          </div>
                          <div className="text-[11px] text-[#6B6456]">{pillar}</div>
                        </div>
                      </div>
                      <div className="text-right tabular-nums">
                        <div className="text-xs font-bold text-[#2C2A24]">
                          {done} / {needed}
                        </div>
                        <div className="text-[11px] text-[#6B6456]">
                          {isComplete ? 'Tamamlandı' : `Kalan: ${remaining}`}
                        </div>
                      </div>
                    </div>

                    {!isComplete && (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={owned < 1}
                          onClick={() => onDeliverResource(itemId, 1)}
                          className={`flex-1 min-h-[42px] rounded-xl text-xs font-semibold transition-all active:scale-95 ${
                            owned >= 1
                              ? 'bg-[#2F6F5E] text-white hover:bg-[#25594B]'
                              : 'bg-[#EAE4D7] text-[#8B8270] cursor-not-allowed'
                          }`}
                        >
                          {owned >= 1 ? '+1 Teslim Et' : `Depoda Yok (${owned})`}
                        </button>
                        {owned > 1 && remaining > 1 && (
                          <button
                            type="button"
                            onClick={() => onDeliverResource(itemId, Math.min(owned, remaining))}
                            className="min-h-[42px] px-3 rounded-xl bg-[#C86D3B] text-white text-xs font-semibold hover:bg-[#B25C2E] active:scale-95 transition-all tabular-nums"
                          >
                            +{Math.min(owned, remaining)} Teslim Et
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
};

interface GuideResetPanelProps {
  state: GameState;
  onResetGame: () => void;
}

export const GuideResetPanel: React.FC<GuideResetPanelProps> = ({ state, onResetGame }) => {
  const [confirmReset, setConfirmReset] = useState(false);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Info className="w-5 h-5 text-[#2F6F5E]" />
        <h3 className="font-display text-lg font-bold text-[#2C2A24]">Mevsim Vadisi Rehberi</h3>
      </div>

      <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2.5 text-xs text-[#5E5748] leading-relaxed">
        <div>
          <span className="font-semibold text-[#2C2A24]">1. Tarım:</span> Buğday her zaman ücretsiz
          ekilir. Mısır 2. seviyede açılır ve tavuk yemine dönüşür. Hazır ürünler çürümez.
        </div>
        <div>
          <span className="font-semibold text-[#2C2A24]">2. Hayvancılık:</span> Yem Değirmeni’nde
          mısırdan tavuk yemi öğüt, Tavuk Kümesi’ne vererek Yumurta ve Doğal Gübre al. Gübre her
          ekime 1 kez uygulanır.
        </div>
        <div>
          <span className="font-semibold text-[#2C2A24]">3. Madencilik:</span> 3. seviyede Vadi
          Madeni açılır. Taş depo ve köy onarımında, Demir Cevheri Atölye’de Alet Parçası yapımında
          kullanılır.
        </div>
      </div>

      <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2">
        <div className="text-xs font-semibold text-[#2C2A24]">İstatistikler</div>
        <div className="grid grid-cols-2 gap-2 text-xs text-[#5E5748] tabular-nums">
          <div>Hasat edilen ekin: {state.stats.cropsHarvested}</div>
          <div>Pişirilen ekmek: {state.stats.breadBaked}</div>
          <div>Toplanan yumurta grubu: {state.stats.eggsCollected}</div>
          <div>Teslim edilen sipariş: {state.stats.ordersDelivered}</div>
          <div>Maden çalışması: {state.stats.mineWorksCompleted}</div>
          <div>Bina geliştirme: {state.stats.buildingsUpgraded}</div>
        </div>
      </div>

      <div className="rounded-2xl border border-[#E2D8C5] bg-[#FFFDF9] p-3.5 space-y-2.5">
        <div className="text-xs font-semibold text-[#2C2A24]">Kayıt Yönetimi</div>
        <p className="text-xs text-[#6B6456]">
          İlerlemen tarayıcında otomatik olarak yerel kaydedilir. Sayfa kapalıyken geçen üretim
          süreleri hesaplanır.
        </p>

        {!confirmReset ? (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="w-full min-h-[44px] rounded-xl border border-[#DED4C1] bg-[#F7F3EA] text-xs font-semibold text-[#B43F2E] hover:bg-[#FDECE9] transition-all flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Çiftliği Baştan Başlat</span>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onResetGame();
                setConfirmReset(false);
              }}
              className="flex-1 min-h-[44px] rounded-xl bg-[#B43F2E] text-white text-xs font-semibold hover:bg-[#993324]"
            >
              Evet, Sıfırla
            </button>
            <button
              type="button"
              onClick={() => setConfirmReset(false)}
              className="flex-1 min-h-[44px] rounded-xl border border-[#DED4C1] bg-[#FFFDF9] text-xs font-semibold text-[#2C2A24]"
            >
              Vazgeç
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
