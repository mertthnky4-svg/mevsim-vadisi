import React from 'react';
import type { ItemId } from '../game/types';

interface ItemIconProps {
  itemId: ItemId | 'gold' | 'xp' | 'warehouse';
  size?: number;
  className?: string;
}

export const ItemIcon: React.FC<ItemIconProps> = ({ itemId, size = 24, className = '' }) => {
  switch (itemId) {
    case 'wheat':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M16 28V10" stroke="#A67C2E" strokeWidth="2.2" strokeLinecap="round" />
          <ellipse cx="12.5" cy="18" rx="3" ry="1.8" transform="rotate(-35 12.5 18)" fill="#E6B84C" stroke="#8C621D" strokeWidth="1.2" />
          <ellipse cx="19.5" cy="18" rx="3" ry="1.8" transform="rotate(35 19.5 18)" fill="#E6B84C" stroke="#8C621D" strokeWidth="1.2" />
          <ellipse cx="12.5" cy="13.5" rx="3" ry="1.8" transform="rotate(-35 12.5 13.5)" fill="#F0C95C" stroke="#8C621D" strokeWidth="1.2" />
          <ellipse cx="19.5" cy="13.5" rx="3" ry="1.8" transform="rotate(35 19.5 13.5)" fill="#F0C95C" stroke="#8C621D" strokeWidth="1.2" />
          <ellipse cx="16" cy="8.5" rx="2.2" ry="3.5" fill="#F5D66E" stroke="#8C621D" strokeWidth="1.2" />
        </svg>
      );
    case 'corn':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <ellipse cx="16" cy="14.5" rx="5.5" ry="9" fill="#F2BE38" stroke="#9E6F10" strokeWidth="1.5" />
          <path d="M12.5 11H19.5M11.5 15H20.5M12.5 19H19.5M16 7V21" stroke="#C78C14" strokeWidth="1.1" strokeLinecap="round" />
          <path d="M11 24C9.5 19 9.5 15 12 13C12 18 13.5 22 16 24.5C18.5 22 20 18 20 13C22.5 15 22.5 19 21 24C19.5 26 17.5 27 16 27C14.5 27 12.5 26 11 24Z" fill="#5A8F49" stroke="#36602A" strokeWidth="1.3" strokeLinejoin="round" />
        </svg>
      );
    case 'bread':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M5 19C5 12.5 9.8 9 16 9C22.2 9 27 12.5 27 19C27 22 24.5 24 21 24H11C7.5 24 5 22 5 19Z" fill="#D98A42" stroke="#7A4416" strokeWidth="1.6" />
          <path d="M7.5 18.5C8 14 11.5 11.5 16 11.5C20.5 11.5 24 14 24.5 18.5" stroke="#F4C17A" strokeWidth="2" strokeLinecap="round" />
          <path d="M12 12.5L14 15.5M17 12L18.5 15" stroke="#7A4416" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case 'chicken_feed':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M9 11L11 7H21L23 11L25 25C25 26.5 23.8 27.5 22.3 27.5H9.7C8.2 27.5 7 26.5 7 25L9 11Z" fill="#DFC79E" stroke="#7A5F39" strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M10.5 11.5H21.5" stroke="#9B7B4F" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="16" cy="18.5" r="4" fill="#F2BE38" stroke="#9E6F10" strokeWidth="1.2" />
          <circle cx="14.5" cy="17.8" r="0.8" fill="#7A4416" />
          <circle cx="17.5" cy="19.2" r="0.8" fill="#7A4416" />
        </svg>
      );
    case 'egg':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M16 5C11.5 5 8 12.5 8 18.5C8 23.5 11.5 27 16 27C20.5 27 24 23.5 24 18.5C24 12.5 20.5 5 16 5Z" fill="#FFF4E0" stroke="#B0895A" strokeWidth="1.6" />
          <path d="M12.5 12.5C11.8 14.5 11.5 16.5 11.8 18.2" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'fertilizer':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M8 22C8 17 11.5 14 16 14C20.5 14 24 17 24 22C24 24.8 21.5 26.5 16 26.5C10.5 26.5 8 24.8 8 22Z" fill="#7A573B" stroke="#4D3421" strokeWidth="1.5" />
          <path d="M16 16V8" stroke="#4F8A4B" strokeWidth="2" strokeLinecap="round" />
          <path d="M16 11C13 11 11 9 11.5 6.5C14 6.5 16 8.2 16 11Z" fill="#6BB35A" stroke="#3B6930" strokeWidth="1.2" />
          <path d="M16 10.5C19 10.5 21 8.5 20.5 6C18 6 16 7.7 16 10.5Z" fill="#82C96E" stroke="#3B6930" strokeWidth="1.2" />
        </svg>
      );
    case 'stone':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M6 21L10 10L19 8L26 14L24 23L13 25L6 21Z" fill="#B5B0A6" stroke="#5E5A52" strokeWidth="1.6" strokeLinejoin="round" />
          <path d="M10 10L17 16L26 14M17 16L13 25" stroke="#7E796F" strokeWidth="1.3" strokeLinejoin="round" />
          <path d="M11 12.5L17 10.5" stroke="#DFDBD2" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case 'iron_ore':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M6 20L9 10L18 7L26 13L25 22L14 25L6 20Z" fill="#7C7771" stroke="#3F3C38" strokeWidth="1.6" strokeLinejoin="round" />
          <path d="M12 13L15 11L17 15L13 16L12 13Z" fill="#C86D3B" stroke="#7A3A1A" strokeWidth="1" />
          <path d="M19 16L22 15L23 19L19 20L19 16Z" fill="#D9824C" stroke="#7A3A1A" strokeWidth="1" />
          <circle cx="15" cy="20" r="1.7" fill="#C86D3B" />
        </svg>
      );
    case 'tool_part':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M9 23L19 13" stroke="#5A636A" strokeWidth="3.2" strokeLinecap="round" />
          <path d="M19 7C21.5 6.2 24.2 7.2 25.3 9.5L22.5 11L21 9.5L22.5 6.7C21.2 6.5 19.9 6.6 19 7Z" fill="#7C8791" />
          <circle cx="21" cy="11" r="4.5" fill="#8C97A1" stroke="#3F474E" strokeWidth="1.5" />
          <circle cx="21" cy="11" r="1.5" fill="#F4EFE6" />
          <path d="M7 22L10 25L12 23L9 20L7 22Z" fill="#B5753F" stroke="#6B401B" strokeWidth="1.2" />
        </svg>
      );
    case 'gold':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <circle cx="16" cy="16" r="10.5" fill="#F2C14E" stroke="#9A6B12" strokeWidth="1.8" />
          <circle cx="16" cy="16" r="7" stroke="#D99B26" strokeWidth="1.3" />
          <path d="M16 11.5V20.5M13.5 14C13.5 12.8 14.6 12 16 12C17.4 12 18.5 12.8 18.5 14C18.5 15.2 17.2 15.8 16 16C14.8 16.2 13.5 16.8 13.5 18C13.5 19.2 14.6 20 16 20C17.4 20 18.5 19.2 18.5 18" stroke="#8C5D08" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case 'xp':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M16 4L19.4 11.4L27.5 12.4L21.5 18L23 26L16 22L9 26L10.5 18L4.5 12.4L12.6 11.4L16 4Z" fill="#599B87" stroke="#265A4B" strokeWidth="1.6" strokeLinejoin="round" />
        </svg>
      );
    case 'warehouse':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M5 14L16 6L27 14V26H5V14Z" fill="#D4A373" stroke="#7A4F2B" strokeWidth="1.6" strokeLinejoin="round" />
          <path d="M4 14.5L16 5.5L28 14.5" stroke="#A65336" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          <rect x="11.5" y="16" width="9" height="10" fill="#8C5B34" stroke="#5E3A1E" strokeWidth="1.3" />
          <path d="M11.5 16L20.5 26M20.5 16L11.5 26" stroke="#D4A373" strokeWidth="1.1" />
        </svg>
      );
  }
};
